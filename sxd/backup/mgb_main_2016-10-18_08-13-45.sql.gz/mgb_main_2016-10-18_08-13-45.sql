#SXD20|20011|50548|50619|2016.10.18 08:13:45|mgb_main|0|426|1746|
#TA b_abtest`9`16384|b_admin_notify`0`16384|b_admin_notify_lang`0`16384|b_agent`31`16384|b_app_password`0`16384|b_bitrixcloud_option`4`16384|b_blog`0`16384|b_blog_category`0`16384|b_blog_comment`0`16384|b_blog_group`0`16384|b_blog_image`0`16384|b_blog_post`0`16384|b_blog_post_category`0`16384|b_blog_post_param`0`16384|b_blog_site_path`0`16384|b_blog_smile`14`16384|b_blog_smile_lang`28`16384|b_blog_socnet`0`16384|b_blog_socnet_rights`0`16384|b_blog_trackback`0`16384|b_blog_user`0`16384|b_blog_user2blog`0`16384|b_blog_user2user_group`0`16384|b_blog_user_group`2`16384|b_blog_user_group_perms`0`16384|b_cache_tag`2`16384|b_captcha`0`16384|b_catalog_contractor`0`16384|b_catalog_currency`5`16384|b_catalog_currency_lang`10`16384|b_catalog_currency_rate`0`16384|b_catalog_disc_save_group`0`16384|b_catalog_disc_save_range`0`16384|b_catalog_disc_save_user`0`16384|b_catalog_discount`0`16384|b_catalog_discount2cat`0`16384|b_catalog_discount2group`0`16384|b_catalog_discount2iblock`0`16384|b_catalog_discount2product`0`16384|b_catalog_discount2section`0`16384|b_catalog_discount_cond`0`16384|b_catalog_discount_coupon`0`16384|b_catalog_discount_module`0`16384|b_catalog_docs_barcode`0`16384|b_catalog_docs_element`0`16384|b_catalog_export`1`16384|b_catalog_extra`0`16384|b_catalog_group`3`16384|b_catalog_group2group`6`16384|b_catalog_group_lang`6`16384|b_catalog_iblock`0`16384|b_catalog_load`0`16384|b_catalog_measure`5`16384|b_catalog_measure_ratio`0`16384|b_catalog_price`0`16384|b_catalog_product`0`16384|b_catalog_product2group`0`16384|b_catalog_product_sets`0`16384|b_catalog_store`0`16384|b_catalog_store_barcode`0`16384|b_catalog_store_docs`0`16384|b_catalog_store_product`0`16384|b_catalog_subscribe`0`16384|b_catalog_subscribe_access`0`16384|b_catalog_vat`2`16384|b_catalog_viewed_product`0`16384|b_checklist`0`16384|b_clouds_file_bucket`0`16384|b_clouds_file_resize`0`16384|b_clouds_file_upload`0`16384|b_component_params`0`16384|b_conv_context`1`16384|b_conv_context_attribute`4`16384|b_conv_context_counter_day`1`16384|b_conv_context_entity_item`0`16384|b_counter_data`0`16384|b_culture`2`16384|b_event`0`16384|b_event_attachment`0`16384|b_event_log`0`16384|b_event_message`71`180224|b_event_message_attachment`0`16384|b_event_message_site`43`16384|b_event_type`91`65536|b_favorite`0`16384|b_file`0`16384|b_file_search`0`16384|b_filters`0`16384|b_finder_dest`0`16384|b_form`0`16384|b_form_2_group`0`16384|b_form_2_mail_template`0`16384|b_form_2_site`0`16384|b_form_answer`0`16384|b_form_crm`0`16384|b_form_crm_field`0`16384|b_form_crm_link`0`16384|b_form_field`0`16384|b_form_field_filter`0`16384|b_form_field_validator`0`16384|b_form_menu`0`16384|b_form_result`0`16384|b_form_result_answer`0`16384|b_form_status`0`16384|b_form_status_2_group`0`16384|b_form_status_2_mail_template`0`16384|b_forum`0`16384|b_forum2site`0`16384|b_forum_dictionary`4`16384|b_forum_email`0`16384|b_forum_file`0`16384|b_forum_filter`91`65536|b_forum_group`0`16384|b_forum_group_lang`0`16384|b_forum_letter`37`16384|b_forum_message`0`16384|b_forum_perms`0`16384|b_forum_pm_folder`4`16384|b_forum_points`0`16384|b_forum_points2post`0`16384|b_forum_points_lang`0`16384|b_forum_private_message`0`16384|b_forum_rank`0`16384|b_forum_rank_lang`0`16384|b_forum_stat`0`16384|b_forum_subscribe`0`16384|b_forum_topic`0`16384|b_forum_user`0`16384|b_forum_user_forum`0`16384|b_forum_user_points`0`16384|b_forum_user_topic`0`16384|b_group`6`16384|b_group_collection_task`0`16384|b_group_subordinate`0`16384|b_group_task`2`16384|b_hlblock_entity`0`16384|b_hot_keys`12`16384|b_hot_keys_code`79`16384|b_iblock`0`16384|b_iblock_cache`0`16384|b_iblock_element`0`16384|b_iblock_element_iprop`0`16384|b_iblock_element_lock`0`16384|b_iblock_element_property`0`16384|b_iblock_element_right`0`16384|b_iblock_fields`0`16384|b_iblock_group`0`16384|b_iblock_iblock_iprop`0`16384|b_iblock_iproperty`0`16384|b_iblock_messages`0`16384|b_iblock_offers_tmp`0`16384|b_iblock_property`0`16384|b_iblock_property_enum`0`16384|b_iblock_right`0`16384|b_iblock_rss`0`16384|b_iblock_section`0`16384|b_iblock_section_element`0`16384|b_iblock_section_iprop`0`16384|b_iblock_section_property`0`16384|b_iblock_section_right`0`16384|b_iblock_sequence`0`16384|b_iblock_site`0`16384|b_iblock_type`0`16384|b_iblock_type_lang`0`16384|b_lang`1`16384|b_lang_domain`0`16384|b_language`2`16384|b_list_rubric`0`16384|b_medialib_collection`0`16384|b_medialib_collection_item`0`16384|b_medialib_item`0`16384|b_medialib_type`3`16384|b_mobileapp_app`0`16384|b_mobileapp_config`0`16384|b_module`31`16384|b_module_group`0`16384|b_module_to_module`417`81920|b_operation`134`16384|b_option`124`16384|b_perf_cache`0`16384|b_perf_cluster`0`16384|b_perf_component`0`16384|b_perf_error`0`16384|b_perf_history`0`16384|b_perf_hit`0`16384|b_perf_index_ban`0`16384|b_perf_index_complete`0`16384|b_perf_index_suggest`0`16384|b_perf_index_suggest_sql`0`16384|b_perf_sql`0`16384|b_perf_sql_backtrace`0`16384|b_perf_tab_column_stat`0`16384|b_perf_tab_stat`0`16384|b_perf_test`0`16384|b_posting`0`16384|b_posting_email`0`16384|b_posting_file`0`16384|b_posting_group`0`16384|b_posting_rubric`0`16384|b_pull_channel`1`16384|b_pull_push`0`16384|b_pull_push_queue`0`16384|b_pull_stack`0`16384|b_pull_watch`0`16384|b_rating`2`16384|b_rating_component`9`16384|b_rating_component_results`2`16384|b_rating_prepare`0`16384|b_rating_results`2`16384|b_rating_rule`5`16384|b_rating_rule_vetting`0`16384|b_rating_user`2`16384|b_rating_vote`0`16384|b_rating_vote_group`6`16384|b_rating_voting`0`16384|b_rating_voting_prepare`0`16384|b_rating_weight`1`16384|b_sale_affiliate`0`16384|b_sale_affiliate_plan`0`16384|b_sale_affiliate_plan_section`0`16384|b_sale_affiliate_tier`0`16384|b_sale_affiliate_transact`0`16384|b_sale_auxiliary`0`16384|b_sale_basket`0`16384|b_sale_basket_props`0`16384|b_sale_bizval`0`16384|b_sale_bizval_code_1C`0`16384|b_sale_bizval_persondomain`0`16384|b_sale_company`0`16384|b_sale_company2location`0`16384|b_sale_company2service`0`16384|b_sale_delivery2location`0`16384|b_sale_delivery2paysystem`0`16384|b_sale_delivery_es`0`16384|b_sale_delivery_srv`0`16384|b_sale_discount`0`16384|b_sale_discount_coupon`0`16384|b_sale_discount_entities`0`16384|b_sale_discount_group`0`16384|b_sale_discount_module`0`16384|b_sale_export`0`16384|b_sale_fuser`0`16384|b_sale_gift_related_data`0`16384|b_sale_hdaln`0`16384|b_sale_lang`0`16384|b_sale_loc_2site`0`16384|b_sale_loc_def2site`0`16384|b_sale_loc_ext`0`16384|b_sale_loc_ext_srv`0`16384|b_sale_loc_name`0`16384|b_sale_loc_type`0`16384|b_sale_loc_type_name`0`16384|b_sale_location`0`16384|b_sale_location2location_group`0`16384|b_sale_location_city`0`16384|b_sale_location_city_lang`0`16384|b_sale_location_country`0`16384|b_sale_location_country_lang`0`16384|b_sale_location_group`0`16384|b_sale_location_group_lang`0`16384|b_sale_location_region`0`16384|b_sale_location_region_lang`0`16384|b_sale_location_zip`0`16384|b_sale_order`0`16384|b_sale_order_change`0`16384|b_sale_order_coupons`0`16384|b_sale_order_delivery`0`16384|b_sale_order_delivery_es`0`16384|b_sale_order_delivery_req`0`16384|b_sale_order_discount`0`16384|b_sale_order_discount_data`0`16384|b_sale_order_dlv_basket`0`16384|b_sale_order_flags2group`0`16384|b_sale_order_history`0`16384|b_sale_order_modules`0`16384|b_sale_order_payment`0`16384|b_sale_order_payment_es`0`16384|b_sale_order_processing`0`16384|b_sale_order_props`0`16384|b_sale_order_props_group`0`16384|b_sale_order_props_relation`0`16384|b_sale_order_props_value`0`16384|b_sale_order_props_variant`0`16384|b_sale_order_rules`0`16384|b_sale_order_rules_descr`0`16384|b_sale_order_tax`0`16384|b_sale_pay_system_action`0`16384|b_sale_pay_system_err_log`0`16384|b_sale_pay_system_es`0`16384|b_sale_person_type`0`16384|b_sale_person_type_site`0`16384|b_sale_product2product`0`16384|b_sale_recurring`0`16384|b_sale_service_rstr`0`16384|b_sale_site2group`0`16384|b_sale_status`4`16384|b_sale_status_group_task`0`16384|b_sale_status_lang`8`16384|b_sale_store_barcode`0`16384|b_sale_tax`0`16384|b_sale_tax2location`0`16384|b_sale_tax_exempt2group`0`16384|b_sale_tax_rate`0`16384|b_sale_tp`1`16384|b_sale_tp_ebay_cat`0`16384|b_sale_tp_ebay_cat_var`0`16384|b_sale_tp_ebay_fq`0`16384|b_sale_tp_ebay_fr`0`16384|b_sale_tp_map`0`16384|b_sale_tp_map_entity`0`16384|b_sale_tp_order`0`16384|b_sale_user_account`0`16384|b_sale_user_cards`0`16384|b_sale_user_props`0`16384|b_sale_user_props_value`0`16384|b_sale_user_transact`0`16384|b_sale_viewed_product`0`16384|b_sale_yandex_settings`0`16384|b_search_content`0`16384|b_search_content_freq`0`16384|b_search_content_param`0`16384|b_search_content_right`0`16384|b_search_content_site`0`16384|b_search_content_stem`0`16384|b_search_content_text`0`16384|b_search_content_title`0`16384|b_search_custom_rank`0`16384|b_search_phrase`0`16384|b_search_stem`0`16384|b_search_suggest`0`16384|b_search_tags`0`16384|b_search_user_right`0`16384|b_sec_filter_mask`0`16384|b_sec_frame_mask`0`16384|b_sec_iprule`0`16384|b_sec_iprule_excl_ip`0`16384|b_sec_iprule_excl_mask`0`16384|b_sec_iprule_incl_ip`0`16384|b_sec_iprule_incl_mask`0`16384|b_sec_recovery_codes`0`16384|b_sec_redirect_url`3`16384|b_sec_session`0`16384|b_sec_user`0`16384|b_sec_virus`0`16384|b_sec_white_list`0`16384|b_security_sitecheck`0`16384|b_sender_contact`0`16384|b_sender_contact_list`0`16384|b_sender_group`0`16384|b_sender_group_connector`0`16384|b_sender_list`0`16384|b_sender_mailing`0`16384|b_sender_mailing_attachment`0`16384|b_sender_mailing_chain`0`16384|b_sender_mailing_group`0`16384|b_sender_mailing_subscription`0`16384|b_sender_mailing_trigger`0`16384|b_sender_posting`0`16384|b_sender_posting_click`0`16384|b_sender_posting_read`0`16384|b_sender_posting_recipient`0`16384|b_sender_posting_unsub`0`16384|b_sender_preset_template`0`16384|b_seo_adv_autolog`0`16384|b_seo_adv_banner`0`16384|b_seo_adv_campaign`0`16384|b_seo_adv_group`0`16384|b_seo_adv_link`0`16384|b_seo_adv_log`0`16384|b_seo_adv_order`0`16384|b_seo_adv_region`0`16384|b_seo_keywords`0`16384|b_seo_search_engine`3`16384|b_seo_sitemap`0`16384|b_seo_sitemap_entity`0`16384|b_seo_sitemap_iblock`0`16384|b_seo_sitemap_runtime`0`16384|b_seo_yandex_direct_stat`0`16384|b_short_uri`0`16384|b_site_template`2`16384|b_smile`24`16384|b_smile_lang`38`16384|b_smile_set`2`16384|b_socialservices_contact`0`16384|b_socialservices_contact_connect`0`16384|b_socialservices_message`0`16384|b_socialservices_user`0`16384|b_socialservices_user_link`0`16384|b_sticker`0`16384|b_sticker_group_task`0`16384|b_subscription`0`16384|b_subscription_rubric`0`16384|b_task`52`16384|b_task_operation`265`16384|b_undo`0`16384|b_urlpreview_metadata`0`16384|b_urlpreview_route`0`16384|b_user`1`16384|b_user_access`6`16384|b_user_access_check`2`16384|b_user_counter`0`16384|b_user_digest`0`16384|b_user_field`6`16384|b_user_field_confirm`0`16384|b_user_field_enum`0`16384|b_user_field_lang`0`16384|b_user_group`3`16384|b_user_hit_auth`0`16384|b_user_option`7`16384|b_user_stored_auth`1`16384|b_utm_blog_comment`0`16384|b_utm_blog_post`0`16384|b_utm_forum_message`0`16384|b_uts_blog_comment`0`16384|b_uts_blog_post`0`16384|b_uts_forum_message`0`16384|b_vote`0`16384|b_vote_answer`0`16384|b_vote_channel`0`16384|b_vote_channel_2_group`0`16384|b_vote_channel_2_site`0`16384|b_vote_event`0`16384|b_vote_event_answer`0`16384|b_vote_event_question`0`16384|b_vote_question`0`16384|b_vote_user`0`16384
#EOH

#	TC`b_abtest`utf8_unicode_ci	;
CREATE TABLE `b_abtest` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ENABLED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCR` text COLLATE utf8_unicode_ci,
  `TEST_DATA` text COLLATE utf8_unicode_ci NOT NULL,
  `START_DATE` datetime DEFAULT NULL,
  `STOP_DATE` datetime DEFAULT NULL,
  `DURATION` int(11) NOT NULL DEFAULT '0',
  `PORTION` int(11) NOT NULL DEFAULT '0',
  `MIN_AMOUNT` int(11) DEFAULT NULL,
  `USER_ID` int(11) DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_abtest`utf8_unicode_ci	;
INSERT INTO `b_abtest` VALUES 
(1,'s1','N','T','Новый дизайн','Запустите А/B-тестирование для сравнения текущего дизайна с новым, и убедитесь, что показатели конверсии нового шаблона сайта выше.','a:2:{s:2:\"id\";s:7:\"sample1\";s:4:\"list\";a:1:{i:0;a:3:{s:4:\"type\";s:8:\"template\";s:9:\"old_value\";s:0:\"\";s:9:\"new_value\";s:0:\"\";}}}',\N,\N,0,30,\N,\N,100),
(2,'s1','N','T','Главная страница','Запустите А/B-тестирование, сравните влияние изменений на главной странице на конверсию вашего сайта.','a:2:{s:2:\"id\";s:7:\"sample2\";s:4:\"list\";a:1:{i:0;a:3:{s:4:\"type\";s:4:\"page\";s:9:\"old_value\";s:0:\"\";s:9:\"new_value\";s:0:\"\";}}}',\N,\N,0,30,\N,\N,200),
(3,'s1','N','T','Детальная карточка товара','С этой страничкой знакомится почти каждый покупатель вашего магазина, прежде чем изменить ее, проведите А/B-тестирование и убедитесь, что для новой страницы показатели конверсии выше.','a:2:{s:2:\"id\";s:7:\"sample3\";s:4:\"list\";a:1:{i:0;a:3:{s:4:\"type\";s:4:\"page\";s:9:\"old_value\";s:0:\"\";s:9:\"new_value\";s:0:\"\";}}}',\N,\N,0,30,\N,\N,300),
(4,'s1','N','T','Страницы корзины','Запустите А/B-тестирование, сравните влияние изменений на странице корзины на конверсию вашего сайта.','a:2:{s:2:\"id\";s:7:\"sample4\";s:4:\"list\";a:1:{i:0;a:3:{s:4:\"type\";s:4:\"page\";s:9:\"old_value\";s:0:\"\";s:9:\"new_value\";s:0:\"\";}}}',\N,\N,0,30,\N,\N,400),
(5,'s1','N','T','Страница оформления заказа','Запустите А/B-тестирование, сравните влияние изменений на странице оформления заказа на конверсию вашего сайта.','a:2:{s:2:\"id\";s:7:\"sample5\";s:4:\"list\";a:1:{i:0;a:3:{s:4:\"type\";s:4:\"page\";s:9:\"old_value\";s:0:\"\";s:9:\"new_value\";s:0:\"\";}}}',\N,\N,0,30,\N,\N,500),
(6,'s1','N','T','Произвольная выбранная страница','Проведите А/B-тестирование для любой страницы вашего сайта и сравните показатели конверсии для принятия правильного решения.','a:2:{s:2:\"id\";s:7:\"sample6\";s:4:\"list\";a:1:{i:0;a:3:{s:4:\"type\";s:4:\"page\";s:9:\"old_value\";s:0:\"\";s:9:\"new_value\";s:0:\"\";}}}',\N,\N,0,30,\N,\N,600),
(7,'s1','N','N','Композит','Запустите А/B-тестирование и сравните показатели конверсии с композитом и без него.','a:2:{s:2:\"id\";s:7:\"sample7\";s:4:\"list\";a:1:{i:0;a:3:{s:4:\"type\";s:9:\"composite\";s:9:\"old_value\";s:1:\"N\";s:9:\"new_value\";s:1:\"Y\";}}}',\N,\N,0,30,\N,\N,700),
(8,'s1','N','N','CDN','Запустите А/B-тестирование, чтобы выявить влияние CDN на конверсию вашего сайта.','a:2:{s:2:\"id\";s:7:\"sample8\";s:4:\"list\";a:1:{i:0;a:3:{s:4:\"type\";s:3:\"cdn\";s:9:\"old_value\";s:1:\"N\";s:9:\"new_value\";s:1:\"Y\";}}}',\N,\N,0,30,\N,\N,800),
(9,'s1','N','N','BigData','Узнайте насколько эффективна работа BigData. Запустите А/B-тестирование и сравните показатели конверсии сайта.','a:2:{s:2:\"id\";s:7:\"sample9\";s:4:\"list\";a:1:{i:0;a:3:{s:4:\"type\";s:7:\"bigdata\";s:9:\"old_value\";s:1:\"N\";s:9:\"new_value\";s:1:\"Y\";}}}',\N,\N,0,30,\N,\N,900)	;
#	TC`b_admin_notify`utf8_unicode_ci	;
CREATE TABLE `b_admin_notify` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAG` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MESSAGE` text COLLATE utf8_unicode_ci,
  `ENABLE_CLOSE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `PUBLIC_SECTION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `IX_AD_TAG` (`TAG`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_admin_notify_lang`utf8_unicode_ci	;
CREATE TABLE `b_admin_notify_lang` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `NOTIFY_ID` int(18) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_ADM_NTFY_LANG` (`NOTIFY_ID`,`LID`),
  KEY `IX_ADM_NTFY_LID` (`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_agent`utf8_unicode_ci	;
CREATE TABLE `b_agent` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(18) NOT NULL DEFAULT '100',
  `NAME` text COLLATE utf8_unicode_ci,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `LAST_EXEC` datetime DEFAULT NULL,
  `NEXT_EXEC` datetime NOT NULL,
  `DATE_CHECK` datetime DEFAULT NULL,
  `AGENT_INTERVAL` int(18) DEFAULT '86400',
  `IS_PERIOD` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `USER_ID` int(18) DEFAULT NULL,
  `RUNNING` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `ix_act_next_exec` (`ACTIVE`,`NEXT_EXEC`),
  KEY `ix_agent_user_id` (`USER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_agent`utf8_unicode_ci	;
INSERT INTO `b_agent` VALUES 
(1,'main',100,'CEvent::CleanUpAgent();','Y','2016-10-18 09:05:41','2016-10-19 00:00:00',\N,86400,'Y',\N,'N'),
(2,'main',100,'CUser::CleanUpHitAuthAgent();','Y','2016-10-18 09:05:41','2016-10-19 00:00:00',\N,86400,'Y',\N,'N'),
(3,'main',100,'CCaptchaAgent::DeleteOldCaptcha(3600);','Y','2016-10-18 09:05:41','2016-10-18 10:05:41',\N,3600,'N',\N,'N'),
(4,'main',100,'CUndo::CleanUpOld();','Y','2016-10-18 09:05:41','2016-10-19 00:00:00',\N,86400,'Y',\N,'N'),
(5,'main',100,'CSiteCheckerTest::CommonTest();','Y',\N,'2016-10-19 03:00:00',\N,86400,'N',\N,'N'),
(6,'main',100,'\\Bitrix\\Main\\Analytics\\CounterDataTable::submitData();','Y','2016-10-18 09:09:37','2016-10-18 09:10:37',\N,60,'N',\N,'N'),
(7,'catalog',100,'\\Bitrix\\Catalog\\CatalogViewedProductTable::clearAgent();','Y','2016-10-18 09:05:42','2016-10-23 09:05:42',\N,432000,'N',\N,'N'),
(8,'currency',100,'\\Bitrix\\Currency\\CurrencyManager::currencyBaseRateAgent();','Y',\N,'2016-10-19 00:01:00',\N,86400,'Y',\N,'N'),
(9,'forum',100,'CForumStat::CleanUp();','Y','2016-10-18 09:05:42','2016-10-19 09:05:42',\N,86400,'N',\N,'N'),
(10,'forum',100,'CForumFiles::CleanUp();','Y','2016-10-18 09:05:42','2016-10-19 09:05:42',\N,86400,'N',\N,'N'),
(13,'sale',100,'\\Bitrix\\Sale\\Product2ProductTable::deleteOldProducts(10);','Y','2016-10-18 09:05:42','2016-10-28 09:05:42',\N,864000,'N',\N,'N'),
(14,'sale',100,'CSaleRecurring::AgentCheckRecurring();','Y','2016-10-18 09:05:42','2016-10-18 11:05:42',\N,7200,'N',\N,'N'),
(15,'sale',100,'CSaleOrder::RemindPayment();','Y','2016-10-18 09:05:42','2016-10-19 09:05:42',\N,86400,'N',\N,'N'),
(16,'sale',100,'CSaleViewedProduct::ClearViewed();','Y','2016-10-18 09:05:42','2016-10-19 09:05:42',\N,86400,'N',\N,'N'),
(17,'sale',100,'CSaleOrder::ClearProductReservedQuantity();','Y','2016-10-18 09:05:42','2016-10-19 09:05:42',\N,86400,'N',\N,'N'),
(20,'search',10,'CSearchSuggest::CleanUpAgent();','Y','2016-10-18 09:05:43','2016-10-19 09:05:43',\N,86400,'N',\N,'N'),
(21,'search',10,'CSearchStatistic::CleanUpAgent();','Y','2016-10-18 09:05:43','2016-10-19 09:05:43',\N,86400,'N',\N,'N'),
(23,'security',100,'CSecuritySession::CleanUpAgent();','Y','2016-10-18 09:05:42','2016-10-18 09:35:42',\N,1800,'N',\N,'N'),
(24,'security',100,'CSecurityIPRule::CleanUpAgent();','Y','2016-10-18 09:05:42','2016-10-18 10:05:42',\N,3600,'N',\N,'N'),
(26,'sender',100,'\\Bitrix\\Sender\\MailingManager::checkPeriod();','Y','2016-10-18 09:09:37','2016-10-18 09:10:37',\N,60,'N',\N,'N'),
(28,'seo',100,'Bitrix\\Seo\\Engine\\YandexDirect::updateAgent();','Y','2016-10-18 09:05:43','2016-10-18 10:05:43',\N,3600,'N',\N,'N'),
(29,'seo',100,'Bitrix\\Seo\\Adv\\LogTable::clean();','Y','2016-10-18 09:05:43','2016-10-19 09:05:43',\N,86400,'N',\N,'N'),
(30,'seo',100,'Bitrix\\Seo\\Adv\\Auto::checkQuantityAgent();','Y','2016-10-18 09:05:43','2016-10-18 10:05:43',\N,3600,'N',\N,'N'),
(33,'storeassist',100,'CStoreAssist::AgentCountDayOrders();','Y',\N,'2016-10-19 00:00:00',\N,86400,'N',\N,'N'),
(35,'subscribe',100,'CSubscription::CleanUp();','Y',\N,'2016-10-19 03:00:00',\N,86400,'Y',\N,'N'),
(38,'pull',100,'CPullChannel::CheckOnlineChannel();','Y','2016-10-18 09:09:41','2016-10-18 09:11:21',\N,100,'N',\N,'N'),
(39,'pull',100,'CPullChannel::CheckExpireAgent();','Y',\N,'2016-10-18 20:05:43',\N,43200,'N',\N,'N'),
(40,'pull',100,'CPullStack::CheckExpireAgent();','Y',\N,'2016-10-19 08:05:43',\N,86400,'N',\N,'N'),
(41,'pull',100,'CPullWatch::CheckExpireAgent();','Y','2016-10-18 09:06:17','2016-10-18 09:26:17',\N,600,'N',\N,'N'),
(43,'main',100,'CRatings::Calculate(3);','Y','2016-10-18 09:08:05','2016-10-18 10:08:05',\N,3600,'N',\N,'N'),
(44,'main',100,'CRatings::Calculate(4);','Y','2016-10-18 09:08:06','2016-10-18 10:08:06',\N,3600,'N',\N,'N')	;
#	TC`b_app_password`utf8_unicode_ci	;
CREATE TABLE `b_app_password` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `APPLICATION_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PASSWORD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DIGEST_PASSWORD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `DATE_LOGIN` datetime DEFAULT NULL,
  `LAST_IP` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COMMENT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SYSCOMMENT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_app_password_user` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_bitrixcloud_option`utf8_unicode_ci	;
CREATE TABLE `b_bitrixcloud_option` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL,
  `PARAM_KEY` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PARAM_VALUE` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_bitrixcloud_option_1` (`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_bitrixcloud_option`utf8_unicode_ci	;
INSERT INTO `b_bitrixcloud_option` VALUES 
(1,'backup_quota',0,'0','0'),
(2,'backup_total_size',0,'0','0'),
(3,'backup_last_backup_time',0,'0','1476767293'),
(4,'monitoring_expire_time',0,'0','1476769179')	;
#	TC`b_blog`utf8_unicode_ci	;
CREATE TABLE `b_blog` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DATE_CREATE` datetime NOT NULL,
  `DATE_UPDATE` datetime NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `OWNER_ID` int(11) DEFAULT NULL,
  `SOCNET_GROUP_ID` int(11) DEFAULT NULL,
  `URL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `REAL_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `ENABLE_COMMENTS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ENABLE_IMG_VERIF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ENABLE_RSS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `LAST_POST_ID` int(11) DEFAULT NULL,
  `LAST_POST_DATE` datetime DEFAULT NULL,
  `AUTO_GROUPS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL_NOTIFY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_HTML` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SEARCH_INDEX` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `USE_SOCNET` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_BLOG_BLOG_4` (`URL`),
  KEY `IX_BLOG_BLOG_1` (`GROUP_ID`,`ACTIVE`),
  KEY `IX_BLOG_BLOG_2` (`OWNER_ID`),
  KEY `IX_BLOG_BLOG_5` (`LAST_POST_DATE`),
  KEY `IX_BLOG_BLOG_6` (`SOCNET_GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_blog_category`utf8_unicode_ci	;
CREATE TABLE `b_blog_category` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BLOG_ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_BLOG_CAT_1` (`BLOG_ID`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_blog_comment`utf8_unicode_ci	;
CREATE TABLE `b_blog_comment` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BLOG_ID` int(11) NOT NULL,
  `POST_ID` int(11) NOT NULL,
  `PARENT_ID` int(11) DEFAULT NULL,
  `AUTHOR_ID` int(11) DEFAULT NULL,
  `ICON_ID` int(11) DEFAULT NULL,
  `AUTHOR_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AUTHOR_EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AUTHOR_IP` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AUTHOR_IP1` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_CREATE` datetime NOT NULL,
  `TITLE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `POST_TEXT` text COLLATE utf8_unicode_ci NOT NULL,
  `PUBLISH_STATUS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'P',
  `HAS_PROPS` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SHARE_DEST` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PATH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_BLOG_COMM_1` (`BLOG_ID`,`POST_ID`),
  KEY `IX_BLOG_COMM_2` (`AUTHOR_ID`),
  KEY `IX_BLOG_COMM_3` (`DATE_CREATE`,`AUTHOR_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_blog_group`utf8_unicode_ci	;
CREATE TABLE `b_blog_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_BLOG_GROUP_1` (`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_blog_image`utf8_unicode_ci	;
CREATE TABLE `b_blog_image` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FILE_ID` int(11) NOT NULL DEFAULT '0',
  `BLOG_ID` int(11) NOT NULL DEFAULT '0',
  `POST_ID` int(11) NOT NULL DEFAULT '0',
  `USER_ID` int(11) NOT NULL DEFAULT '0',
  `TIMESTAMP_X` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `TITLE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IMAGE_SIZE` int(11) NOT NULL DEFAULT '0',
  `IS_COMMENT` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `COMMENT_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_BLOG_IMAGE_1` (`POST_ID`,`BLOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_blog_post`utf8_unicode_ci	;
CREATE TABLE `b_blog_post` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `BLOG_ID` int(11) NOT NULL,
  `AUTHOR_ID` int(11) NOT NULL,
  `PREVIEW_TEXT` text COLLATE utf8_unicode_ci,
  `PREVIEW_TEXT_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `DETAIL_TEXT` text COLLATE utf8_unicode_ci NOT NULL,
  `DETAIL_TEXT_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `DATE_CREATE` datetime NOT NULL,
  `DATE_PUBLISH` datetime NOT NULL,
  `KEYWORDS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PUBLISH_STATUS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'P',
  `CATEGORY_ID` char(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ATRIBUTE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ENABLE_TRACKBACK` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ENABLE_COMMENTS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ATTACH_IMG` int(11) DEFAULT NULL,
  `NUM_COMMENTS` int(11) NOT NULL DEFAULT '0',
  `NUM_TRACKBACKS` int(11) NOT NULL DEFAULT '0',
  `VIEWS` int(11) DEFAULT NULL,
  `FAVORITE_SORT` int(11) DEFAULT NULL,
  `PATH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MICRO` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `HAS_IMAGES` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HAS_PROPS` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HAS_TAGS` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HAS_COMMENT_IMAGES` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HAS_SOCNET_ALL` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEO_TITLE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEO_TAGS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEO_DESCRIPTION` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_BLOG_POST_1` (`BLOG_ID`,`PUBLISH_STATUS`,`DATE_PUBLISH`),
  KEY `IX_BLOG_POST_2` (`BLOG_ID`,`DATE_PUBLISH`,`PUBLISH_STATUS`),
  KEY `IX_BLOG_POST_3` (`BLOG_ID`,`CATEGORY_ID`),
  KEY `IX_BLOG_POST_4` (`PUBLISH_STATUS`,`DATE_PUBLISH`),
  KEY `IX_BLOG_POST_5` (`DATE_PUBLISH`,`AUTHOR_ID`),
  KEY `IX_BLOG_POST_CODE` (`BLOG_ID`,`CODE`),
  KEY `IX_BLOG_POST_6` (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_blog_post_category`utf8_unicode_ci	;
CREATE TABLE `b_blog_post_category` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BLOG_ID` int(11) NOT NULL,
  `POST_ID` int(11) NOT NULL,
  `CATEGORY_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_BLOG_POST_CATEGORY` (`POST_ID`,`CATEGORY_ID`),
  KEY `IX_BLOG_POST_CATEGORY_CAT_ID` (`CATEGORY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_blog_post_param`utf8_unicode_ci	;
CREATE TABLE `b_blog_post_param` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `POST_ID` int(11) DEFAULT NULL,
  `USER_ID` int(11) DEFAULT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_BLOG_PP_1` (`POST_ID`,`USER_ID`),
  KEY `IX_BLOG_PP_2` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_blog_site_path`utf8_unicode_ci	;
CREATE TABLE `b_blog_site_path` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `PATH` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_BLOG_SITE_PATH_2` (`SITE_ID`,`TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_blog_smile`utf8_unicode_ci	;
CREATE TABLE `b_blog_smile` (
  `ID` smallint(3) NOT NULL AUTO_INCREMENT,
  `SMILE_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `TYPING` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IMAGE` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CLICKABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(10) NOT NULL DEFAULT '150',
  `IMAGE_WIDTH` int(11) NOT NULL DEFAULT '0',
  `IMAGE_HEIGHT` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_blog_smile`utf8_unicode_ci	;
INSERT INTO `b_blog_smile` VALUES 
(1,'S',':D :-D','icon_biggrin.png',\N,'Y',120,16,16),
(2,'S',':) :-)','icon_smile.png',\N,'Y',100,16,16),
(3,'S',':( :-(','icon_sad.png',\N,'Y',140,16,16),
(4,'S',':o :-o :shock:','icon_eek.png',\N,'Y',180,16,16),
(5,'S','8) 8-)','icon_cool.png',\N,'Y',130,16,16),
(6,'S',':{} :-{}','icon_kiss.png',\N,'Y',200,16,16),
(7,'S',':oops:','icon_redface.png',\N,'Y',190,16,16),
(8,'S',':cry: :~(','icon_cry.png',\N,'Y',160,16,16),
(9,'S',':evil: >:-<','icon_evil.png',\N,'Y',170,16,16),
(10,'S',';) ;-)','icon_wink.png',\N,'Y',110,16,16),
(11,'S',':!:','icon_exclaim.png',\N,'Y',220,16,16),
(12,'S',':?:','icon_question.png',\N,'Y',210,16,16),
(13,'S',':idea:','icon_idea.png',\N,'Y',230,16,16),
(14,'S',':| :-|','icon_neutral.png',\N,'Y',150,16,16)	;
#	TC`b_blog_smile_lang`utf8_unicode_ci	;
CREATE TABLE `b_blog_smile_lang` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SMILE_ID` int(11) NOT NULL DEFAULT '0',
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_BLOG_SMILE_K` (`SMILE_ID`,`LID`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_blog_smile_lang`utf8_unicode_ci	;
INSERT INTO `b_blog_smile_lang` VALUES 
(1,1,'ru','Широкая улыбка'),
(2,1,'en','Big grin'),
(3,2,'ru','С улыбкой'),
(4,2,'en','Smile'),
(5,3,'ru','Печально'),
(6,3,'en','Sad'),
(7,4,'ru','Удивленно'),
(8,4,'en','Surprised'),
(9,5,'ru','Здорово'),
(10,5,'en','Cool'),
(11,6,'ru','Поцелуй'),
(12,6,'en','Kiss'),
(13,7,'ru','Смущенный'),
(14,7,'en','Embarrassed'),
(15,8,'ru','Очень грустно'),
(16,8,'en','Crying'),
(17,9,'ru','Со злостью'),
(18,9,'en','Angry'),
(19,10,'ru','Шутливо'),
(20,10,'en','Wink'),
(21,11,'ru','Восклицание'),
(22,11,'en','Exclamation'),
(23,12,'ru','Вопрос'),
(24,12,'en','Question'),
(25,13,'ru','Идея'),
(26,13,'en','Idea'),
(27,14,'ru','Скептически'),
(28,14,'en','Skeptic')	;
#	TC`b_blog_socnet`utf8_unicode_ci	;
CREATE TABLE `b_blog_socnet` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BLOG_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_BLOG_SOCNET` (`BLOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_blog_socnet_rights`utf8_unicode_ci	;
CREATE TABLE `b_blog_socnet_rights` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `POST_ID` int(11) NOT NULL,
  `ENTITY_TYPE` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `ENTITY` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_BLOG_SR_1` (`POST_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_blog_trackback`utf8_unicode_ci	;
CREATE TABLE `b_blog_trackback` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `URL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PREVIEW_TEXT` text COLLATE utf8_unicode_ci NOT NULL,
  `BLOG_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `POST_DATE` datetime NOT NULL,
  `BLOG_ID` int(11) NOT NULL,
  `POST_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_BLOG_TRBK_1` (`BLOG_ID`,`POST_ID`),
  KEY `IX_BLOG_TRBK_2` (`POST_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_blog_user`utf8_unicode_ci	;
CREATE TABLE `b_blog_user` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `ALIAS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `AVATAR` int(11) DEFAULT NULL,
  `INTERESTS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_VISIT` datetime DEFAULT NULL,
  `DATE_REG` datetime NOT NULL,
  `ALLOW_POST` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_BLOG_USER_1` (`USER_ID`),
  KEY `IX_BLOG_USER_2` (`ALIAS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_blog_user2blog`utf8_unicode_ci	;
CREATE TABLE `b_blog_user2blog` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `BLOG_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_BLOG_USER2GROUP_1` (`BLOG_ID`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_blog_user2user_group`utf8_unicode_ci	;
CREATE TABLE `b_blog_user2user_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `BLOG_ID` int(11) NOT NULL,
  `USER_GROUP_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_BLOG_USER2GROUP_1` (`USER_ID`,`BLOG_ID`,`USER_GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_blog_user_group`utf8_unicode_ci	;
CREATE TABLE `b_blog_user_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BLOG_ID` int(11) DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_BLOG_USER_GROUP_1` (`BLOG_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_blog_user_group`utf8_unicode_ci	;
INSERT INTO `b_blog_user_group` VALUES 
(1,\N,'all'),
(2,\N,'registered')	;
#	TC`b_blog_user_group_perms`utf8_unicode_ci	;
CREATE TABLE `b_blog_user_group_perms` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BLOG_ID` int(11) NOT NULL,
  `USER_GROUP_ID` int(11) NOT NULL,
  `PERMS_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'P',
  `POST_ID` int(11) DEFAULT NULL,
  `PERMS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'D',
  `AUTOSET` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_BLOG_UG_PERMS_1` (`BLOG_ID`,`USER_GROUP_ID`,`PERMS_TYPE`,`POST_ID`),
  KEY `IX_BLOG_UG_PERMS_2` (`USER_GROUP_ID`,`PERMS_TYPE`,`POST_ID`),
  KEY `IX_BLOG_UG_PERMS_3` (`POST_ID`,`USER_GROUP_ID`,`PERMS_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_cache_tag`utf8_unicode_ci	;
CREATE TABLE `b_cache_tag` (
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CACHE_SALT` char(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RELATIVE_PATH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAG` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  KEY `ix_b_cache_tag_0` (`SITE_ID`,`CACHE_SALT`,`RELATIVE_PATH`(50)),
  KEY `ix_b_cache_tag_1` (`TAG`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_cache_tag`utf8_unicode_ci	;
INSERT INTO `b_cache_tag` VALUES 
(\N,\N,'0:1476767287','**'),
('s1','/e25','/s1/bitrix/menu/06f','bitrix:menu')	;
#	TC`b_captcha`utf8_unicode_ci	;
CREATE TABLE `b_captcha` (
  `ID` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `CODE` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `IP` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATE` datetime NOT NULL,
  UNIQUE KEY `UX_B_CAPTCHA` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_contractor`utf8_unicode_ci	;
CREATE TABLE `b_catalog_contractor` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PERSON_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `PERSON_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSON_LASTNAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSON_MIDDLENAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PHONE` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `POST_INDEX` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COUNTRY` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CITY` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COMPANY` varchar(145) COLLATE utf8_unicode_ci DEFAULT NULL,
  `INN` varchar(145) COLLATE utf8_unicode_ci DEFAULT NULL,
  `KPP` varchar(145) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ADDRESS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_MODIFY` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `MODIFIED_BY` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_currency`utf8_unicode_ci	;
CREATE TABLE `b_catalog_currency` (
  `CURRENCY` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `AMOUNT_CNT` int(11) NOT NULL DEFAULT '1',
  `AMOUNT` decimal(18,4) DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `DATE_UPDATE` datetime NOT NULL,
  `NUMCODE` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BASE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CREATED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `CURRENT_BASE_RATE` decimal(26,12) DEFAULT NULL,
  PRIMARY KEY (`CURRENCY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_catalog_currency`utf8_unicode_ci	;
INSERT INTO `b_catalog_currency` VALUES 
('BYN',1,32.3400,500,'2016-10-18 09:00:40','933','N',\N,'2016-10-18 09:00:40',\N,32.340000000000),
('EUR',1,71.7100,300,'2016-10-18 09:00:40','978','N',\N,'2016-10-18 09:00:40',\N,71.710000000000),
('RUB',1,1.0000,100,'2016-10-18 09:00:40','643','Y',\N,'2016-10-18 09:00:40',\N,1.000000000000),
('UAH',10,26.0400,400,'2016-10-18 09:00:40','980','N',\N,'2016-10-18 09:00:40',\N,2.604000000000),
('USD',1,64.8100,200,'2016-10-18 09:00:40','840','N',\N,'2016-10-18 09:00:40',\N,64.810000000000)	;
#	TC`b_catalog_currency_lang`utf8_unicode_ci	;
CREATE TABLE `b_catalog_currency_lang` (
  `CURRENCY` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `FORMAT_STRING` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FULL_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEC_POINT` varchar(5) COLLATE utf8_unicode_ci DEFAULT '.',
  `THOUSANDS_SEP` varchar(5) COLLATE utf8_unicode_ci DEFAULT ' ',
  `DECIMALS` tinyint(4) NOT NULL DEFAULT '2',
  `THOUSANDS_VARIANT` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HIDE_ZERO` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CREATED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  PRIMARY KEY (`CURRENCY`,`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_catalog_currency_lang`utf8_unicode_ci	;
INSERT INTO `b_catalog_currency_lang` VALUES 
('BYN','en','# BYN','Belarusian ruble','.','',2,'S','Y',\N,'2016-10-18 09:00:40',\N,'2016-10-18 09:00:40'),
('BYN','ru','# руб.','Белорусский рубль','.','',2,'S','Y',\N,'2016-10-18 09:00:40',\N,'2016-10-18 09:00:40'),
('EUR','en','&euro;#','Euro','.','',2,'C','Y',\N,'2016-10-18 09:00:40',\N,'2016-10-18 09:00:40'),
('EUR','ru','&euro;#','Евро','.','',2,'C','Y',\N,'2016-10-18 09:00:40',\N,'2016-10-18 09:00:40'),
('RUB','en','# rub.','Ruble','.','',2,'S','Y',\N,'2016-10-18 09:00:40',\N,'2016-10-18 09:00:40'),
('RUB','ru','# руб.','Рубль','.','',2,'S','Y',\N,'2016-10-18 09:00:40',\N,'2016-10-18 09:00:40'),
('UAH','en','UAH #','UAH','.','',2,'S','Y',\N,'2016-10-18 09:00:40',\N,'2016-10-18 09:00:40'),
('UAH','ru','# грн.','Гривна','.','',2,'S','Y',\N,'2016-10-18 09:00:40',\N,'2016-10-18 09:00:40'),
('USD','en','$#','US Dollar','.','',2,'C','Y',\N,'2016-10-18 09:00:40',\N,'2016-10-18 09:00:40'),
('USD','ru','$#','Доллар США','.','',2,'C','Y',\N,'2016-10-18 09:00:40',\N,'2016-10-18 09:00:40')	;
#	TC`b_catalog_currency_rate`utf8_unicode_ci	;
CREATE TABLE `b_catalog_currency_rate` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CURRENCY` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `BASE_CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_RATE` date NOT NULL,
  `RATE_CNT` int(11) NOT NULL DEFAULT '1',
  `RATE` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `CREATED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_CURRENCY_RATE` (`CURRENCY`,`DATE_RATE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_disc_save_group`utf8_unicode_ci	;
CREATE TABLE `b_catalog_disc_save_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_CAT_DSG_DISCOUNT` (`DISCOUNT_ID`),
  KEY `IX_CAT_DSG_GROUP` (`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_disc_save_range`utf8_unicode_ci	;
CREATE TABLE `b_catalog_disc_save_range` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `RANGE_FROM` double NOT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'P',
  `VALUE` double NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_CAT_DSR_DISCOUNT` (`DISCOUNT_ID`),
  KEY `IX_CAT_DSR_DISCOUNT2` (`DISCOUNT_ID`,`RANGE_FROM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_disc_save_user`utf8_unicode_ci	;
CREATE TABLE `b_catalog_disc_save_user` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `ACTIVE_FROM` datetime NOT NULL,
  `ACTIVE_TO` datetime NOT NULL,
  `RANGE_FROM` double NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_CAT_DSU_DISCOUNT` (`DISCOUNT_ID`),
  KEY `IX_CAT_DSU_USER` (`DISCOUNT_ID`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_discount`utf8_unicode_ci	;
CREATE TABLE `b_catalog_discount` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `TYPE` int(11) NOT NULL DEFAULT '0',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ACTIVE_FROM` datetime DEFAULT NULL,
  `ACTIVE_TO` datetime DEFAULT NULL,
  `RENEWAL` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MAX_USES` int(11) NOT NULL DEFAULT '0',
  `COUNT_USES` int(11) NOT NULL DEFAULT '0',
  `COUPON` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `MAX_DISCOUNT` decimal(18,4) DEFAULT NULL,
  `VALUE_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'P',
  `VALUE` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `CURRENCY` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `MIN_ORDER_SUM` decimal(18,4) DEFAULT '0.0000',
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `COUNT_PERIOD` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'U',
  `COUNT_SIZE` int(11) NOT NULL DEFAULT '0',
  `COUNT_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `COUNT_FROM` datetime DEFAULT NULL,
  `COUNT_TO` datetime DEFAULT NULL,
  `ACTION_SIZE` int(11) NOT NULL DEFAULT '0',
  `ACTION_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `PRIORITY` int(18) NOT NULL DEFAULT '1',
  `LAST_DISCOUNT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `VERSION` int(11) NOT NULL DEFAULT '1',
  `NOTES` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONDITIONS` text COLLATE utf8_unicode_ci,
  `UNPACK` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_C_D_COUPON` (`COUPON`),
  KEY `IX_C_D_ACT` (`ACTIVE`,`ACTIVE_FROM`,`ACTIVE_TO`),
  KEY `IX_C_D_ACT_B` (`SITE_ID`,`RENEWAL`,`ACTIVE`,`ACTIVE_FROM`,`ACTIVE_TO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_discount2cat`utf8_unicode_ci	;
CREATE TABLE `b_catalog_discount2cat` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `CATALOG_GROUP_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_C_D2C_CATDIS` (`CATALOG_GROUP_ID`,`DISCOUNT_ID`),
  UNIQUE KEY `IX_C_D2C_CATDIS_B` (`DISCOUNT_ID`,`CATALOG_GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_discount2group`utf8_unicode_ci	;
CREATE TABLE `b_catalog_discount2group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_C_D2G_GRDIS` (`GROUP_ID`,`DISCOUNT_ID`),
  UNIQUE KEY `IX_C_D2G_GRDIS_B` (`DISCOUNT_ID`,`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_discount2iblock`utf8_unicode_ci	;
CREATE TABLE `b_catalog_discount2iblock` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `IBLOCK_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_C_D2I_IBDIS` (`IBLOCK_ID`,`DISCOUNT_ID`),
  UNIQUE KEY `IX_C_D2I_IBDIS_B` (`DISCOUNT_ID`,`IBLOCK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_discount2product`utf8_unicode_ci	;
CREATE TABLE `b_catalog_discount2product` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `PRODUCT_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_C_D2P_PRODIS` (`PRODUCT_ID`,`DISCOUNT_ID`),
  UNIQUE KEY `IX_C_D2P_PRODIS_B` (`DISCOUNT_ID`,`PRODUCT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_discount2section`utf8_unicode_ci	;
CREATE TABLE `b_catalog_discount2section` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_C_D2S_SECDIS` (`SECTION_ID`,`DISCOUNT_ID`),
  UNIQUE KEY `IX_C_D2S_SECDIS_B` (`DISCOUNT_ID`,`SECTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_discount_cond`utf8_unicode_ci	;
CREATE TABLE `b_catalog_discount_cond` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_GROUP_ID` int(11) NOT NULL DEFAULT '-1',
  `PRICE_TYPE_ID` int(11) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_discount_coupon`utf8_unicode_ci	;
CREATE TABLE `b_catalog_discount_coupon` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `COUPON` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_APPLY` datetime DEFAULT NULL,
  `ONE_TIME` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ix_cat_dc_index1` (`DISCOUNT_ID`,`COUPON`),
  KEY `ix_cat_dc_index2` (`COUPON`,`ACTIVE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_discount_module`utf8_unicode_ci	;
CREATE TABLE `b_catalog_discount_module` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_CAT_DSC_MOD` (`DISCOUNT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_docs_barcode`utf8_unicode_ci	;
CREATE TABLE `b_catalog_docs_barcode` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DOC_ELEMENT_ID` int(11) NOT NULL,
  `BARCODE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_CATALOG_DOCS_BARCODE1` (`DOC_ELEMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_docs_element`utf8_unicode_ci	;
CREATE TABLE `b_catalog_docs_element` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DOC_ID` int(11) NOT NULL,
  `STORE_FROM` int(11) DEFAULT NULL,
  `STORE_TO` int(11) DEFAULT NULL,
  `ELEMENT_ID` int(11) DEFAULT NULL,
  `AMOUNT` double DEFAULT NULL,
  `PURCHASING_PRICE` double DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_CATALOG_DOCS_ELEMENT1` (`DOC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_export`utf8_unicode_ci	;
CREATE TABLE `b_catalog_export` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FILE_NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `DEFAULT_PROFILE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IN_MENU` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IN_AGENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IN_CRON` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SETUP_VARS` text COLLATE utf8_unicode_ci,
  `LAST_USE` datetime DEFAULT NULL,
  `IS_EXPORT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NEED_EDIT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `BCAT_EX_FILE_NAME` (`FILE_NAME`),
  KEY `IX_CAT_IS_EXPORT` (`IS_EXPORT`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_catalog_export`utf8_unicode_ci	;
INSERT INTO `b_catalog_export` VALUES 
(1,'yandex','IRR.ru (\"Из рук в руки\")','N','N','N','N',\N,\N,'Y','Y',\N,\N,\N,\N)	;
#	TC`b_catalog_extra`utf8_unicode_ci	;
CREATE TABLE `b_catalog_extra` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `PERCENTAGE` decimal(18,2) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_group`utf8_unicode_ci	;
CREATE TABLE `b_catalog_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `BASE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SORT` int(11) NOT NULL DEFAULT '100',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_catalog_group`utf8_unicode_ci	;
INSERT INTO `b_catalog_group` VALUES 
(1,'BASE','Y',100,\N,'2016-10-18 09:08:07',1,'2016-10-18 09:08:07',1),
(2,'WHOLESALE','N',200,\N,'2016-10-18 09:08:07',1,'2016-10-18 09:08:07',1),
(3,'RETAIL','N',300,\N,'2016-10-18 09:08:07',1,'2016-10-18 09:08:07',1)	;
#	TC`b_catalog_group2group`utf8_unicode_ci	;
CREATE TABLE `b_catalog_group2group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CATALOG_GROUP_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `BUY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_CATG2G_UNI` (`CATALOG_GROUP_ID`,`GROUP_ID`,`BUY`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_catalog_group2group`utf8_unicode_ci	;
INSERT INTO `b_catalog_group2group` VALUES 
(1,1,1,'N'),
(2,1,1,'Y'),
(3,2,5,'N'),
(4,2,5,'Y'),
(5,3,2,'N'),
(6,3,2,'Y')	;
#	TC`b_catalog_group_lang`utf8_unicode_ci	;
CREATE TABLE `b_catalog_group_lang` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CATALOG_GROUP_ID` int(11) NOT NULL,
  `LANG` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_CATALOG_GROUP_ID` (`CATALOG_GROUP_ID`,`LANG`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_catalog_group_lang`utf8_unicode_ci	;
INSERT INTO `b_catalog_group_lang` VALUES 
(1,1,'ru','Базовая цена'),
(2,1,'en','Base price'),
(3,2,'ru','Оптовая цена'),
(4,2,'en','Wholesale price'),
(5,3,'ru','Розничная цена'),
(6,3,'en','Retail price')	;
#	TC`b_catalog_iblock`utf8_unicode_ci	;
CREATE TABLE `b_catalog_iblock` (
  `IBLOCK_ID` int(11) NOT NULL,
  `YANDEX_EXPORT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SUBSCRIPTION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `VAT_ID` int(11) DEFAULT '0',
  `PRODUCT_IBLOCK_ID` int(11) NOT NULL DEFAULT '0',
  `SKU_PROPERTY_ID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`IBLOCK_ID`),
  KEY `IXS_CAT_IB_PRODUCT` (`PRODUCT_IBLOCK_ID`),
  KEY `IXS_CAT_IB_SKU_PROP` (`SKU_PROPERTY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_load`utf8_unicode_ci	;
CREATE TABLE `b_catalog_load` (
  `NAME` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci NOT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'I',
  `LAST_USED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`NAME`,`TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_measure`utf8_unicode_ci	;
CREATE TABLE `b_catalog_measure` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CODE` int(11) NOT NULL,
  `MEASURE_TITLE` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SYMBOL_RUS` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SYMBOL_INTL` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SYMBOL_LETTER_INTL` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_DEFAULT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_B_CATALOG_MEASURE1` (`CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_catalog_measure`utf8_unicode_ci	;
INSERT INTO `b_catalog_measure` VALUES 
(1,6,\N,\N,'m','MTR','N'),
(2,112,\N,\N,'l','LTR','N'),
(3,163,\N,\N,'g','GRM','N'),
(4,166,\N,\N,'kg','KGM','N'),
(5,796,\N,\N,'pc. 1','PCE. NMB','Y')	;
#	TC`b_catalog_measure_ratio`utf8_unicode_ci	;
CREATE TABLE `b_catalog_measure_ratio` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PRODUCT_ID` int(11) NOT NULL,
  `RATIO` double NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_B_CATALOG_MEASURE_RATIO` (`PRODUCT_ID`,`RATIO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_price`utf8_unicode_ci	;
CREATE TABLE `b_catalog_price` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PRODUCT_ID` int(11) NOT NULL,
  `EXTRA_ID` int(11) DEFAULT NULL,
  `CATALOG_GROUP_ID` int(11) NOT NULL,
  `PRICE` decimal(18,2) NOT NULL,
  `CURRENCY` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `QUANTITY_FROM` int(11) DEFAULT NULL,
  `QUANTITY_TO` int(11) DEFAULT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRICE_SCALE` decimal(26,12) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IXS_CAT_PRICE_PID` (`PRODUCT_ID`,`CATALOG_GROUP_ID`),
  KEY `IXS_CAT_PRICE_GID` (`CATALOG_GROUP_ID`),
  KEY `IXS_CAT_PRICE_SCALE` (`PRICE_SCALE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_product`utf8_unicode_ci	;
CREATE TABLE `b_catalog_product` (
  `ID` int(11) NOT NULL,
  `QUANTITY` double NOT NULL,
  `QUANTITY_TRACE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `WEIGHT` double NOT NULL DEFAULT '0',
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `PRICE_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `RECUR_SCHEME_LENGTH` int(11) DEFAULT NULL,
  `RECUR_SCHEME_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'D',
  `TRIAL_PRICE_ID` int(11) DEFAULT NULL,
  `WITHOUT_ORDER` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SELECT_BEST_PRICE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `VAT_ID` int(11) DEFAULT '0',
  `VAT_INCLUDED` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `CAN_BUY_ZERO` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `NEGATIVE_AMOUNT_TRACE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'D',
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PURCHASING_PRICE` decimal(18,2) DEFAULT NULL,
  `PURCHASING_CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BARCODE_MULTI` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `QUANTITY_RESERVED` double DEFAULT '0',
  `SUBSCRIBE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WIDTH` double DEFAULT NULL,
  `LENGTH` double DEFAULT NULL,
  `HEIGHT` double DEFAULT NULL,
  `MEASURE` int(11) DEFAULT NULL,
  `TYPE` int(11) DEFAULT NULL,
  `AVAILABLE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BUNDLE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_product2group`utf8_unicode_ci	;
CREATE TABLE `b_catalog_product2group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PRODUCT_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `ACCESS_LENGTH` int(11) NOT NULL,
  `ACCESS_LENGTH_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'D',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_C_P2G_PROD_GROUP` (`PRODUCT_ID`,`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_product_sets`utf8_unicode_ci	;
CREATE TABLE `b_catalog_product_sets` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TYPE` int(11) NOT NULL,
  `SET_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `ITEM_ID` int(11) NOT NULL,
  `QUANTITY` double DEFAULT NULL,
  `MEASURE` int(11) DEFAULT NULL,
  `DISCOUNT_PERCENT` double DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `CREATED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_CAT_PR_SET_TYPE` (`TYPE`),
  KEY `IX_CAT_PR_SET_OWNER_ID` (`OWNER_ID`),
  KEY `IX_CAT_PR_SET_SET_ID` (`SET_ID`),
  KEY `IX_CAT_PR_SET_ITEM_ID` (`ITEM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_store`utf8_unicode_ci	;
CREATE TABLE `b_catalog_store` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(75) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ADDRESS` varchar(245) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `GPS_N` varchar(15) COLLATE utf8_unicode_ci DEFAULT '0',
  `GPS_S` varchar(15) COLLATE utf8_unicode_ci DEFAULT '0',
  `IMAGE_ID` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOCATION_ID` int(11) DEFAULT NULL,
  `DATE_MODIFY` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DATE_CREATE` datetime DEFAULT NULL,
  `USER_ID` int(11) DEFAULT NULL,
  `MODIFIED_BY` int(11) DEFAULT NULL,
  `PHONE` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SCHEDULE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ISSUING_CENTER` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SHIPPING_CENTER` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_store_barcode`utf8_unicode_ci	;
CREATE TABLE `b_catalog_store_barcode` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PRODUCT_ID` int(11) NOT NULL,
  `BARCODE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STORE_ID` int(11) DEFAULT NULL,
  `ORDER_ID` int(11) DEFAULT NULL,
  `DATE_MODIFY` datetime DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `MODIFIED_BY` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_B_CATALOG_STORE_BARCODE1` (`BARCODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_store_docs`utf8_unicode_ci	;
CREATE TABLE `b_catalog_store_docs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DOC_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONTRACTOR_ID` int(11) DEFAULT NULL,
  `DATE_MODIFY` datetime DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `MODIFIED_BY` int(11) DEFAULT NULL,
  `CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STATUS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DATE_STATUS` datetime DEFAULT NULL,
  `DATE_DOCUMENT` datetime DEFAULT NULL,
  `STATUS_BY` int(11) DEFAULT NULL,
  `TOTAL` double DEFAULT NULL,
  `COMMENTARY` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_store_product`utf8_unicode_ci	;
CREATE TABLE `b_catalog_store_product` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PRODUCT_ID` int(11) NOT NULL,
  `AMOUNT` double NOT NULL DEFAULT '0',
  `STORE_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_CATALOG_STORE_PRODUCT2` (`PRODUCT_ID`,`STORE_ID`),
  KEY `IX_CATALOG_STORE_PRODUCT1` (`STORE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_subscribe`utf8_unicode_ci	;
CREATE TABLE `b_catalog_subscribe` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DATE_FROM` datetime NOT NULL,
  `DATE_TO` datetime DEFAULT NULL,
  `USER_CONTACT` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CONTACT_TYPE` smallint(5) unsigned NOT NULL,
  `USER_ID` int(10) unsigned DEFAULT NULL,
  `ITEM_ID` int(10) unsigned NOT NULL,
  `NEED_SENDING` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_CAT_SUB_USER_CONTACT` (`USER_CONTACT`),
  KEY `IX_CAT_SUB_USER_ID` (`USER_ID`),
  KEY `IX_CAT_SUB_ITEM_ID` (`ITEM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_subscribe_access`utf8_unicode_ci	;
CREATE TABLE `b_catalog_subscribe_access` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DATE_FROM` datetime NOT NULL,
  `USER_CONTACT` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TOKEN` char(6) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_CAT_SUB_ACS_USER_CONTACT` (`USER_CONTACT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_catalog_vat`utf8_unicode_ci	;
CREATE TABLE `b_catalog_vat` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `C_SORT` int(18) NOT NULL DEFAULT '100',
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `RATE` decimal(18,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`ID`),
  KEY `IX_CAT_VAT_ACTIVE` (`ACTIVE`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_catalog_vat`utf8_unicode_ci	;
INSERT INTO `b_catalog_vat` VALUES 
(1,'2016-10-18 09:08:07','Y',100,'Без НДС',0.00),
(2,'2016-10-18 09:08:07','Y',200,'НДС 18%',18.00)	;
#	TC`b_catalog_viewed_product`utf8_unicode_ci	;
CREATE TABLE `b_catalog_viewed_product` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FUSER_ID` int(11) NOT NULL,
  `DATE_VISIT` datetime NOT NULL,
  `PRODUCT_ID` int(11) NOT NULL,
  `ELEMENT_ID` int(11) NOT NULL DEFAULT '0',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `VIEW_COUNT` int(11) NOT NULL DEFAULT '1',
  `RECOMMENDATION` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_CAT_V_PR_FUSER_ID` (`FUSER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_checklist`utf8_unicode_ci	;
CREATE TABLE `b_checklist` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DATE_CREATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TESTER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COMPANY_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PICTURE` int(11) DEFAULT NULL,
  `TOTAL` int(11) DEFAULT NULL,
  `SUCCESS` int(11) DEFAULT NULL,
  `FAILED` int(11) DEFAULT NULL,
  `PENDING` int(11) DEFAULT NULL,
  `SKIP` int(11) DEFAULT NULL,
  `STATE` longtext COLLATE utf8_unicode_ci,
  `REPORT_COMMENT` text COLLATE utf8_unicode_ci,
  `REPORT` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `EMAIL` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PHONE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SENDED_TO_BITRIX` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `HIDDEN` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_clouds_file_bucket`utf8_unicode_ci	;
CREATE TABLE `b_clouds_file_bucket` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `SORT` int(11) DEFAULT '500',
  `READ_ONLY` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `SERVICE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BUCKET` varchar(63) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOCATION` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CNAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILE_COUNT` int(11) DEFAULT '0',
  `FILE_SIZE` float DEFAULT '0',
  `LAST_FILE_ID` int(11) DEFAULT NULL,
  `PREFIX` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SETTINGS` text COLLATE utf8_unicode_ci,
  `FILE_RULES` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_clouds_file_resize`utf8_unicode_ci	;
CREATE TABLE `b_clouds_file_resize` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ERROR_CODE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `FILE_ID` int(11) DEFAULT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci,
  `FROM_PATH` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TO_PATH` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_file_resize_ts` (`TIMESTAMP_X`),
  KEY `ix_b_file_resize_path` (`TO_PATH`(100)),
  KEY `ix_b_file_resize_file` (`FILE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_clouds_file_upload`utf8_unicode_ci	;
CREATE TABLE `b_clouds_file_upload` (
  `ID` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `FILE_PATH` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `FILE_SIZE` int(11) DEFAULT NULL,
  `TMP_FILE` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BUCKET_ID` int(11) NOT NULL,
  `PART_SIZE` int(11) NOT NULL,
  `PART_NO` int(11) NOT NULL,
  `PART_FAIL_COUNTER` int(11) NOT NULL,
  `NEXT_STEP` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_component_params`utf8_unicode_ci	;
CREATE TABLE `b_component_params` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `COMPONENT_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TEMPLATE_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REAL_PATH` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SEF_MODE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SEF_FOLDER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `START_CHAR` int(11) NOT NULL,
  `END_CHAR` int(11) NOT NULL,
  `PARAMETERS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `ix_comp_params_name` (`COMPONENT_NAME`),
  KEY `ix_comp_params_path` (`SITE_ID`,`REAL_PATH`),
  KEY `ix_comp_params_sname` (`SITE_ID`,`COMPONENT_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_conv_context`utf8_unicode_ci	;
CREATE TABLE `b_conv_context` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SNAPSHOT` char(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_B_CONV_CONTEXT_SNAPSHOT` (`SNAPSHOT`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_conv_context`utf8_unicode_ci	;
INSERT INTO `b_conv_context` VALUES 
(1,'13711320167b7d48ecada5db836b3c4eb6a6fa7ea7e419c821efc56901c13a3f')	;
#	TC`b_conv_context_attribute`utf8_unicode_ci	;
CREATE TABLE `b_conv_context_attribute` (
  `CONTEXT_ID` int(10) unsigned NOT NULL,
  `NAME` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`CONTEXT_ID`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_conv_context_attribute`utf8_unicode_ci	;
INSERT INTO `b_conv_context_attribute` VALUES 
(1,'conversion_browser','chrome'),
(1,'conversion_device_desktop',''),
(1,'conversion_operating_system','windows'),
(1,'conversion_site','s1')	;
#	TC`b_conv_context_counter_day`utf8_unicode_ci	;
CREATE TABLE `b_conv_context_counter_day` (
  `DAY` date NOT NULL,
  `CONTEXT_ID` int(10) unsigned NOT NULL,
  `NAME` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` float NOT NULL,
  PRIMARY KEY (`DAY`,`CONTEXT_ID`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_conv_context_counter_day`utf8_unicode_ci	;
INSERT INTO `b_conv_context_counter_day` VALUES 
('2016-10-18',1,'conversion_visit_day',1)	;
#	TC`b_conv_context_entity_item`utf8_unicode_ci	;
CREATE TABLE `b_conv_context_entity_item` (
  `ENTITY` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ITEM` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `CONTEXT_ID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ENTITY`,`ITEM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_counter_data`utf8_unicode_ci	;
CREATE TABLE `b_counter_data` (
  `ID` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `TYPE` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `DATA` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_culture`utf8_unicode_ci	;
CREATE TABLE `b_culture` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_DATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_DATETIME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WEEK_START` int(1) DEFAULT '1',
  `CHARSET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DIRECTION` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_culture`utf8_unicode_ci	;
INSERT INTO `b_culture` VALUES 
(1,'ru','ru','DD.MM.YYYY','DD.MM.YYYY HH:MI:SS','#NAME# #LAST_NAME#',1,'UTF-8','Y'),
(2,'en','en','MM/DD/YYYY','MM/DD/YYYY H:MI:SS T','#NAME# #LAST_NAME#',0,'UTF-8','Y')	;
#	TC`b_event`utf8_unicode_ci	;
CREATE TABLE `b_event` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `EVENT_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE_ID` int(18) DEFAULT NULL,
  `LID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `C_FIELDS` longtext COLLATE utf8_unicode_ci,
  `DATE_INSERT` datetime DEFAULT NULL,
  `DATE_EXEC` datetime DEFAULT NULL,
  `SUCCESS_EXEC` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DUPLICATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `ix_success` (`SUCCESS_EXEC`),
  KEY `ix_b_event_date_exec` (`DATE_EXEC`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_event_attachment`utf8_unicode_ci	;
CREATE TABLE `b_event_attachment` (
  `EVENT_ID` int(18) NOT NULL,
  `FILE_ID` int(18) NOT NULL,
  `IS_FILE_COPIED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`EVENT_ID`,`FILE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_event_log`utf8_unicode_ci	;
CREATE TABLE `b_event_log` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SEVERITY` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `AUDIT_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ITEM_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `REMOTE_ADDR` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_AGENT` text COLLATE utf8_unicode_ci,
  `REQUEST_URI` text COLLATE utf8_unicode_ci,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_ID` int(18) DEFAULT NULL,
  `GUEST_ID` int(18) DEFAULT NULL,
  `DESCRIPTION` mediumtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `ix_b_event_log_time` (`TIMESTAMP_X`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_event_message`utf8_unicode_ci	;
CREATE TABLE `b_event_message` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `EVENT_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `EMAIL_FROM` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#EMAIL_FROM#',
  `EMAIL_TO` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#EMAIL_TO#',
  `SUBJECT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MESSAGE` longtext COLLATE utf8_unicode_ci,
  `MESSAGE_PHP` longtext COLLATE utf8_unicode_ci,
  `BODY_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `BCC` text COLLATE utf8_unicode_ci,
  `REPLY_TO` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CC` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IN_REPLY_TO` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRIORITY` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD1_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD1_VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD2_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD2_VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SITE_TEMPLATE_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ADDITIONAL_FIELD` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `ix_b_event_message_name` (`EVENT_NAME`(50))
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_event_message`utf8_unicode_ci	;
INSERT INTO `b_event_message` VALUES 
(1,'2016-10-18 07:58:52','NEW_USER','s1','Y','#DEFAULT_EMAIL_FROM#','#DEFAULT_EMAIL_FROM#','#SITE_NAME#: Зарегистрировался новый пользователь','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nНа сайте #SERVER_NAME# успешно зарегистрирован новый пользователь.\n\nДанные пользователя:\nID пользователя: #USER_ID#\n\nИмя: #NAME#\nФамилия: #LAST_NAME#\nE-Mail: #EMAIL#\n\nLogin: #LOGIN#\n\nПисьмо сгенерировано автоматически.','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nНа сайте <?=$arParams[\"SERVER_NAME\"];?> успешно зарегистрирован новый пользователь.\n\nДанные пользователя:\nID пользователя: <?=$arParams[\"USER_ID\"];?>\n\n\nИмя: <?=$arParams[\"NAME\"];?>\n\nФамилия: <?=$arParams[\"LAST_NAME\"];?>\n\nE-Mail: <?=$arParams[\"EMAIL\"];?>\n\n\nLogin: <?=$arParams[\"LOGIN\"];?>\n\n\nПисьмо сгенерировано автоматически.','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(2,'2016-10-18 07:58:52','USER_INFO','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL#','#SITE_NAME#: Регистрационная информация','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n#NAME# #LAST_NAME#,\n\n#MESSAGE#\n\nВаша регистрационная информация:\n\nID пользователя: #USER_ID#\nСтатус профиля: #STATUS#\nLogin: #LOGIN#\n\nВы можете изменить пароль, перейдя по следующей ссылке:\nhttp://#SERVER_NAME#/auth/index.php?change_password=yes&lang=ru&USER_CHECKWORD=#CHECKWORD#&USER_LOGIN=#URL_LOGIN#\n\nСообщение сгенерировано автоматически.','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n<?=$arParams[\"NAME\"];?> <?=$arParams[\"LAST_NAME\"];?>,\n\n<?=$arParams[\"MESSAGE\"];?>\n\n\nВаша регистрационная информация:\n\nID пользователя: <?=$arParams[\"USER_ID\"];?>\n\nСтатус профиля: <?=$arParams[\"STATUS\"];?>\n\nLogin: <?=$arParams[\"LOGIN\"];?>\n\n\nВы можете изменить пароль, перейдя по следующей ссылке:\nhttp://<?=$arParams[\"SERVER_NAME\"];?>/auth/index.php?change_password=yes&lang=ru&USER_CHECKWORD=<?=$arParams[\"CHECKWORD\"];?>&USER_LOGIN=<?=$arParams[\"URL_LOGIN\"];?>\n\n\nСообщение сгенерировано автоматически.','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(3,'2016-10-18 07:58:52','USER_PASS_REQUEST','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL#','#SITE_NAME#: Запрос на смену пароля','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n#NAME# #LAST_NAME#,\n\n#MESSAGE#\n\nДля смены пароля перейдите по следующей ссылке:\nhttp://#SERVER_NAME#/auth/index.php?change_password=yes&lang=ru&USER_CHECKWORD=#CHECKWORD#&USER_LOGIN=#URL_LOGIN#\n\nВаша регистрационная информация:\n\nID пользователя: #USER_ID#\nСтатус профиля: #STATUS#\nLogin: #LOGIN#\n\nСообщение сгенерировано автоматически.','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n<?=$arParams[\"NAME\"];?> <?=$arParams[\"LAST_NAME\"];?>,\n\n<?=$arParams[\"MESSAGE\"];?>\n\n\nДля смены пароля перейдите по следующей ссылке:\nhttp://<?=$arParams[\"SERVER_NAME\"];?>/auth/index.php?change_password=yes&lang=ru&USER_CHECKWORD=<?=$arParams[\"CHECKWORD\"];?>&USER_LOGIN=<?=$arParams[\"URL_LOGIN\"];?>\n\n\nВаша регистрационная информация:\n\nID пользователя: <?=$arParams[\"USER_ID\"];?>\n\nСтатус профиля: <?=$arParams[\"STATUS\"];?>\n\nLogin: <?=$arParams[\"LOGIN\"];?>\n\n\nСообщение сгенерировано автоматически.','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(4,'2016-10-18 07:58:52','USER_PASS_CHANGED','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL#','#SITE_NAME#: Подтверждение смены пароля','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n#NAME# #LAST_NAME#,\n\n#MESSAGE#\n\nВаша регистрационная информация:\n\nID пользователя: #USER_ID#\nСтатус профиля: #STATUS#\nLogin: #LOGIN#\n\nСообщение сгенерировано автоматически.','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n<?=$arParams[\"NAME\"];?> <?=$arParams[\"LAST_NAME\"];?>,\n\n<?=$arParams[\"MESSAGE\"];?>\n\n\nВаша регистрационная информация:\n\nID пользователя: <?=$arParams[\"USER_ID\"];?>\n\nСтатус профиля: <?=$arParams[\"STATUS\"];?>\n\nLogin: <?=$arParams[\"LOGIN\"];?>\n\n\nСообщение сгенерировано автоматически.','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(5,'2016-10-18 07:58:52','NEW_USER_CONFIRM','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL#','#SITE_NAME#: Подтверждение регистрации нового пользователя','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nЗдравствуйте,\n\nВы получили это сообщение, так как ваш адрес был использован при регистрации нового пользователя на сервере #SERVER_NAME#.\n\nВаш код для подтверждения регистрации: #CONFIRM_CODE#\n\nДля подтверждения регистрации перейдите по следующей ссылке:\nhttp://#SERVER_NAME#/auth/index.php?confirm_registration=yes&confirm_user_id=#USER_ID#&confirm_code=#CONFIRM_CODE#\n\nВы также можете ввести код для подтверждения регистрации на странице:\nhttp://#SERVER_NAME#/auth/index.php?confirm_registration=yes&confirm_user_id=#USER_ID#\n\nВнимание! Ваш профиль не будет активным, пока вы не подтвердите свою регистрацию.\n\n---------------------------------------------------------------------\n\nСообщение сгенерировано автоматически.','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nЗдравствуйте,\n\nВы получили это сообщение, так как ваш адрес был использован при регистрации нового пользователя на сервере <?=$arParams[\"SERVER_NAME\"];?>.\n\nВаш код для подтверждения регистрации: <?=$arParams[\"CONFIRM_CODE\"];?>\n\n\nДля подтверждения регистрации перейдите по следующей ссылке:\nhttp://<?=$arParams[\"SERVER_NAME\"];?>/auth/index.php?confirm_registration=yes&confirm_user_id=<?=$arParams[\"USER_ID\"];?>&confirm_code=<?=$arParams[\"CONFIRM_CODE\"];?>\n\n\nВы также можете ввести код для подтверждения регистрации на странице:\nhttp://<?=$arParams[\"SERVER_NAME\"];?>/auth/index.php?confirm_registration=yes&confirm_user_id=<?=$arParams[\"USER_ID\"];?>\n\n\nВнимание! Ваш профиль не будет активным, пока вы не подтвердите свою регистрацию.\n\n---------------------------------------------------------------------\n\nСообщение сгенерировано автоматически.','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(6,'2016-10-18 07:58:52','USER_INVITE','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL#','#SITE_NAME#: Приглашение на сайт','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\nЗдравствуйте, #NAME# #LAST_NAME#!\n\nАдминистратором сайта вы добавлены в число зарегистрированных пользователей.\n\nПриглашаем Вас на наш сайт.\n\nВаша регистрационная информация:\n\nID пользователя: #ID#\nLogin: #LOGIN#\n\nРекомендуем вам сменить установленный автоматически пароль.\n\nДля смены пароля перейдите по следующей ссылке:\nhttp://#SERVER_NAME#/auth.php?change_password=yes&USER_LOGIN=#URL_LOGIN#&USER_CHECKWORD=#CHECKWORD#\n','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\nЗдравствуйте, <?=$arParams[\"NAME\"];?> <?=$arParams[\"LAST_NAME\"];?>!\n\nАдминистратором сайта вы добавлены в число зарегистрированных пользователей.\n\nПриглашаем Вас на наш сайт.\n\nВаша регистрационная информация:\n\nID пользователя: <?=$arParams[\"ID\"];?>\n\nLogin: <?=$arParams[\"LOGIN\"];?>\n\n\nРекомендуем вам сменить установленный автоматически пароль.\n\nДля смены пароля перейдите по следующей ссылке:\nhttp://<?=$arParams[\"SERVER_NAME\"];?>/auth.php?change_password=yes&USER_LOGIN=<?=$arParams[\"URL_LOGIN\"];?>&USER_CHECKWORD=<?=$arParams[\"CHECKWORD\"];?>\n\n','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(7,'2016-10-18 07:58:52','FEEDBACK_FORM','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: Сообщение из формы обратной связи','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nВам было отправлено сообщение через форму обратной связи\n\nАвтор: #AUTHOR#\nE-mail автора: #AUTHOR_EMAIL#\n\nТекст сообщения:\n#TEXT#\n\nСообщение сгенерировано автоматически.','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nВам было отправлено сообщение через форму обратной связи\n\nАвтор: <?=$arParams[\"AUTHOR\"];?>\n\nE-mail автора: <?=$arParams[\"AUTHOR_EMAIL\"];?>\n\n\nТекст сообщения:\n<?=$arParams[\"TEXT\"];?>\n\n\nСообщение сгенерировано автоматически.','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(8,'2016-10-18 07:59:56','NEW_BLOG_MESSAGE','s1','Y','#EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: [B] #BLOG_NAME# : #MESSAGE_TITLE#','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nНовое сообщение в блоге \"#BLOG_NAME#\"\n\nТема:\n#MESSAGE_TITLE#\n\nАвтор: #AUTHOR#\nДата: #MESSAGE_DATE#\n\nТекст сообщения:\n#MESSAGE_TEXT#\n\nАдрес сообщения:\n#MESSAGE_PATH#\n\nСообщение сгенерировано автоматически.','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nНовое сообщение в блоге \"<?=$arParams[\"BLOG_NAME\"];?>\"\n\nТема:\n<?=$arParams[\"MESSAGE_TITLE\"];?>\n\n\nАвтор: <?=$arParams[\"AUTHOR\"];?>\n\nДата: <?=$arParams[\"MESSAGE_DATE\"];?>\n\n\nТекст сообщения:\n<?=$arParams[\"MESSAGE_TEXT\"];?>\n\n\nАдрес сообщения:\n<?=$arParams[\"MESSAGE_PATH\"];?>\n\n\nСообщение сгенерировано автоматически.','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(9,'2016-10-18 07:59:56','NEW_BLOG_COMMENT','s1','Y','#EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: [B] #MESSAGE_TITLE# : #COMMENT_TITLE#','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nНовый комментарий в блоге \"#BLOG_NAME#\" на сообщение \"#MESSAGE_TITLE#\"\n\nТема:\n#COMMENT_TITLE#\nАвтор: #AUTHOR#\nДата: #COMMENT_DATE#\n\nТекст сообщения:\n#COMMENT_TEXT#\n\nАдрес сообщения:\n#COMMENT_PATH#\n\nСообщение сгенерировано автоматически.','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nНовый комментарий в блоге \"<?=$arParams[\"BLOG_NAME\"];?>\" на сообщение \"<?=$arParams[\"MESSAGE_TITLE\"];?>\"\n\nТема:\n<?=$arParams[\"COMMENT_TITLE\"];?>\n\nАвтор: <?=$arParams[\"AUTHOR\"];?>\n\nДата: <?=$arParams[\"COMMENT_DATE\"];?>\n\n\nТекст сообщения:\n<?=$arParams[\"COMMENT_TEXT\"];?>\n\n\nАдрес сообщения:\n<?=$arParams[\"COMMENT_PATH\"];?>\n\n\nСообщение сгенерировано автоматически.','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(10,'2016-10-18 07:59:56','NEW_BLOG_COMMENT2COMMENT','s1','Y','#EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: [B] #MESSAGE_TITLE# : #COMMENT_TITLE#','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nНовый комментарий на ваш комментарий в блоге \"#BLOG_NAME#\" на сообщение \"#MESSAGE_TITLE#\".\n\nТема:\n#COMMENT_TITLE#\nАвтор: #AUTHOR#\nДата: #COMMENT_DATE#\n\nТекст сообщения:\n#COMMENT_TEXT#\n\nАдрес сообщения:\n#COMMENT_PATH#\n\nСообщение сгенерировано автоматически.','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nНовый комментарий на ваш комментарий в блоге \"<?=$arParams[\"BLOG_NAME\"];?>\" на сообщение \"<?=$arParams[\"MESSAGE_TITLE\"];?>\".\n\nТема:\n<?=$arParams[\"COMMENT_TITLE\"];?>\n\nАвтор: <?=$arParams[\"AUTHOR\"];?>\n\nДата: <?=$arParams[\"COMMENT_DATE\"];?>\n\n\nТекст сообщения:\n<?=$arParams[\"COMMENT_TEXT\"];?>\n\n\nАдрес сообщения:\n<?=$arParams[\"COMMENT_PATH\"];?>\n\n\nСообщение сгенерировано автоматически.','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(11,'2016-10-18 07:59:56','NEW_BLOG_COMMENT_WITHOUT_TITLE','s1','Y','#EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: [B] #MESSAGE_TITLE#','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nНовый комментарий в блоге \"#BLOG_NAME#\" на сообщение \"#MESSAGE_TITLE#\"\n\nАвтор: #AUTHOR#\nДата: #COMMENT_DATE#\n\nТекст сообщения:\n#COMMENT_TEXT#\n\nАдрес сообщения:\n#COMMENT_PATH#\n\nСообщение сгенерировано автоматически.','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nНовый комментарий в блоге \"<?=$arParams[\"BLOG_NAME\"];?>\" на сообщение \"<?=$arParams[\"MESSAGE_TITLE\"];?>\"\n\nАвтор: <?=$arParams[\"AUTHOR\"];?>\n\nДата: <?=$arParams[\"COMMENT_DATE\"];?>\n\n\nТекст сообщения:\n<?=$arParams[\"COMMENT_TEXT\"];?>\n\n\nАдрес сообщения:\n<?=$arParams[\"COMMENT_PATH\"];?>\n\n\nСообщение сгенерировано автоматически.','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(12,'2016-10-18 07:59:56','NEW_BLOG_COMMENT2COMMENT_WITHOUT_TITLE','s1','Y','#EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: [B] #MESSAGE_TITLE#','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nНовый комментарий на ваш комментарий в блоге \"#BLOG_NAME#\" на сообщение \"#MESSAGE_TITLE#\".\n\nАвтор: #AUTHOR#\nДата: #COMMENT_DATE#\n\nТекст сообщения:\n#COMMENT_TEXT#\n\nАдрес сообщения:\n#COMMENT_PATH#\n\nСообщение сгенерировано автоматически.\n','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nНовый комментарий на ваш комментарий в блоге \"<?=$arParams[\"BLOG_NAME\"];?>\" на сообщение \"<?=$arParams[\"MESSAGE_TITLE\"];?>\".\n\nАвтор: <?=$arParams[\"AUTHOR\"];?>\n\nДата: <?=$arParams[\"COMMENT_DATE\"];?>\n\n\nТекст сообщения:\n<?=$arParams[\"COMMENT_TEXT\"];?>\n\n\nАдрес сообщения:\n<?=$arParams[\"COMMENT_PATH\"];?>\n\n\nСообщение сгенерировано автоматически.\n','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(13,'2016-10-18 07:59:56','BLOG_YOUR_BLOG_TO_USER','s1','Y','#EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: [B] Ваш блог \"#BLOG_NAME#\" был добавлен в друзья к #USER#','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nВаш блог \"#BLOG_NAME#\" был добавлен в друзья к #USER#.\n\nПрофиль пользователя: #USER_URL#\n\nАдрес вашего блога: #BLOG_ADR#\n\nСообщение сгенерировано автоматически.\n','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nВаш блог \"<?=$arParams[\"BLOG_NAME\"];?>\" был добавлен в друзья к <?=$arParams[\"USER\"];?>.\n\nПрофиль пользователя: <?=$arParams[\"USER_URL\"];?>\n\n\nАдрес вашего блога: <?=$arParams[\"BLOG_ADR\"];?>\n\n\nСообщение сгенерировано автоматически.\n','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(14,'2016-10-18 07:59:56','BLOG_YOU_TO_BLOG','s1','Y','#EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: [B] Вы были добавлены в друзья блога \"#BLOG_NAME#\"','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nВы были добавлены в друзья блога \"#BLOG_NAME#\".\n\nАдрес блога: #BLOG_ADR#\n\nВаш профиль: #USER_URL#\n\nСообщение сгенерировано автоматически.\n','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nВы были добавлены в друзья блога \"<?=$arParams[\"BLOG_NAME\"];?>\".\n\nАдрес блога: <?=$arParams[\"BLOG_ADR\"];?>\n\n\nВаш профиль: <?=$arParams[\"USER_URL\"];?>\n\n\nСообщение сгенерировано автоматически.\n','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(15,'2016-10-18 07:59:56','BLOG_BLOG_TO_YOU','s1','Y','#EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: [B] К вам в друзья был добавлен блог \"#BLOG_NAME#\"','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nК вам в друзья был добавлен блог \"#BLOG_NAME#\".\n\nАдрес блога: #BLOG_ADR#\n\nВаш профиль: #USER_URL#\n\nСообщение сгенерировано автоматически.\n','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nК вам в друзья был добавлен блог \"<?=$arParams[\"BLOG_NAME\"];?>\".\n\nАдрес блога: <?=$arParams[\"BLOG_ADR\"];?>\n\n\nВаш профиль: <?=$arParams[\"USER_URL\"];?>\n\n\nСообщение сгенерировано автоматически.\n','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(16,'2016-10-18 07:59:56','BLOG_USER_TO_YOUR_BLOG','s1','Y','#EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: [B] В ваш блог \"#BLOG_NAME#\" был добавлен друг #USER#','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nВ ваш блог \"#BLOG_NAME#\" был добавлен друг #USER#.\n\nПрофиль пользователя: #USER_URL#\n\nАдрес вашего блога: #BLOG_ADR#\n\nСообщение сгенерировано автоматически.\n','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nВ ваш блог \"<?=$arParams[\"BLOG_NAME\"];?>\" был добавлен друг <?=$arParams[\"USER\"];?>.\n\nПрофиль пользователя: <?=$arParams[\"USER_URL\"];?>\n\n\nАдрес вашего блога: <?=$arParams[\"BLOG_ADR\"];?>\n\n\nСообщение сгенерировано автоматически.\n','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(17,'2016-10-18 07:59:56','BLOG_SONET_NEW_POST','s1','Y','#EMAIL_FROM#','#EMAIL_TO#','#POST_TITLE#','<?EventMessageThemeCompiler::includeComponent(\"bitrix:socialnetwork.blog.post.mail\",\"\",Array(\"EMAIL_TO\" => \"{#EMAIL_TO#}\",\"RECIPIENT_ID\" => \"{#RECIPIENT_ID#}\",\"POST_ID\" => \"{#POST_ID#}\",\"URL\" => \"{#URL#}\"));?>','<?EventMessageThemeCompiler::includeComponent(\"bitrix:socialnetwork.blog.post.mail\",\"\",Array(\"EMAIL_TO\" => \"{$arParams[\'EMAIL_TO\']}\",\"RECIPIENT_ID\" => \"{$arParams[\'RECIPIENT_ID\']}\",\"POST_ID\" => \"{$arParams[\'POST_ID\']}\",\"URL\" => \"{$arParams[\'URL\']}\"));?>','html',\N,\N,\N,\N,\N,\N,\N,\N,\N,'mail_user',\N),
(18,'2016-10-18 07:59:56','BLOG_SONET_NEW_COMMENT','s1','Y','#EMAIL_FROM#','#EMAIL_TO#','Re: #POST_TITLE#','<?EventMessageThemeCompiler::includeComponent(\"bitrix:socialnetwork.blog.post.comment.mail\",\"\",Array(\"COMMENT_ID\" => \"{#COMMENT_ID#}\",\"RECIPIENT_ID\" => \"{#RECIPIENT_ID#}\",\"EMAIL_TO\" => \"{#EMAIL_TO#}\",\"POST_ID\" => \"{#POST_ID#}\",\"URL\" => \"{#URL#}\"));?>','<?EventMessageThemeCompiler::includeComponent(\"bitrix:socialnetwork.blog.post.comment.mail\",\"\",Array(\"COMMENT_ID\" => \"{$arParams[\'COMMENT_ID\']}\",\"RECIPIENT_ID\" => \"{$arParams[\'RECIPIENT_ID\']}\",\"EMAIL_TO\" => \"{$arParams[\'EMAIL_TO\']}\",\"POST_ID\" => \"{$arParams[\'POST_ID\']}\",\"URL\" => \"{$arParams[\'URL\']}\"));?>','html',\N,\N,\N,\N,\N,\N,\N,\N,\N,'mail_user',\N),
(19,'2016-10-18 07:59:56','BLOG_SONET_POST_SHARE','s1','Y','#EMAIL_FROM#','#EMAIL_TO#','#POST_TITLE#','<?EventMessageThemeCompiler::includeComponent(\"bitrix:socialnetwork.blog.post_share.mail\",\"\",Array(\"EMAIL_TO\" => \"{#EMAIL_TO#}\",\"RECIPIENT_ID\" => \"{#RECIPIENT_ID#}\",\"POST_ID\" => \"{#POST_ID#}\",\"URL\" => \"{#URL#}\"));?>','<?EventMessageThemeCompiler::includeComponent(\"bitrix:socialnetwork.blog.post_share.mail\",\"\",Array(\"EMAIL_TO\" => \"{$arParams[\'EMAIL_TO\']}\",\"RECIPIENT_ID\" => \"{$arParams[\'RECIPIENT_ID\']}\",\"POST_ID\" => \"{$arParams[\'POST_ID\']}\",\"URL\" => \"{$arParams[\'URL\']}\"));?>','html',\N,\N,\N,\N,\N,\N,\N,\N,\N,'mail_user',\N),
(20,'2016-10-18 07:59:56','BLOG_POST_BROADCAST','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: #MESSAGE_TITLE#','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nНа сайте добавлено новое сообщение.\n\nТема:\n#MESSAGE_TITLE#\n\nАвтор: #AUTHOR#\n\nТекст сообщения:\n#MESSAGE_TEXT#\n\nАдрес сообщения:\n#MESSAGE_PATH#\n\nСообщение сгенерировано автоматически.','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nНа сайте добавлено новое сообщение.\n\nТема:\n<?=$arParams[\"MESSAGE_TITLE\"];?>\n\n\nАвтор: <?=$arParams[\"AUTHOR\"];?>\n\n\nТекст сообщения:\n<?=$arParams[\"MESSAGE_TEXT\"];?>\n\n\nАдрес сообщения:\n<?=$arParams[\"MESSAGE_PATH\"];?>\n\n\nСообщение сгенерировано автоматически.','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(21,'2016-10-18 08:00:26','CATALOG_PRODUCT_SUBSCRIBE_LIST_CONFIRM','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: Код подтверждения','\n			<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n			<html xmlns=\"http://www.w3.org/1999/xhtml\">\n			<head>\n				<style>\n					body\n					{\n						font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n						font-size: 14px;\n						color: #000;\n					}\n				</style>\n			</head>\n			<body>\n			<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; \n				border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n				<tr>\n					<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; \n						padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n						<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n							<tr>\n								<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: \n								center; font-size: 26px; color: #0b3961;\">Информационное сообщение сайта #SITE_NAME#</td>\n							</tr>\n							<tr>\n								<td bgcolor=\"#bad3df\" height=\"11\"></td>\n							</tr>\n						</table>\n					</td>\n				</tr>\n				<tr>\n					<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; \n						padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n						<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Уважаемый, #USER_NAME#!</p>\n						<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">\nВы получили это сообщение, так как на ваш адрес был запрошен код подтверждения для доступа к подпискам сайта #SERVER_NAME#. <br><br> \nВаш код для подтверждения подписки: #TOKEN# <br><br> \nДля получения доступа к подпискам перейдите по следующей ссылке: #TOKEN_URL# <br><br>\nВы также можете ввести код на странице: #LIST_SUBSCRIBES# <br><br>\nПисьмо содержит информацию для авторизации.<br>\nИспользуя код подтверждения, вы cможете получить доступ к списку подписок.<br>\nНе отвечайте на письмо, оно сформировано автоматически.<br><br>\nСпасибо, что вы с нами!<br>\n</p>\n					</td>\n				</tr>\n				<tr>\n					<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; \n						padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n						<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; \n							line-height:21px;\">С уважением, администрация \n							<a href=\"http://#SERVER_NAME#\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n							E-mail: <a href=\"mailto:#DEFAULT_EMAIL_FROM#\" style=\"color:#2e6eb6;\">#DEFAULT_EMAIL_FROM#</a>\n							\n						</p>\n					</td>\n				</tr>\n			</table>\n			</body>\n			</html>\n		','\n			<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n			<html xmlns=\"http://www.w3.org/1999/xhtml\">\n			<head>\n				<style>\n					body\n					{\n						font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n						font-size: 14px;\n						color: #000;\n					}\n				</style>\n			</head>\n			<body>\n			<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; \n				border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n				<tr>\n					<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; \n						padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n						<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n							<tr>\n								<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: \n								center; font-size: 26px; color: #0b3961;\">Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?></td>\n							</tr>\n							<tr>\n								<td bgcolor=\"#bad3df\" height=\"11\"></td>\n							</tr>\n						</table>\n					</td>\n				</tr>\n				<tr>\n					<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; \n						padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n						<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Уважаемый, <?=$arParams[\"USER_NAME\"];?>!</p>\n						<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">\nВы получили это сообщение, так как на ваш адрес был запрошен код подтверждения для доступа к подпискам сайта <?=$arParams[\"SERVER_NAME\"];?>. <br><br> \nВаш код для подтверждения подписки: <?=$arParams[\"TOKEN\"];?> <br><br> \nДля получения доступа к подпискам перейдите по следующей ссылке: <?=$arParams[\"TOKEN_URL\"];?> <br><br>\nВы также можете ввести код на странице: <?=$arParams[\"LIST_SUBSCRIBES\"];?> <br><br>\nПисьмо содержит информацию для авторизации.<br>\nИспользуя код подтверждения, вы cможете получить доступ к списку подписок.<br>\nНе отвечайте на письмо, оно сформировано автоматически.<br><br>\nСпасибо, что вы с нами!<br>\n</p>\n					</td>\n				</tr>\n				<tr>\n					<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; \n						padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n						<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; \n							line-height:21px;\">С уважением, администрация \n							<a href=\"http://<?=$arParams[\"SERVER_NAME\"];?>\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n							E-mail: <a href=\"mailto:<?=$arParams[\"DEFAULT_EMAIL_FROM\"];?>\" style=\"color:#2e6eb6;\"><?=$arParams[\"DEFAULT_EMAIL_FROM\"];?></a>\n							\n						</p>\n					</td>\n				</tr>\n			</table>\n			</body>\n			</html>\n		','html','#BCC#',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(22,'2016-10-18 08:00:26','CATALOG_PRODUCT_SUBSCRIBE_NOTIFY','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: Уведомление о поступлении товара','\n			<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n			<html xmlns=\"http://www.w3.org/1999/xhtml\">\n			<head>\n				<style>\n					body\n					{\n						font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n						font-size: 14px;\n						color: #000;\n					}\n				</style>\n			</head>\n			<body>\n			<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; \n				border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n				<tr>\n					<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; \n						padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n						<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n							<tr>\n								<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: \n								center; font-size: 26px; color: #0b3961;\">Уведомление о поступлении товара в магазин #SITE_NAME#</td>\n							</tr>\n							<tr>\n								<td bgcolor=\"#bad3df\" height=\"11\"></td>\n							</tr>\n						</table>\n					</td>\n				</tr>\n				<tr>\n					<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; \n						padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n						<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Уважаемый, #USER_NAME#!</p>\n						<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">\nТовар \"#NAME#\" (#PAGE_URL#) поступил на склад.<br><br>\nВы просили оповестить вас о поступление товара.<br><br>\nТовар поступил к нам в магазин, вы можете оформить заказ прямо сейчас: (#CHECKOUT_URL#)<br><br>\nНе отвечайте на письмо, оно сформировано автоматически.<br><br>\nСпасибо, что вы с нами!<br>\n</p>\n					</td>\n				</tr>\n				<tr>\n					<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; \n						padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n						<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; \n							line-height:21px;\">С уважением, администрация \n							<a href=\"http://#SERVER_NAME#\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n							E-mail: <a href=\"mailto:#DEFAULT_EMAIL_FROM#\" style=\"color:#2e6eb6;\">#DEFAULT_EMAIL_FROM#</a>\n							<br><a href=\"#UNSUBSCRIBE_URL#\">Отписаться</a>\n						</p>\n					</td>\n				</tr>\n			</table>\n			</body>\n			</html>\n		','\n			<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n			<html xmlns=\"http://www.w3.org/1999/xhtml\">\n			<head>\n				<style>\n					body\n					{\n						font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n						font-size: 14px;\n						color: #000;\n					}\n				</style>\n			</head>\n			<body>\n			<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; \n				border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n				<tr>\n					<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; \n						padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n						<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n							<tr>\n								<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: \n								center; font-size: 26px; color: #0b3961;\">Уведомление о поступлении товара в магазин <?=$arParams[\"SITE_NAME\"];?></td>\n							</tr>\n							<tr>\n								<td bgcolor=\"#bad3df\" height=\"11\"></td>\n							</tr>\n						</table>\n					</td>\n				</tr>\n				<tr>\n					<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; \n						padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n						<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Уважаемый, <?=$arParams[\"USER_NAME\"];?>!</p>\n						<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">\nТовар \"<?=$arParams[\"NAME\"];?>\" (<?=$arParams[\"PAGE_URL\"];?>) поступил на склад.<br><br>\nВы просили оповестить вас о поступление товара.<br><br>\nТовар поступил к нам в магазин, вы можете оформить заказ прямо сейчас: (<?=$arParams[\"CHECKOUT_URL\"];?>)<br><br>\nНе отвечайте на письмо, оно сформировано автоматически.<br><br>\nСпасибо, что вы с нами!<br>\n</p>\n					</td>\n				</tr>\n				<tr>\n					<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; \n						padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n						<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; \n							line-height:21px;\">С уважением, администрация \n							<a href=\"http://<?=$arParams[\"SERVER_NAME\"];?>\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n							E-mail: <a href=\"mailto:<?=$arParams[\"DEFAULT_EMAIL_FROM\"];?>\" style=\"color:#2e6eb6;\"><?=$arParams[\"DEFAULT_EMAIL_FROM\"];?></a>\n							<br><a href=\"<?=$arParams[\"UNSUBSCRIBE_URL\"];?>\">Отписаться</a>\n						</p>\n					</td>\n				</tr>\n			</table>\n			</body>\n			</html>\n		','html','#BCC#',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(23,'2016-10-18 08:00:26','CATALOG_PRODUCT_SUBSCRIBE_NOTIFY_REPEATED','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL_TO#','Уведомление о товаре в магазине #SITE_NAME#','\n			<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n			<html xmlns=\"http://www.w3.org/1999/xhtml\">\n			<head>\n				<style>\n					body\n					{\n						font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n						font-size: 14px;\n						color: #000;\n					}\n				</style>\n			</head>\n			<body>\n			<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; \n				border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n				<tr>\n					<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; \n						padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n						<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n							<tr>\n								<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: \n								center; font-size: 26px; color: #0b3961;\">Уведомление о товаре в магазине #SITE_NAME#</td>\n							</tr>\n							<tr>\n								<td bgcolor=\"#bad3df\" height=\"11\"></td>\n							</tr>\n						</table>\n					</td>\n				</tr>\n				<tr>\n					<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; \n						padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n						<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Уважаемый, #USER_NAME#!</p>\n						<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">\nТовар \"#NAME#\" (#PAGE_URL#) к сожалению снова закончился.<br><br>\nМы обязательно сообщим вам о поступлении товара.<br><br>\nНе отвечайте на письмо, оно сформировано автоматически.<br><br>\nСпасибо, что вы с нами!<br>\n</p>\n					</td>\n				</tr>\n				<tr>\n					<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; \n						padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n						<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; \n							line-height:21px;\">С уважением, администрация \n							<a href=\"http://#SERVER_NAME#\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n							E-mail: <a href=\"mailto:#DEFAULT_EMAIL_FROM#\" style=\"color:#2e6eb6;\">#DEFAULT_EMAIL_FROM#</a>\n							<br><a href=\"#UNSUBSCRIBE_URL#\">Отписаться</a>\n						</p>\n					</td>\n				</tr>\n			</table>\n			</body>\n			</html>\n		','\n			<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n			<html xmlns=\"http://www.w3.org/1999/xhtml\">\n			<head>\n				<style>\n					body\n					{\n						font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n						font-size: 14px;\n						color: #000;\n					}\n				</style>\n			</head>\n			<body>\n			<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; \n				border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n				<tr>\n					<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; \n						padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n						<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n							<tr>\n								<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: \n								center; font-size: 26px; color: #0b3961;\">Уведомление о товаре в магазине <?=$arParams[\"SITE_NAME\"];?></td>\n							</tr>\n							<tr>\n								<td bgcolor=\"#bad3df\" height=\"11\"></td>\n							</tr>\n						</table>\n					</td>\n				</tr>\n				<tr>\n					<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; \n						padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n						<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Уважаемый, <?=$arParams[\"USER_NAME\"];?>!</p>\n						<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">\nТовар \"<?=$arParams[\"NAME\"];?>\" (<?=$arParams[\"PAGE_URL\"];?>) к сожалению снова закончился.<br><br>\nМы обязательно сообщим вам о поступлении товара.<br><br>\nНе отвечайте на письмо, оно сформировано автоматически.<br><br>\nСпасибо, что вы с нами!<br>\n</p>\n					</td>\n				</tr>\n				<tr>\n					<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; \n						padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n						<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; \n							line-height:21px;\">С уважением, администрация \n							<a href=\"http://<?=$arParams[\"SERVER_NAME\"];?>\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n							E-mail: <a href=\"mailto:<?=$arParams[\"DEFAULT_EMAIL_FROM\"];?>\" style=\"color:#2e6eb6;\"><?=$arParams[\"DEFAULT_EMAIL_FROM\"];?></a>\n							<br><a href=\"<?=$arParams[\"UNSUBSCRIBE_URL\"];?>\">Отписаться</a>\n						</p>\n					</td>\n				</tr>\n			</table>\n			</body>\n			</html>\n		','html','#BCC#',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(24,'2016-10-18 08:01:14','NEW_FORUM_MESSAGE','s1','Y','#FROM_EMAIL#','#RECIPIENT#','#SITE_NAME#: [F] #TOPIC_TITLE# : #FORUM_NAME#','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nНовое сообщение на форуме #SERVER_NAME#.\n\nТема:\n#TOPIC_TITLE#\n\nАвтор: #AUTHOR#\nДата : #MESSAGE_DATE#\nТекст сообщения:\n\n#MESSAGE_TEXT#\n\nАдрес сообщения:\nhttp://#SERVER_NAME##PATH2FORUM#\n\nСообщение сгенерировано автоматически.\n','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nНовое сообщение на форуме <?=$arParams[\"SERVER_NAME\"];?>.\n\nТема:\n<?=$arParams[\"TOPIC_TITLE\"];?>\n\n\nАвтор: <?=$arParams[\"AUTHOR\"];?>\n\nДата : <?=$arParams[\"MESSAGE_DATE\"];?>\n\nТекст сообщения:\n\n<?=$arParams[\"MESSAGE_TEXT\"];?>\n\n\nАдрес сообщения:\nhttp://<?=$arParams[\"SERVER_NAME\"];?><?=$arParams[\"PATH2FORUM\"];?>\n\n\nСообщение сгенерировано автоматически.\n','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(25,'2016-10-18 08:01:14','NEW_FORUM_PRIV','s1','Y','#FROM_EMAIL#','#TO_EMAIL#','#SITE_NAME#: [private] #SUBJECT#','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nВы получили персональное сообщение с форума на сайте #SERVER_NAME#.\n\nТема: #SUBJECT#\n\nАвтор: #FROM_NAME# #FROM_EMAIL#\nДата : #MESSAGE_DATE#\nСообщение:\n\n#MESSAGE#\n\nСообщение сгенерировано автоматически.\n','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nВы получили персональное сообщение с форума на сайте <?=$arParams[\"SERVER_NAME\"];?>.\n\nТема: <?=$arParams[\"SUBJECT\"];?>\n\n\nАвтор: <?=$arParams[\"FROM_NAME\"];?> <?=$arParams[\"FROM_EMAIL\"];?>\n\nДата : <?=$arParams[\"MESSAGE_DATE\"];?>\n\nСообщение:\n\n<?=$arParams[\"MESSAGE\"];?>\n\n\nСообщение сгенерировано автоматически.\n','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(26,'2016-10-18 08:01:14','NEW_FORUM_PRIVATE_MESSAGE','s1','Y','#FROM_EMAIL#','#TO_EMAIL#','#SITE_NAME#: [private] #SUBJECT#','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nВы получили персональное сообщение с форума на сайте #SERVER_NAME#.\n\nТема: #SUBJECT#\n\nАвтор: #FROM_NAME#\nДата: #MESSAGE_DATE#\nСообщение:\n\n#MESSAGE#\n\nСсылка на сообщение: #MESSAGE_LINK#Сообщение сгенерировано автоматически.\n','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nВы получили персональное сообщение с форума на сайте <?=$arParams[\"SERVER_NAME\"];?>.\n\nТема: <?=$arParams[\"SUBJECT\"];?>\n\n\nАвтор: <?=$arParams[\"FROM_NAME\"];?>\n\nДата: <?=$arParams[\"MESSAGE_DATE\"];?>\n\nСообщение:\n\n<?=$arParams[\"MESSAGE\"];?>\n\n\nСсылка на сообщение: <?=$arParams[\"MESSAGE_LINK\"];?>Сообщение сгенерировано автоматически.\n','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(27,'2016-10-18 08:01:14','EDIT_FORUM_MESSAGE','s1','Y','#FROM_EMAIL#','#RECIPIENT#','#SITE_NAME#: [F] #TOPIC_TITLE# : #FORUM_NAME#','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nИзменение сообщения на форуме #SERVER_NAME#.\n\nТема:\n#TOPIC_TITLE#\n\nАвтор: #AUTHOR#\nДата : #MESSAGE_DATE#\nТекст сообщения:\n\n#MESSAGE_TEXT#\n\nАдрес сообщения:\nhttp://#SERVER_NAME##PATH2FORUM#\n\nСообщение сгенерировано автоматически.\n','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nИзменение сообщения на форуме <?=$arParams[\"SERVER_NAME\"];?>.\n\nТема:\n<?=$arParams[\"TOPIC_TITLE\"];?>\n\n\nАвтор: <?=$arParams[\"AUTHOR\"];?>\n\nДата : <?=$arParams[\"MESSAGE_DATE\"];?>\n\nТекст сообщения:\n\n<?=$arParams[\"MESSAGE_TEXT\"];?>\n\n\nАдрес сообщения:\nhttp://<?=$arParams[\"SERVER_NAME\"];?><?=$arParams[\"PATH2FORUM\"];?>\n\n\nСообщение сгенерировано автоматически.\n','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(28,'2016-10-18 08:01:14','FORUM_NEW_MESSAGE_MAIL','s1','Y','#FROM_EMAIL#','#RECIPIENT#','#TOPIC_TITLE#','#MESSAGE_TEXT#\n\n------------------------------------------  \nВы получили это сообщение, так как выподписаны на форум #FORUM_NAME#.\n\nОтветить на сообщение можно по электронной почте или через форму на сайте:\nhttp://#SERVER_NAME##PATH2FORUM#\n\nНаписать новое сообщение: #FORUM_EMAIL#\n\nАвтор сообщения: #AUTHOR#\n\nСообщение сгенерировано автоматически на сайте #SITE_NAME#.\n','<?=$arParams[\"MESSAGE_TEXT\"];?>\n\n\n------------------------------------------  \nВы получили это сообщение, так как выподписаны на форум <?=$arParams[\"FORUM_NAME\"];?>.\n\nОтветить на сообщение можно по электронной почте или через форму на сайте:\nhttp://<?=$arParams[\"SERVER_NAME\"];?><?=$arParams[\"PATH2FORUM\"];?>\n\n\nНаписать новое сообщение: <?=$arParams[\"FORUM_EMAIL\"];?>\n\n\nАвтор сообщения: <?=$arParams[\"AUTHOR\"];?>\n\n\nСообщение сгенерировано автоматически на сайте <?=$arParams[\"SITE_NAME\"];?>.\n','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(29,'2016-10-18 08:02:56','SALE_NEW_ORDER','s1','Y','#SALE_EMAIL#','#EMAIL#','#SITE_NAME#: Новый заказ N#ORDER_ID#','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Вами оформлен заказ в магазине #SITE_NAME#</td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Уважаемый #ORDER_USER#,</p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Ваш заказ номер #ORDER_ID# от #ORDER_DATE# принят.<br />\n<br />\nСтоимость заказа: #PRICE#.<br />\n<br />\nСостав заказа:<br />\n#ORDER_LIST#<br />\n<br />\nВы можете следить за выполнением своего заказа (на какой стадии выполнения он находится), войдя в Ваш персональный раздел сайта #SITE_NAME#.<br />\n<br />\nОбратите внимание, что для входа в этот раздел Вам необходимо будет ввести логин и пароль пользователя сайта #SITE_NAME#.<br />\n<br />\nДля того, чтобы аннулировать заказ, воспользуйтесь функцией отмены заказа, которая доступна в Вашем персональном разделе сайта #SITE_NAME#.<br />\n<br />\nПожалуйста, при обращении к администрации сайта #SITE_NAME# ОБЯЗАТЕЛЬНО указывайте номер Вашего заказа - #ORDER_ID#.<br />\n<br />\nСпасибо за покупку!<br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://#SERVER_NAME#\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:#SALE_EMAIL#\" style=\"color:#2e6eb6;\">#SALE_EMAIL#</a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Вами оформлен заказ в магазине <?=$arParams[\"SITE_NAME\"];?></td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Уважаемый <?=$arParams[\"ORDER_USER\"];?>,</p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Ваш заказ номер <?=$arParams[\"ORDER_ID\"];?> от <?=$arParams[\"ORDER_DATE\"];?> принят.<br />\n<br />\nСтоимость заказа: <?=$arParams[\"PRICE\"];?>.<br />\n<br />\nСостав заказа:<br />\n<?=$arParams[\"ORDER_LIST\"];?><br />\n<br />\nВы можете следить за выполнением своего заказа (на какой стадии выполнения он находится), войдя в Ваш персональный раздел сайта <?=$arParams[\"SITE_NAME\"];?>.<br />\n<br />\nОбратите внимание, что для входа в этот раздел Вам необходимо будет ввести логин и пароль пользователя сайта <?=$arParams[\"SITE_NAME\"];?>.<br />\n<br />\nДля того, чтобы аннулировать заказ, воспользуйтесь функцией отмены заказа, которая доступна в Вашем персональном разделе сайта <?=$arParams[\"SITE_NAME\"];?>.<br />\n<br />\nПожалуйста, при обращении к администрации сайта <?=$arParams[\"SITE_NAME\"];?> ОБЯЗАТЕЛЬНО указывайте номер Вашего заказа - <?=$arParams[\"ORDER_ID\"];?>.<br />\n<br />\nСпасибо за покупку!<br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://<?=$arParams[\"SERVER_NAME\"];?>\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:<?=$arParams[\"SALE_EMAIL\"];?>\" style=\"color:#2e6eb6;\"><?=$arParams[\"SALE_EMAIL\"];?></a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','html','#BCC#',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(30,'2016-10-18 08:02:56','SALE_ORDER_CANCEL','s1','Y','#SALE_EMAIL#','#EMAIL#','#SITE_NAME#: Отмена заказа N#ORDER_ID#','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">#SITE_NAME#: Отмена заказа N#ORDER_ID#</td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Заказ номер #ORDER_ID# от #ORDER_DATE# отменен.</p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">#ORDER_CANCEL_DESCRIPTION#<br />\n<br />\nДля получения подробной информации по заказу пройдите на сайт http://#SERVER_NAME#/personal/order/#ORDER_ACCOUNT_NUMBER_ENCODE#/<br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://#SERVER_NAME#\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:#SALE_EMAIL#\" style=\"color:#2e6eb6;\">#SALE_EMAIL#</a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\"><?=$arParams[\"SITE_NAME\"];?>: Отмена заказа N<?=$arParams[\"ORDER_ID\"];?></td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Заказ номер <?=$arParams[\"ORDER_ID\"];?> от <?=$arParams[\"ORDER_DATE\"];?> отменен.</p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\"><?=$arParams[\"ORDER_CANCEL_DESCRIPTION\"];?><br />\n<br />\nДля получения подробной информации по заказу пройдите на сайт http://<?=$arParams[\"SERVER_NAME\"];?>/personal/order/<?=$arParams[\"ORDER_ACCOUNT_NUMBER_ENCODE\"];?>/<br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://<?=$arParams[\"SERVER_NAME\"];?>\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:<?=$arParams[\"SALE_EMAIL\"];?>\" style=\"color:#2e6eb6;\"><?=$arParams[\"SALE_EMAIL\"];?></a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','html','#BCC#',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(31,'2016-10-18 08:02:56','SALE_ORDER_DELIVERY','s1','Y','#SALE_EMAIL#','#EMAIL#','#SITE_NAME#: Доставка заказа N#ORDER_ID# разрешена','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Доставка вашего заказа с сайта #SITE_NAME# разрешена</td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Доставка заказа номер #ORDER_ID# от #ORDER_DATE# разрешена.</p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Для получения подробной информации по заказу пройдите на сайт http://#SERVER_NAME#/personal/order/#ORDER_ACCOUNT_NUMBER_ENCODE#/<br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://#SERVER_NAME#\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:#SALE_EMAIL#\" style=\"color:#2e6eb6;\">#SALE_EMAIL#</a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Доставка вашего заказа с сайта <?=$arParams[\"SITE_NAME\"];?> разрешена</td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Доставка заказа номер <?=$arParams[\"ORDER_ID\"];?> от <?=$arParams[\"ORDER_DATE\"];?> разрешена.</p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Для получения подробной информации по заказу пройдите на сайт http://<?=$arParams[\"SERVER_NAME\"];?>/personal/order/<?=$arParams[\"ORDER_ACCOUNT_NUMBER_ENCODE\"];?>/<br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://<?=$arParams[\"SERVER_NAME\"];?>\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:<?=$arParams[\"SALE_EMAIL\"];?>\" style=\"color:#2e6eb6;\"><?=$arParams[\"SALE_EMAIL\"];?></a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','html','#BCC#',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(32,'2016-10-18 08:02:56','SALE_ORDER_PAID','s1','Y','#SALE_EMAIL#','#EMAIL#','#SITE_NAME#: Заказ N#ORDER_ID# оплачен','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Вы оплатили заказ на сайте #SITE_NAME#</td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Заказ номер #ORDER_ID# от #ORDER_DATE# оплачен.</p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Для получения подробной информации по заказу пройдите на сайт http://#SERVER_NAME#/personal/order/#ORDER_ACCOUNT_NUMBER_ENCODE#/</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://#SERVER_NAME#\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:#SALE_EMAIL#\" style=\"color:#2e6eb6;\">#SALE_EMAIL#</a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Вы оплатили заказ на сайте <?=$arParams[\"SITE_NAME\"];?></td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Заказ номер <?=$arParams[\"ORDER_ID\"];?> от <?=$arParams[\"ORDER_DATE\"];?> оплачен.</p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Для получения подробной информации по заказу пройдите на сайт http://<?=$arParams[\"SERVER_NAME\"];?>/personal/order/<?=$arParams[\"ORDER_ACCOUNT_NUMBER_ENCODE\"];?>/</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://<?=$arParams[\"SERVER_NAME\"];?>\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:<?=$arParams[\"SALE_EMAIL\"];?>\" style=\"color:#2e6eb6;\"><?=$arParams[\"SALE_EMAIL\"];?></a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','html','#BCC#',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(33,'2016-10-18 08:02:56','SALE_ORDER_REMIND_PAYMENT','s1','Y','#SALE_EMAIL#','#EMAIL#','#SITE_NAME#: Напоминание об оплате заказа N#ORDER_ID# ','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Напоминаем вам об оплате заказа на сайте #SITE_NAME#</td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Уважаемый #ORDER_USER#,</p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Вами был оформлен заказ N #ORDER_ID# от #ORDER_DATE# на сумму #PRICE#.<br />\n<br />\nК сожалению, на сегодняшний день средства по этому заказу не поступили к нам.<br />\n<br />\nВы можете следить за выполнением своего заказа (на какой стадии выполнения он находится), войдя в Ваш персональный раздел сайта #SITE_NAME#.<br />\n<br />\nОбратите внимание, что для входа в этот раздел Вам необходимо будет ввести логин и пароль пользователя сайта #SITE_NAME#.<br />\n<br />\nДля того, чтобы аннулировать заказ, воспользуйтесь функцией отмены заказа, которая доступна в Вашем персональном разделе сайта #SITE_NAME#.<br />\n<br />\nПожалуйста, при обращении к администрации сайта #SITE_NAME# ОБЯЗАТЕЛЬНО указывайте номер Вашего заказа - #ORDER_ID#.<br />\n<br />\nСпасибо за покупку!<br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://#SERVER_NAME#\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:#SALE_EMAIL#\" style=\"color:#2e6eb6;\">#SALE_EMAIL#</a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Напоминаем вам об оплате заказа на сайте <?=$arParams[\"SITE_NAME\"];?></td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Уважаемый <?=$arParams[\"ORDER_USER\"];?>,</p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Вами был оформлен заказ N <?=$arParams[\"ORDER_ID\"];?> от <?=$arParams[\"ORDER_DATE\"];?> на сумму <?=$arParams[\"PRICE\"];?>.<br />\n<br />\nК сожалению, на сегодняшний день средства по этому заказу не поступили к нам.<br />\n<br />\nВы можете следить за выполнением своего заказа (на какой стадии выполнения он находится), войдя в Ваш персональный раздел сайта <?=$arParams[\"SITE_NAME\"];?>.<br />\n<br />\nОбратите внимание, что для входа в этот раздел Вам необходимо будет ввести логин и пароль пользователя сайта <?=$arParams[\"SITE_NAME\"];?>.<br />\n<br />\nДля того, чтобы аннулировать заказ, воспользуйтесь функцией отмены заказа, которая доступна в Вашем персональном разделе сайта <?=$arParams[\"SITE_NAME\"];?>.<br />\n<br />\nПожалуйста, при обращении к администрации сайта <?=$arParams[\"SITE_NAME\"];?> ОБЯЗАТЕЛЬНО указывайте номер Вашего заказа - <?=$arParams[\"ORDER_ID\"];?>.<br />\n<br />\nСпасибо за покупку!<br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://<?=$arParams[\"SERVER_NAME\"];?>\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:<?=$arParams[\"SALE_EMAIL\"];?>\" style=\"color:#2e6eb6;\"><?=$arParams[\"SALE_EMAIL\"];?></a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','html','#BCC#',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(34,'2016-10-18 08:02:56','SALE_SUBSCRIBE_PRODUCT','s1','Y','#SALE_EMAIL#','#EMAIL#','#SITE_NAME#: Уведомление о поступлении товара','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Уведомление о поступлении товара в магазин #SITE_NAME#</td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Уважаемый, #USER_NAME#!</p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Товар \"#NAME#\" (#PAGE_URL#) поступил на склад.<br />\n<br />\nВы можете Оформить заказ (http://#SERVER_NAME#/personal/cart/).<br />\n<br />\nНе забудьте авторизоваться!<br />\n<br />\nВы получили это сообщение по Вашей просьбе оповестить при появлении товара.<br />\nНе отвечайте на него - письмо сформировано автоматически.<br />\n<br />\nСпасибо за покупку!<br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://#SERVER_NAME#\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:#SALE_EMAIL#\" style=\"color:#2e6eb6;\">#SALE_EMAIL#</a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Уведомление о поступлении товара в магазин <?=$arParams[\"SITE_NAME\"];?></td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Уважаемый, <?=$arParams[\"USER_NAME\"];?>!</p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Товар \"<?=$arParams[\"NAME\"];?>\" (<?=$arParams[\"PAGE_URL\"];?>) поступил на склад.<br />\n<br />\nВы можете Оформить заказ (http://<?=$arParams[\"SERVER_NAME\"];?>/personal/cart/).<br />\n<br />\nНе забудьте авторизоваться!<br />\n<br />\nВы получили это сообщение по Вашей просьбе оповестить при появлении товара.<br />\nНе отвечайте на него - письмо сформировано автоматически.<br />\n<br />\nСпасибо за покупку!<br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://<?=$arParams[\"SERVER_NAME\"];?>\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:<?=$arParams[\"SALE_EMAIL\"];?>\" style=\"color:#2e6eb6;\"><?=$arParams[\"SALE_EMAIL\"];?></a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','html','#BCC#',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(35,'2016-10-18 08:02:56','SALE_ORDER_TRACKING_NUMBER','s1','Y','#SALE_EMAIL#','#EMAIL#','Номер идентификатора отправления вашего заказа на сайте #SITE_NAME#','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Номер идентификатора отправления вашего заказа на сайте #SITE_NAME#</td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Уважаемый #ORDER_USER#,</p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Произошла почтовая отправка заказа N #ORDER_ID# от #ORDER_DATE#.<br />\n<br />\nНомер идентификатора отправления: #ORDER_TRACKING_NUMBER#.<br />\n<br />\nДля получения подробной информации по заказу пройдите на сайт http://#SERVER_NAME#/personal/order/detail/#ORDER_ACCOUNT_NUMBER_ENCODE#/<br />\n<br />\nE-mail: #SALE_EMAIL#<br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://#SERVER_NAME#\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:#SALE_EMAIL#\" style=\"color:#2e6eb6;\">#SALE_EMAIL#</a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Номер идентификатора отправления вашего заказа на сайте <?=$arParams[\"SITE_NAME\"];?></td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\">Уважаемый <?=$arParams[\"ORDER_USER\"];?>,</p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Произошла почтовая отправка заказа N <?=$arParams[\"ORDER_ID\"];?> от <?=$arParams[\"ORDER_DATE\"];?>.<br />\n<br />\nНомер идентификатора отправления: <?=$arParams[\"ORDER_TRACKING_NUMBER\"];?>.<br />\n<br />\nДля получения подробной информации по заказу пройдите на сайт http://<?=$arParams[\"SERVER_NAME\"];?>/personal/order/detail/<?=$arParams[\"ORDER_ACCOUNT_NUMBER_ENCODE\"];?>/<br />\n<br />\nE-mail: <?=$arParams[\"SALE_EMAIL\"];?><br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://<?=$arParams[\"SERVER_NAME\"];?>\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:<?=$arParams[\"SALE_EMAIL\"];?>\" style=\"color:#2e6eb6;\"><?=$arParams[\"SALE_EMAIL\"];?></a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','html','#BCC#',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(36,'2016-10-18 08:02:56','SALE_NEW_ORDER_RECURRING','s1','Y','#SALE_EMAIL#','#EMAIL#','#SITE_NAME#: Новый заказ N#ORDER_ID# на продление подписки','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nУважаемый #ORDER_USER#,\n\nВаш заказ номер #ORDER_ID# от #ORDER_DATE# на продление подписки принят.\n\nСтоимость заказа: #PRICE#.\n\nСостав заказа:\n#ORDER_LIST#\n\nВы можете следить за выполнением своего заказа (на какой\nстадии выполнения он находится), войдя в Ваш персональный\nраздел сайта #SITE_NAME#. Обратите внимание, что для входа\nв этот раздел Вам необходимо будет ввести логин и пароль\nпользователя сайта #SITE_NAME#.\n\nДля того, чтобы аннулировать заказ, воспользуйтесь функцией\nотмены заказа, которая доступна в Вашем персональном\nразделе сайта #SITE_NAME#.\n\nПожалуйста, при обращении к администрации сайта #SITE_NAME#\nОБЯЗАТЕЛЬНО указывайте номер Вашего заказа - #ORDER_ID#.\n\nСпасибо за покупку!\n','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nУважаемый <?=$arParams[\"ORDER_USER\"];?>,\n\nВаш заказ номер <?=$arParams[\"ORDER_ID\"];?> от <?=$arParams[\"ORDER_DATE\"];?> на продление подписки принят.\n\nСтоимость заказа: <?=$arParams[\"PRICE\"];?>.\n\nСостав заказа:\n<?=$arParams[\"ORDER_LIST\"];?>\n\n\nВы можете следить за выполнением своего заказа (на какой\nстадии выполнения он находится), войдя в Ваш персональный\nраздел сайта <?=$arParams[\"SITE_NAME\"];?>. Обратите внимание, что для входа\nв этот раздел Вам необходимо будет ввести логин и пароль\nпользователя сайта <?=$arParams[\"SITE_NAME\"];?>.\n\nДля того, чтобы аннулировать заказ, воспользуйтесь функцией\nотмены заказа, которая доступна в Вашем персональном\nразделе сайта <?=$arParams[\"SITE_NAME\"];?>.\n\nПожалуйста, при обращении к администрации сайта <?=$arParams[\"SITE_NAME\"];?>\n\nОБЯЗАТЕЛЬНО указывайте номер Вашего заказа - <?=$arParams[\"ORDER_ID\"];?>.\n\nСпасибо за покупку!\n','text','#BCC#',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(37,'2016-10-18 08:02:56','SALE_RECURRING_CANCEL','s1','Y','#SALE_EMAIL#','#EMAIL#','#SITE_NAME#: Подписка отменена','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nПодписка отменена\n\n#CANCELED_REASON#\n#SITE_NAME#\n','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nПодписка отменена\n\n<?=$arParams[\"CANCELED_REASON\"];?>\n\n<?=$arParams[\"SITE_NAME\"];?>\n\n','text','#BCC#',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(38,'2016-10-18 08:02:56','SALE_STATUS_CHANGED_F','s1','Y','#SALE_EMAIL#','#EMAIL#','#SERVER_NAME#: Изменение статуса заказа N#ORDER_ID#','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Изменение статуса заказа в магазине #SITE_NAME#</td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\"></p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Информационное сообщение сайта #SITE_NAME#<br />\n------------------------------------------<br />\n<br />\nСтатус заказа номер #ORDER_ID# от #ORDER_DATE# изменен.<br />\n<br />\nНовый статус заказа:<br />\n#ORDER_STATUS#<br />\n#ORDER_DESCRIPTION#<br />\n#TEXT#<br />\n<br />\nДля получения подробной информации по заказу пройдите на сайт #SERVER_NAME#/personal/order/#ORDER_ID#/<br />\n<br />\nСпасибо за ваш выбор!<br />\n#SITE_NAME#<br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://#SERVER_NAME#\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:#SALE_EMAIL#\" style=\"color:#2e6eb6;\">#SALE_EMAIL#</a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Изменение статуса заказа в магазине <?=$arParams[\"SITE_NAME\"];?></td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\"></p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?><br />\n------------------------------------------<br />\n<br />\nСтатус заказа номер <?=$arParams[\"ORDER_ID\"];?> от <?=$arParams[\"ORDER_DATE\"];?> изменен.<br />\n<br />\nНовый статус заказа:<br />\n<?=$arParams[\"ORDER_STATUS\"];?><br />\n<?=$arParams[\"ORDER_DESCRIPTION\"];?><br />\n<?=$arParams[\"TEXT\"];?><br />\n<br />\nДля получения подробной информации по заказу пройдите на сайт <?=$arParams[\"SERVER_NAME\"];?>/personal/order/<?=$arParams[\"ORDER_ID\"];?>/<br />\n<br />\nСпасибо за ваш выбор!<br />\n<?=$arParams[\"SITE_NAME\"];?><br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://<?=$arParams[\"SERVER_NAME\"];?>\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:<?=$arParams[\"SALE_EMAIL\"];?>\" style=\"color:#2e6eb6;\"><?=$arParams[\"SALE_EMAIL\"];?></a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','html',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(39,'2016-10-18 08:02:56','SALE_STATUS_CHANGED_N','s1','Y','#SALE_EMAIL#','#EMAIL#','#SERVER_NAME#: Изменение статуса заказа N#ORDER_ID#','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Изменение статуса заказа в магазине #SITE_NAME#</td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\"></p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Информационное сообщение сайта #SITE_NAME#<br />\n------------------------------------------<br />\n<br />\nСтатус заказа номер #ORDER_ID# от #ORDER_DATE# изменен.<br />\n<br />\nНовый статус заказа:<br />\n#ORDER_STATUS#<br />\n#ORDER_DESCRIPTION#<br />\n#TEXT#<br />\n<br />\nДля получения подробной информации по заказу пройдите на сайт #SERVER_NAME#/personal/order/#ORDER_ID#/<br />\n<br />\nСпасибо за ваш выбор!<br />\n#SITE_NAME#<br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://#SERVER_NAME#\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:#SALE_EMAIL#\" style=\"color:#2e6eb6;\">#SALE_EMAIL#</a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\n	<style>\n		body\n		{\n			font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif;\n			font-size: 14px;\n			color: #000;\n		}\n	</style>\n</head>\n<body>\n<table cellpadding=\"0\" cellspacing=\"0\" width=\"850\" style=\"background-color: #d1d1d1; border-radius: 2px; border:1px solid #d1d1d1; margin: 0 auto;\" border=\"1\" bordercolor=\"#d1d1d1\">\n	<tr>\n		<td height=\"83\" width=\"850\" bgcolor=\"#eaf3f5\" style=\"border: none; padding-top: 23px; padding-right: 17px; padding-bottom: 24px; padding-left: 17px;\">\n			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n				<tr>\n					<td bgcolor=\"#ffffff\" height=\"75\" style=\"font-weight: bold; text-align: center; font-size: 26px; color: #0b3961;\">Изменение статуса заказа в магазине <?=$arParams[\"SITE_NAME\"];?></td>\n				</tr>\n				<tr>\n					<td bgcolor=\"#bad3df\" height=\"11\"></td>\n				</tr>\n			</table>\n		</td>\n	</tr>\n	<tr>\n		<td width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 16px; padding-left: 44px;\">\n			<p style=\"margin-top:30px; margin-bottom: 28px; font-weight: bold; font-size: 19px;\"></p>\n			<p style=\"margin-top: 0; margin-bottom: 20px; line-height: 20px;\">Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?><br />\n------------------------------------------<br />\n<br />\nСтатус заказа номер <?=$arParams[\"ORDER_ID\"];?> от <?=$arParams[\"ORDER_DATE\"];?> изменен.<br />\n<br />\nНовый статус заказа:<br />\n<?=$arParams[\"ORDER_STATUS\"];?><br />\n<?=$arParams[\"ORDER_DESCRIPTION\"];?><br />\n<?=$arParams[\"TEXT\"];?><br />\n<br />\nДля получения подробной информации по заказу пройдите на сайт <?=$arParams[\"SERVER_NAME\"];?>/personal/order/<?=$arParams[\"ORDER_ID\"];?>/<br />\n<br />\nСпасибо за ваш выбор!<br />\n<?=$arParams[\"SITE_NAME\"];?><br />\n</p>\n		</td>\n	</tr>\n	<tr>\n		<td height=\"40px\" width=\"850\" bgcolor=\"#f7f7f7\" valign=\"top\" style=\"border: none; padding-top: 0; padding-right: 44px; padding-bottom: 30px; padding-left: 44px;\">\n			<p style=\"border-top: 1px solid #d1d1d1; margin-bottom: 5px; margin-top: 0; padding-top: 20px; line-height:21px;\">С уважением,<br />администрация <a href=\"http://<?=$arParams[\"SERVER_NAME\"];?>\" style=\"color:#2e6eb6;\">Интернет-магазина</a><br />\n				E-mail: <a href=\"mailto:<?=$arParams[\"SALE_EMAIL\"];?>\" style=\"color:#2e6eb6;\"><?=$arParams[\"SALE_EMAIL\"];?></a>\n			</p>\n		</td>\n	</tr>\n</table>\n</body>\n</html>','html',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(40,'2016-10-18 08:03:29','VIRUS_DETECTED','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL#','#SITE_NAME#: Обнаружен вирус','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nЗдравствуйте!\n\nВы получили это сообщение, так как модуль проактивной защиты сервера #SERVER_NAME# обнаружил код, похожий на вирус.\n\n1. Подозрительный код был вырезан из html.\n2. Проверьте журнал вторжений и убедитесь, что код действительно вредоносный, а не является кодом какого-либо счетчика или фреймворка.\n (ссылка: http://#SERVER_NAME#/bitrix/admin/event_log.php?lang=ru&set_filter=Y&find_type=audit_type_id&find_audit_type[]=SECURITY_VIRUS )\n3. В случае, если код не является опасным, добавьте его в исключения на странице настройки антивируса.\n (ссылка: http://#SERVER_NAME#/bitrix/admin/security_antivirus.php?lang=ru&tabControl_active_tab=exceptions )\n4. Если код является вирусным, то необходимо выполнить следующие действия:\n\n а) Смените пароли доступа к сайту у администраторов и ответственных сотрудников.\n б) Смените пароли доступа по ssh и ftp.\n в) Проверьте и вылечите компьютеры администраторов, имевших доступ к сайту по ssh или ftp.\n г) В программах доступа к сайту по ssh и ftp отключите сохранение паролей.\n д) Удалите вредоносный код из зараженных файлов. Например, восстановите поврежденные файлы из самой свежей резервной копии.\n\n---------------------------------------------------------------------\nСообщение сгенерировано автоматически.\n','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nЗдравствуйте!\n\nВы получили это сообщение, так как модуль проактивной защиты сервера <?=$arParams[\"SERVER_NAME\"];?> обнаружил код, похожий на вирус.\n\n1. Подозрительный код был вырезан из html.\n2. Проверьте журнал вторжений и убедитесь, что код действительно вредоносный, а не является кодом какого-либо счетчика или фреймворка.\n (ссылка: http://<?=$arParams[\"SERVER_NAME\"];?>/bitrix/admin/event_log.php?lang=ru&set_filter=Y&find_type=audit_type_id&find_audit_type[]=SECURITY_VIRUS )\n3. В случае, если код не является опасным, добавьте его в исключения на странице настройки антивируса.\n (ссылка: http://<?=$arParams[\"SERVER_NAME\"];?>/bitrix/admin/security_antivirus.php?lang=ru&tabControl_active_tab=exceptions )\n4. Если код является вирусным, то необходимо выполнить следующие действия:\n\n а) Смените пароли доступа к сайту у администраторов и ответственных сотрудников.\n б) Смените пароли доступа по ssh и ftp.\n в) Проверьте и вылечите компьютеры администраторов, имевших доступ к сайту по ssh или ftp.\n г) В программах доступа к сайту по ssh и ftp отключите сохранение паролей.\n д) Удалите вредоносный код из зараженных файлов. Например, восстановите поврежденные файлы из самой свежей резервной копии.\n\n---------------------------------------------------------------------\nСообщение сгенерировано автоматически.\n','text','',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(41,'2016-10-18 08:03:33','SENDER_SUBSCRIBE_CONFIRM','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL#','#SITE_NAME#: Подтверждение подписки','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nЗдравствуйте,\n\nВы получили это сообщение, так как ваш адрес был подписан\nна список рассылки сервера #SERVER_NAME#.\n\nДополнительная информация о подписке:\n\nАдрес подписки (email) ............ #EMAIL#\nДата добавления/редактирования .... #DATE#\nСписок рассылок:\n#MAILING_LIST#\n\n\nДля подтверждения подписки перейдите по следующей ссылке:\nhttp://#SERVER_NAME##CONFIRM_URL#\n\n\nВнимание! Вы не будете получать сообщения рассылки, пока не подтвердите\nсвою подписку.\nЕсли вы не подписывались на рассылку и получили это письмо по ошибке,\nпроигнорируйте его.\n\nСообщение сгенерировано автоматически.\n','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nЗдравствуйте,\n\nВы получили это сообщение, так как ваш адрес был подписан\nна список рассылки сервера <?=$arParams[\"SERVER_NAME\"];?>.\n\nДополнительная информация о подписке:\n\nАдрес подписки (email) ............ <?=$arParams[\"EMAIL\"];?>\n\nДата добавления/редактирования .... <?=$arParams[\"DATE\"];?>\n\nСписок рассылок:\n<?=$arParams[\"MAILING_LIST\"];?>\n\n\n\nДля подтверждения подписки перейдите по следующей ссылке:\nhttp://<?=$arParams[\"SERVER_NAME\"];?><?=$arParams[\"CONFIRM_URL\"];?>\n\n\n\nВнимание! Вы не будете получать сообщения рассылки, пока не подтвердите\nсвою подписку.\nЕсли вы не подписывались на рассылку и получили это письмо по ошибке,\nпроигнорируйте его.\n\nСообщение сгенерировано автоматически.\n','text','',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(42,'2016-10-18 08:03:42','SUBSCRIBE_CONFIRM','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL#','#SITE_NAME#: Подтверждение подписки','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nЗдравствуйте,\n\nВы получили это сообщение, так как ваш адрес был подписан\nна список рассылки сервера #SERVER_NAME#.\n\nДополнительная информация о подписке:\n\nАдрес подписки (email) ............ #EMAIL#\nДата добавления/редактирования .... #DATE_SUBSCR#\n\nВаш код для подтверждения подписки: #CONFIRM_CODE#\n\nДля подтверждения подписки перейдите по следующей ссылке:\nhttp://#SERVER_NAME##SUBSCR_SECTION#subscr_edit.php?ID=#ID#&CONFIRM_CODE=#CONFIRM_CODE#\n\nВы также можете ввести код для подтверждения подписки на странице:\nhttp://#SERVER_NAME##SUBSCR_SECTION#subscr_edit.php?ID=#ID#\n\nВнимание! Вы не будете получать сообщения рассылки, пока не подтвердите\nсвою подписку.\n\n---------------------------------------------------------------------\nСохраните это письмо, так как оно содержит информацию для авторизации.\nИспользуя код подтверждения подписки, вы cможете изменить параметры\nподписки или отписаться от рассылки.\n\nИзменить параметры:\nhttp://#SERVER_NAME##SUBSCR_SECTION#subscr_edit.php?ID=#ID#&CONFIRM_CODE=#CONFIRM_CODE#\n\nОтписаться:\nhttp://#SERVER_NAME##SUBSCR_SECTION#subscr_edit.php?ID=#ID#&CONFIRM_CODE=#CONFIRM_CODE#&action=unsubscribe\n---------------------------------------------------------------------\n\nСообщение сгенерировано автоматически.\n','Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nЗдравствуйте,\n\nВы получили это сообщение, так как ваш адрес был подписан\nна список рассылки сервера <?=$arParams[\"SERVER_NAME\"];?>.\n\nДополнительная информация о подписке:\n\nАдрес подписки (email) ............ <?=$arParams[\"EMAIL\"];?>\n\nДата добавления/редактирования .... <?=$arParams[\"DATE_SUBSCR\"];?>\n\n\nВаш код для подтверждения подписки: <?=$arParams[\"CONFIRM_CODE\"];?>\n\n\nДля подтверждения подписки перейдите по следующей ссылке:\nhttp://<?=$arParams[\"SERVER_NAME\"];?><?=$arParams[\"SUBSCR_SECTION\"];?>subscr_edit.php?ID=<?=$arParams[\"ID\"];?>&CONFIRM_CODE=<?=$arParams[\"CONFIRM_CODE\"];?>\n\n\nВы также можете ввести код для подтверждения подписки на странице:\nhttp://<?=$arParams[\"SERVER_NAME\"];?><?=$arParams[\"SUBSCR_SECTION\"];?>subscr_edit.php?ID=<?=$arParams[\"ID\"];?>\n\n\nВнимание! Вы не будете получать сообщения рассылки, пока не подтвердите\nсвою подписку.\n\n---------------------------------------------------------------------\nСохраните это письмо, так как оно содержит информацию для авторизации.\nИспользуя код подтверждения подписки, вы cможете изменить параметры\nподписки или отписаться от рассылки.\n\nИзменить параметры:\nhttp://<?=$arParams[\"SERVER_NAME\"];?><?=$arParams[\"SUBSCR_SECTION\"];?>subscr_edit.php?ID=<?=$arParams[\"ID\"];?>&CONFIRM_CODE=<?=$arParams[\"CONFIRM_CODE\"];?>\n\n\nОтписаться:\nhttp://<?=$arParams[\"SERVER_NAME\"];?><?=$arParams[\"SUBSCR_SECTION\"];?>subscr_edit.php?ID=<?=$arParams[\"ID\"];?>&CONFIRM_CODE=<?=$arParams[\"CONFIRM_CODE\"];?>&action=unsubscribe\n---------------------------------------------------------------------\n\nСообщение сгенерировано автоматически.\n','text','',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
(43,'2016-10-18 08:03:50','VOTE_FOR','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: [V] #VOTE_TITLE#','#USER_NAME# принял участие в опросе \"#VOTE_TITLE#\":\n#VOTE_STATISTIC#\n\nhttp://#SERVER_NAME##URL#\nСообщение сгенерировано автоматически.','<?=$arParams[\"USER_NAME\"];?> принял участие в опросе \"<?=$arParams[\"VOTE_TITLE\"];?>\":\n<?=$arParams[\"VOTE_STATISTIC\"];?>\n\n\nhttp://<?=$arParams[\"SERVER_NAME\"];?><?=$arParams[\"URL\"];?>\n\nСообщение сгенерировано автоматически.','text',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N)	;
#	TC`b_event_message_attachment`utf8_unicode_ci	;
CREATE TABLE `b_event_message_attachment` (
  `EVENT_MESSAGE_ID` int(18) NOT NULL,
  `FILE_ID` int(18) NOT NULL,
  PRIMARY KEY (`EVENT_MESSAGE_ID`,`FILE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_event_message_site`utf8_unicode_ci	;
CREATE TABLE `b_event_message_site` (
  `EVENT_MESSAGE_ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`EVENT_MESSAGE_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_event_message_site`utf8_unicode_ci	;
INSERT INTO `b_event_message_site` VALUES 
(1,'s1'),
(2,'s1'),
(3,'s1'),
(4,'s1'),
(5,'s1'),
(6,'s1'),
(7,'s1'),
(8,'s1'),
(9,'s1'),
(10,'s1'),
(11,'s1'),
(12,'s1'),
(13,'s1'),
(14,'s1'),
(15,'s1'),
(16,'s1'),
(17,'s1'),
(18,'s1'),
(19,'s1'),
(20,'s1'),
(21,'s1'),
(22,'s1'),
(23,'s1'),
(24,'s1'),
(25,'s1'),
(26,'s1'),
(27,'s1'),
(28,'s1'),
(29,'s1'),
(30,'s1'),
(31,'s1'),
(32,'s1'),
(33,'s1'),
(34,'s1'),
(35,'s1'),
(36,'s1'),
(37,'s1'),
(38,'s1'),
(39,'s1'),
(40,'s1'),
(41,'s1'),
(42,'s1'),
(43,'s1')	;
#	TC`b_event_type`utf8_unicode_ci	;
CREATE TABLE `b_event_type` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `EVENT_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `SORT` int(18) NOT NULL DEFAULT '150',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_1` (`EVENT_NAME`,`LID`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_event_type`utf8_unicode_ci	;
INSERT INTO `b_event_type` VALUES 
(1,'ru','NEW_USER','Зарегистрировался новый пользователь','\n\n#USER_ID# - ID пользователя\n#LOGIN# - Логин\n#EMAIL# - EMail\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#USER_IP# - IP пользователя\n#USER_HOST# - Хост пользователя\n',1),
(2,'ru','USER_INFO','Информация о пользователе','\n\n#USER_ID# - ID пользователя\n#STATUS# - Статус логина\n#MESSAGE# - Сообщение пользователю\n#LOGIN# - Логин\n#URL_LOGIN# - Логин, закодированный для использования в URL\n#CHECKWORD# - Контрольная строка для смены пароля\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#EMAIL# - E-Mail пользователя\n',2),
(3,'ru','NEW_USER_CONFIRM','Подтверждение регистрации нового пользователя','\n\n\n#USER_ID# - ID пользователя\n#LOGIN# - Логин\n#EMAIL# - EMail\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#USER_IP# - IP пользователя\n#USER_HOST# - Хост пользователя\n#CONFIRM_CODE# - Код подтверждения\n',3),
(4,'ru','USER_PASS_REQUEST','Запрос на смену пароля','\n\n#USER_ID# - ID пользователя\n#STATUS# - Статус логина\n#MESSAGE# - Сообщение пользователю\n#LOGIN# - Логин\n#URL_LOGIN# - Логин, закодированный для использования в URL\n#CHECKWORD# - Контрольная строка для смены пароля\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#EMAIL# - E-Mail пользователя\n',4),
(5,'ru','USER_PASS_CHANGED','Подтверждение смены пароля','\n\n#USER_ID# - ID пользователя\n#STATUS# - Статус логина\n#MESSAGE# - Сообщение пользователю\n#LOGIN# - Логин\n#URL_LOGIN# - Логин, закодированный для использования в URL\n#CHECKWORD# - Контрольная строка для смены пароля\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#EMAIL# - E-Mail пользователя\n',5),
(6,'ru','USER_INVITE','Приглашение на сайт нового пользователя','#ID# - ID пользователя\n#LOGIN# - Логин\n#URL_LOGIN# - Логин, закодированный для использования в URL\n#EMAIL# - EMail\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#PASSWORD# - пароль пользователя \n#CHECKWORD# - Контрольная строка для смены пароля\n#XML_ID# - ID пользователя для связи с внешними источниками\n',6),
(7,'ru','FEEDBACK_FORM','Отправка сообщения через форму обратной связи','#AUTHOR# - Автор сообщения\n#AUTHOR_EMAIL# - Email автора сообщения\n#TEXT# - Текст сообщения\n#EMAIL_FROM# - Email отправителя письма\n#EMAIL_TO# - Email получателя письма',7),
(8,'en','NEW_USER','New user was registered','\n\n#USER_ID# - User ID\n#LOGIN# - Login\n#EMAIL# - EMail\n#NAME# - Name\n#LAST_NAME# - Last Name\n#USER_IP# - User IP\n#USER_HOST# - User Host\n',1),
(9,'en','USER_INFO','Account Information','\n\n#USER_ID# - User ID\n#STATUS# - Account status\n#MESSAGE# - Message for user\n#LOGIN# - Login\n#URL_LOGIN# - Encoded login for use in URL\n#CHECKWORD# - Check string for password change\n#NAME# - Name\n#LAST_NAME# - Last Name\n#EMAIL# - User E-Mail\n',2),
(10,'en','NEW_USER_CONFIRM','New user registration confirmation','\n\n#USER_ID# - User ID\n#LOGIN# - Login\n#EMAIL# - E-mail\n#NAME# - First name\n#LAST_NAME# - Last name\n#USER_IP# - User IP\n#USER_HOST# - User host\n#CONFIRM_CODE# - Confirmation code\n',3),
(11,'en','USER_PASS_REQUEST','Password Change Request','\n\n#USER_ID# - User ID\n#STATUS# - Account status\n#MESSAGE# - Message for user\n#LOGIN# - Login\n#URL_LOGIN# - Encoded login for use in URL\n#CHECKWORD# - Check string for password change\n#NAME# - Name\n#LAST_NAME# - Last Name\n#EMAIL# - User E-Mail\n',4),
(12,'en','USER_PASS_CHANGED','Password Change Confirmation','\n\n#USER_ID# - User ID\n#STATUS# - Account status\n#MESSAGE# - Message for user\n#LOGIN# - Login\n#URL_LOGIN# - Encoded login for use in URL\n#CHECKWORD# - Check string for password change\n#NAME# - Name\n#LAST_NAME# - Last Name\n#EMAIL# - User E-Mail\n',5),
(13,'en','USER_INVITE','Invitation of a new site user','#ID# - User ID\n#LOGIN# - Login\n#URL_LOGIN# - Encoded login for use in URL\n#EMAIL# - EMail\n#NAME# - Name\n#LAST_NAME# - Last Name\n#PASSWORD# - User password \n#CHECKWORD# - Password check string\n#XML_ID# - User ID to link with external data sources\n\n',6),
(14,'en','FEEDBACK_FORM','Sending a message using a feedback form','#AUTHOR# - Message author\n#AUTHOR_EMAIL# - Author\'s e-mail address\n#TEXT# - Message text\n#EMAIL_FROM# - Sender\'s e-mail address\n#EMAIL_TO# - Recipient\'s e-mail address',7),
(15,'ru','NEW_BLOG_MESSAGE','Новое сообщение в блоге','#BLOG_ID# - ID блога \n#BLOG_NAME# - Название блога\n#BLOG_URL# - Название блога латиницей\n#MESSAGE_TITLE# - Тема сообщения\n#MESSAGE_TEXT# - Текст сообщения\n#MESSAGE_DATE# - Дата сообщения\n#MESSAGE_PATH# - URL адрес сообщения\n#AUTHOR# - Автор сообщения\n#EMAIL_FROM# - Email отправителя письма\n#EMAIL_TO# - Email получателя письма',100),
(16,'ru','NEW_BLOG_COMMENT','Новый комментарий в блоге','#BLOG_ID# - ID блога \n#BLOG_NAME# - Название блога\n#BLOG_URL# - Название блога латиницей\n#MESSAGE_TITLE# - Тема сообщения\n#COMMENT_TITLE# - Заголовок комментария\n#COMMENT_TEXT# - Текст комментария\n#COMMENT_DATE# - Текст комментария\n#COMMENT_PATH# - URL адрес сообщения\n#AUTHOR# - Автор сообщения\n#EMAIL_FROM# - Email отправителя письма\n#EMAIL_TO# - Email получателя письма',100),
(17,'ru','NEW_BLOG_COMMENT2COMMENT','Новый комментарий на ваш комментарий в блоге','#BLOG_ID# - ID блога \n#BLOG_NAME# - Название блога\n#BLOG_URL# - Название блога латиницей\n#MESSAGE_TITLE# - Тема сообщения\n#COMMENT_TITLE# - Заголовок комментария\n#COMMENT_TEXT# - Текст комментария\n#COMMENT_DATE# - Текст комментария\n#COMMENT_PATH# - URL адрес сообщения\n#AUTHOR# - Автор сообщения\n#EMAIL_FROM# - Email отправителя письма\n#EMAIL_TO# - Email получателя письма',100),
(18,'ru','NEW_BLOG_COMMENT_WITHOUT_TITLE','Новый комментарий в блоге (без темы)','#BLOG_ID# - ID блога \n#BLOG_NAME# - Название блога\n#BLOG_URL# - Название блога латиницей\n#MESSAGE_TITLE# - Тема сообщения\n#COMMENT_TEXT# - Текст комментария\n#COMMENT_DATE# - Текст комментария\n#COMMENT_PATH# - URL адрес сообщения\n#AUTHOR# - Автор сообщения\n#EMAIL_FROM# - Email отправителя письма\n#EMAIL_TO# - Email получателя письма',100),
(19,'ru','NEW_BLOG_COMMENT2COMMENT_WITHOUT_TITLE','Новый комментарий на ваш комментарий в блоге (без темы)','#BLOG_ID# - ID блога \n#BLOG_NAME# - Название блога\n#BLOG_URL# - Название блога латиницей\n#COMMENT_TITLE# - Заголовок комментария\n#COMMENT_TEXT# - Текст комментария\n#COMMENT_DATE# - Текст комментария\n#COMMENT_PATH# - URL адрес сообщения\n#AUTHOR# - Автор сообщения\n#EMAIL_FROM# - Email отправителя письма\n#EMAIL_TO# - Email получателя письма',100),
(20,'ru','BLOG_YOUR_BLOG_TO_USER','Ваш блог был добавлен в друзья','#BLOG_ID# - ID блога \n#BLOG_NAME# - Название блога\n#BLOG_URL# - Название блога латиницей\n#BLOG_ADR# - Адрес блога\n#USER_ID# - ID пользователя\n#USER# - Пользователь\n#USER_URL# - Адрес пользователя\n#EMAIL_FROM# - Email отправителя письма\n#EMAIL_TO# - Email получателя письма\n',100),
(21,'ru','BLOG_YOU_TO_BLOG','Вы были добавлены в друзья блога','#BLOG_ID# - ID блога \n#BLOG_NAME# - Название блога\n#BLOG_URL# - Название блога латиницей\n#BLOG_ADR# - Адрес блога\n#USER_ID# - ID пользователя\n#USER# - Пользователь\n#USER_URL# - Адрес пользователя\n#EMAIL_FROM# - Email отправителя письма\n#EMAIL_TO# - Email получателя письма\n',100),
(22,'ru','BLOG_BLOG_TO_YOU','К вам в друзья был добавлен блог','#BLOG_ID# - ID блога \n#BLOG_NAME# - Название блога\n#BLOG_URL# - Название блога латиницей\n#BLOG_ADR# - Адрес блога\n#USER_ID# - ID пользователя\n#USER# - Пользователь\n#USER_URL# - Адрес пользователя\n#EMAIL_FROM# - Email отправителя письма\n#EMAIL_TO# - Email получателя письма\n',100),
(23,'ru','BLOG_USER_TO_YOUR_BLOG','В ваш блог был добавлен друг','#BLOG_ID# - ID блога \n#BLOG_NAME# - Название блога\n#BLOG_URL# - Название блога латиницей\n#BLOG_ADR# - Адрес блога\n#USER_ID# - ID пользователя\n#USER# - Пользователь\n#USER_URL# - Адрес пользователя\n#EMAIL_FROM# - Email отправителя письма\n#EMAIL_TO# - Email получателя письма\n',100),
(24,'ru','BLOG_SONET_NEW_POST','Добавлено новое сообщение','#EMAIL_TO# - Email получателя письма\n#POST_ID# - ID сообщения\n#RECIPIENT_ID# - ID получателя\n#URL_ID# - URL страницы сообщения\n',100),
(25,'ru','BLOG_SONET_NEW_COMMENT','Добавлен новый комментарий','#EMAIL_TO# - Email получателя письма\n#COMMENT_ID# - ID комментария\n#POST_ID# - ID сообщения\n#RECIPIENT_ID# - ID получателя\n#URL_ID# - URL страницы сообщения\n',100),
(26,'ru','BLOG_SONET_POST_SHARE','Добавлен новый получатель сообщения','#EMAIL_TO# - Email получателя письма\n#POST_ID# - ID сообщения\n#RECIPIENT_ID# - ID получателя\n#URL_ID# - URL страницы сообщения\n',100),
(27,'ru','BLOG_POST_BROADCAST','Добавлено новое сообщение','\n#MESSAGE_TITLE# - Тема сообщения\n#MESSAGE_TEXT# - Текст сообщения\n#MESSAGE_PATH# - URL адрес сообщения\n#AUTHOR# - Автор сообщения\n#EMAIL_TO# - Email получателя письма',100),
(28,'en','NEW_BLOG_MESSAGE','New blog message','#BLOG_ID# - Blog ID\n#BLOG_NAME# - Blog title\n#BLOG_URL# - Blog url\n#MESSAGE_TITLE# - Message title\n#MESSAGE_TEXT# - Message text\n#MESSAGE_DATE# - Message date\n#MESSAGE_PATH# - URL to message\n#AUTHOR# - Message author\n#EMAIL_FROM# - Sender email\n#EMAIL_TO# - Recipient email',100),
(29,'en','NEW_BLOG_COMMENT','New comment in blog','#BLOG_ID# - Blog ID\n#BLOG_NAME# - Blog title\n#BLOG_URL# - Blog url\n#MESSAGE_TITLE# - Message title\n#COMMENT_TITLE# - Comment title\n#COMMENT_TEXT# - Comment text\n#COMMENT_DATE# - Comment date\n#COMMENT_PATH# - Comment URL\n#AUTHOR# - Comment author\n#EMAIL_FROM# - Sender email\n#EMAIL_TO# - Recipient email',100),
(30,'en','NEW_BLOG_COMMENT2COMMENT','New comment for your in blog','#BLOG_ID# - Blog ID\n#BLOG_NAME# - Blog title\n#BLOG_URL# - Blog url\n#MESSAGE_TITLE# - Message title\n#COMMENT_TITLE# - Comment title\n#COMMENT_TEXT# - Comment text\n#COMMENT_DATE# - Comment date\n#COMMENT_PATH# - Comment URL\n#AUTHOR# - Comment author\n#EMAIL_FROM# - Sender email\n#EMAIL_TO# - Recipient email',100),
(31,'en','NEW_BLOG_COMMENT_WITHOUT_TITLE','New comment in blog (without subject)','#BLOG_ID# - Blog ID\n#BLOG_NAME# - Blog title\n#BLOG_URL# - Blog url\n#MESSAGE_TITLE# - Message title\n#COMMENT_TEXT# - Comment text\n#COMMENT_DATE# - Comment date\n#COMMENT_PATH# - Comment URL\n#AUTHOR# - Comment author\n#EMAIL_FROM# - Sender email\n#EMAIL_TO# - Recipient email',100),
(32,'en','NEW_BLOG_COMMENT2COMMENT_WITHOUT_TITLE','New comment for your in blog (without subject)','#BLOG_ID# - Blog ID\n#BLOG_NAME# - Blog title\n#BLOG_URL# - Blog url\n#MESSAGE_TITLE# - Message title\n#COMMENT_TEXT# - Comment text\n#COMMENT_DATE# - Comment date\n#COMMENT_PATH# - Comment URL\n#AUTHOR# - Comment author\n#EMAIL_FROM# - Sender email\n#EMAIL_TO# - Recipient email',100),
(33,'en','BLOG_YOUR_BLOG_TO_USER','Your blog has been added to friends','#BLOG_ID# - Blog ID\n#BLOG_NAME# - Blog name\n#BLOG_URL# - Blog name, Latin letters only\n#BLOG_ADR# - Blog address\n#USER_ID# - User ID\n#USER# - User\n#USER_URL# - User URL\n#EMAIL_FROM# - Sender E-mail\n#EMAIL_TO# - Recipient E-mail',100),
(34,'en','BLOG_YOU_TO_BLOG','You have been added to blog friends','#BLOG_ID# - Blog ID\n#BLOG_NAME# - Blog name\n#BLOG_URL# - Blog name, Latin letters only\n#BLOG_ADR# - Blog address\n#USER_ID# - User ID\n#USER# - User\n#USER_URL# - User URL\n#EMAIL_FROM# - Sender E-mail\n#EMAIL_TO# - Recipient E-mail',100),
(35,'en','BLOG_BLOG_TO_YOU','A blog has been added to your friends','#BLOG_ID# - Blog ID\n#BLOG_NAME# - Blog name\n#BLOG_URL# - Blog name, Latin letters only\n#BLOG_ADR# - Blog address\n#USER_ID# - User ID\n#USER# - User\n#USER_URL# - User URL\n#EMAIL_FROM# - Sender E-mail\n#EMAIL_TO# - Recipient E-mail',100),
(36,'en','BLOG_USER_TO_YOUR_BLOG','A friend has been added to your blog','#BLOG_ID# - Blog ID\n#BLOG_NAME# - Blog name\n#BLOG_URL# - Blog name, Latin letters only\n#BLOG_ADR# - Blog address\n#USER_ID# - User ID\n#USER# - User\n#USER_URL# - User URL\n#EMAIL_FROM# - Sender E-mail\n#EMAIL_TO# - Recipient E-mail',100),
(37,'en','BLOG_SONET_NEW_POST','New post added','#EMAIL_TO# - Recipient email\n#POST_ID# - Post ID\n#URL_ID# - Post URL',100),
(38,'en','BLOG_SONET_NEW_COMMENT','Comment added','#EMAIL_TO# - Recipient email\n#COMMENT_ID# - Comment ID\n#POST_ID# - Post ID\n#URL_ID# - Post URL',100),
(39,'en','BLOG_SONET_POST_SHARE','New recipient added','#EMAIL_TO# - Recipient email\n#POST_ID# - Post ID\n#URL_ID# - Post URL',100),
(40,'en','BLOG_POST_BROADCAST','New post added','\n#MESSAGE_TITLE# - Post subject\n#MESSAGE_TEXT# - Post text \n#MESSAGE_PATH# - Post URL\n#AUTHOR# - Post author\n#EMAIL_TO# - E-mail recipient',100),
(41,'en','CATALOG_PRODUCT_SUBSCRIBE_LIST_CONFIRM','Код подтверждения','\n#TOKEN# - Код подтверждения\n#TOKEN_URL# - Ссылка с кодом подтверждения\n#LIST_SUBSCRIBES# - Список подписок\n#URL_PARAMETERS# - Параметры ссылки для подтверждения кода доступа\n',100),
(42,'en','CATALOG_PRODUCT_SUBSCRIBE_NOTIFY','Уведомление о поступлении товара','#USER_NAME# - имя пользователя\n#EMAIL_TO# - email пользователя\n#NAME# - название товара\n#PAGE_URL# - детальная страница товара\n#CHECKOUT_URL# - добавление товара в корзину\n#CHECKOUT_URL_PARAMETERS# - параметры ссылки добавления товара в корзину\n#PRODUCT_ID# - id товара для формирования ссылок\n#UNSUBSCRIBE_URL# - ссылка отписки от товара\n#UNSUBSCRIBE_URL_PARAMETERS# - параметры ссылки отписки от товара\n',100),
(43,'en','CATALOG_PRODUCT_SUBSCRIBE_NOTIFY_REPEATED','Уведомление о товаре в магазине','#USER_NAME# - имя пользователя\n#EMAIL_TO# - email пользователя\n#NAME# - название товара\n#PAGE_URL# - детальная страница товара\n#PRODUCT_ID# - id товара для формирования ссылок\n#UNSUBSCRIBE_URL# - ссылка отписки от товара\n#UNSUBSCRIBE_URL_PARAMETERS# - параметры ссылки отписки от товара\n',100),
(44,'ru','CATALOG_PRODUCT_SUBSCRIBE_LIST_CONFIRM','Код подтверждения','\n#TOKEN# - Код подтверждения\n#TOKEN_URL# - Ссылка с кодом подтверждения\n#LIST_SUBSCRIBES# - Список подписок\n#URL_PARAMETERS# - Параметры ссылки для подтверждения кода доступа\n',100),
(45,'ru','CATALOG_PRODUCT_SUBSCRIBE_NOTIFY','Уведомление о поступлении товара','#USER_NAME# - имя пользователя\n#EMAIL_TO# - email пользователя\n#NAME# - название товара\n#PAGE_URL# - детальная страница товара\n#CHECKOUT_URL# - добавление товара в корзину\n#CHECKOUT_URL_PARAMETERS# - параметры ссылки добавления товара в корзину\n#PRODUCT_ID# - id товара для формирования ссылок\n#UNSUBSCRIBE_URL# - ссылка отписки от товара\n#UNSUBSCRIBE_URL_PARAMETERS# - параметры ссылки отписки от товара\n',100),
(46,'ru','CATALOG_PRODUCT_SUBSCRIBE_NOTIFY_REPEATED','Уведомление о товаре в магазине','#USER_NAME# - имя пользователя\n#EMAIL_TO# - email пользователя\n#NAME# - название товара\n#PAGE_URL# - детальная страница товара\n#PRODUCT_ID# - id товара для формирования ссылок\n#UNSUBSCRIBE_URL# - ссылка отписки от товара\n#UNSUBSCRIBE_URL_PARAMETERS# - параметры ссылки отписки от товара\n',100),
(47,'ru','NEW_FORUM_MESSAGE','Новое сообщение на форуме','\n			#FORUM_ID# - ID форума\n			#FORUM_NAME# - Название форума\n			#TOPIC_ID# - ID темы\n			#MESSAGE_ID# - ID сообщения\n			#TOPIC_TITLE# - Тема сообщения\n			#MESSAGE_TEXT# - Текст сообщения\n			#MESSAGE_DATE# - Дата сообщения\n			#AUTHOR# - Автор сообщения\n			#RECIPIENT# - Получатель сообщения\n			#TAPPROVED# - Тема сообщения показывается\n			#MAPPROVED# - Тело сообщения показывается\n			#PATH2FORUM# - Адрес сообщения\n			#FROM_EMAIL# - E-Mail для поля From письма',100),
(48,'ru','NEW_FORUM_PRIV','Приватное письмо посетителю форума','\n			#FROM_NAME# - Автор сообщения\n			#FROM_EMAIL# - E-Mail автора сообщения\n			#TO_NAME# - Имя получателя сообщения\n			#TO_EMAIL# - E-Mail получателя сообщения\n			#SUBJECT# - Тема сообщения\n			#MESSAGE# - Тело сообщения\n			#MESSAGE_DATE# - Дата сообщения',100),
(49,'ru','NEW_FORUM_PRIVATE_MESSAGE','Приватное сообщение','\n			#FROM_NAME# - Имя автора сообщения\n			#FROM_USER_ID# - ID автора сообщения\n			#FROM_EMAIL# - E-Mail автора сообщения\n			#TO_NAME# - Имя получателя сообщения\n			#TO_USER_ID# - ID получателя сообщения\n			#TO_EMAIL# - E-Mail получателя сообщения\n			#SUBJECT# - Тема сообщения\n			#MESSAGE# - Текст сообщения\n			#MESSAGE_DATE# - Дата сообщения\n			#MESSAGE_LINK# - Ссылка на сообщение',100),
(50,'ru','EDIT_FORUM_MESSAGE','Изменение сообщения на форуме','\n			#FORUM_ID# - ID форума\n			#FORUM_NAME# - Название форума\n			#TOPIC_ID# - ID темы\n			#MESSAGE_ID# - ID сообщения\n			#TOPIC_TITLE# - Тема сообщения\n			#MESSAGE_TEXT# - Текст сообщения\n			#MESSAGE_DATE# - Дата сообщения\n			#AUTHOR# - Автор сообщения\n			#RECIPIENT# - Получатель сообщения\n			#TAPPROVED# - Тема сообщения показывается\n			#MAPPROVED# - Тело сообщения показывается\n			#PATH2FORUM# - Адрес сообщения\n			#FROM_EMAIL# - E-Mail для поля From письма',100),
(51,'en','NEW_FORUM_MESSAGE','New forum message','\n			#FORUM_ID# - Forum ID\n			#FORUM_NAME# - Forum name\n			#TOPIC_ID# - Topic ID\n			#MESSAGE_ID# - Message ID\n			#TOPIC_TITLE# - Topic title\n			#MESSAGE_TEXT# - Message text\n			#MESSAGE_DATE# - Message date\n			#AUTHOR# - Message author\n			#RECIPIENT# - E-Mail recipient\n			#TAPPROVED# - Message topic is approved\n			#MAPPROVED# - Message is approved\n			#PATH2FORUM# - Message Url\n			#FROM_EMAIL# - E-Mail for From field of the EMail',100),
(52,'en','NEW_FORUM_PRIV','Private message for forum user','\n			#FROM_NAME# - Name of the sender\n			#FROM_EMAIL# - E-Mail of the sender\n			#TO_NAME# - Name of recipient\n			#TO_EMAIL# - E-Mail of recipient\n			#SUBJECT# - Topic\n			#MESSAGE# - Message\n			#MESSAGE_DATE# - Date',100),
(53,'en','NEW_FORUM_PRIVATE_MESSAGE','Private message for forum user','\n			#FROM_NAME# - Name of the sender\n			#FROM_USER_ID# - ID of the sender\n			#FROM_EMAIL# - E-Mail of the sender\n			#TO_NAME# - Name of recipient\n			#TO_USER_ID# - ID of recipient\n			#TO_EMAIL# - E-Mail of recipient\n			#SUBJECT# - Topic\n			#MESSAGE# - Message\n			#MESSAGE_DATE# - Date\n			#MESSAGE_LINK# - Link to message',100),
(54,'en','EDIT_FORUM_MESSAGE','Changing forum message','\n			#FORUM_ID# - Forum ID\n			#FORUM_NAME# - Forum name\n			#TOPIC_ID# - Topic ID\n			#MESSAGE_ID# - Message ID\n			#TOPIC_TITLE# - Topic title\n			#MESSAGE_TEXT# - Message text\n			#MESSAGE_DATE# - Message date\n			#AUTHOR# - Message author\n			#RECIPIENT# - E-Mail recipient\n			#TAPPROVED# - Message topic is approved\n			#MAPPROVED# - Message is approved\n			#PATH2FORUM# - Message Url\n			#FROM_EMAIL# - E-Mail for From field of the EMail',100),
(55,'ru','FORUM_NEW_MESSAGE_MAIL','Новое сообщение на форуме в режиме общения по E-Mail','#FORUM_NAME# - Название форума\n#AUTHOR# - Автор сообщения\n#FROM_EMAIL# - E-Mail для поля From письма\n#RECIPIENT# - Получатель сообщения\n#TOPIC_TITLE# - Тема сообщения\n#MESSAGE_TEXT# - Текст сообщения\n#PATH2FORUM# - Адрес сообщения\n#MESSAGE_DATE# - Дата сообщения\n#FORUM_EMAIL# - Е-Mail адрес для добавления сообщений на форум\n#FORUM_ID# - ID форума\n#TOPIC_ID# - ID темы \n#MESSAGE_ID# - ID сообщения\n#TAPPROVED# - Тема опубликована\n#MAPPROVED# - Сообщение опубликовано\n',100),
(56,'en','FORUM_NEW_MESSAGE_MAIL','New message at the forum (e-mail messaging mode)','#FORUM_NAME# - Forum name\n#AUTHOR# - Message author\n#FROM_EMAIL# - E-Mail in the &amp;From&amp; field\n#RECIPIENT# - Message recipient\n#TOPIC_TITLE# - Message subject\n#MESSAGE_TEXT# - Message text\n#PATH2FORUM# - Message URL\n#MESSAGE_DATE# - Message date\n#FORUM_EMAIL# - E-Mail to add messages to the forum \n#FORUM_ID# - Forum ID\n#TOPIC_ID# - Topic ID \n#MESSAGE_ID# - Message ID\n#TAPPROVED# - Topic approved and published\n#MAPPROVED# - Message approved and published\n',100),
(57,'ru','SALE_NEW_ORDER','Новый заказ','#ORDER_ID# - код заказа\n#ORDER_ACCOUNT_NUMBER_ENCODE# - код заказа(для ссылок)\n#ORDER_REAL_ID# - реальный ID заказа\n#ORDER_DATE# - дата заказа\n#ORDER_USER# - заказчик\n#PRICE# - сумма заказа\n#EMAIL# - E-Mail заказчика\n#BCC# - E-Mail скрытой копии\n#ORDER_LIST# - состав заказа\n#SALE_EMAIL# - E-Mail отдела продаж',100),
(58,'ru','SALE_NEW_ORDER_RECURRING','Новый заказ на продление подписки','#ORDER_ID# - код заказа\n#ORDER_ACCOUNT_NUMBER_ENCODE# - код заказа(для ссылок)\n#ORDER_REAL_ID# - реальный ID заказа\n#ORDER_DATE# - дата заказа\n#ORDER_USER# - заказчик\n#PRICE# - сумма заказа\n#EMAIL# - E-Mail заказчика\n#BCC# - E-Mail скрытой копии\n#ORDER_LIST# - состав заказа\n#SALE_EMAIL# - E-Mail отдела продаж',100),
(59,'ru','SALE_ORDER_REMIND_PAYMENT','Напоминание об оплате заказа','#ORDER_ID# - код заказа\n#ORDER_ACCOUNT_NUMBER_ENCODE# - код заказа(для ссылок)\n#ORDER_REAL_ID# - реальный ID заказа\n#ORDER_DATE# - дата заказа\n#ORDER_USER# - заказчик\n#PRICE# - сумма заказа\n#EMAIL# - E-Mail заказчика\n#BCC# - E-Mail скрытой копии\n#ORDER_LIST# - состав заказа\n#SALE_EMAIL# - E-Mail отдела продаж',100),
(60,'ru','SALE_ORDER_CANCEL','Отмена заказа','#ORDER_ID# - код заказа\n#ORDER_ACCOUNT_NUMBER_ENCODE# - код заказа(для ссылок)\n#ORDER_REAL_ID# - реальный ID заказа\n#ORDER_DATE# - дата заказа\n#EMAIL# - E-Mail пользователя\n#ORDER_CANCEL_DESCRIPTION# - причина отмены\n#SALE_EMAIL# - E-Mail отдела продаж',100),
(61,'ru','SALE_ORDER_PAID','Заказ оплачен','#ORDER_ID# - код заказа\n#ORDER_ACCOUNT_NUMBER_ENCODE# - код заказа(для ссылок)\n#ORDER_REAL_ID# - реальный ID заказа\n#ORDER_DATE# - дата заказа\n#EMAIL# - E-Mail пользователя\n#SALE_EMAIL# - E-Mail отдела продаж',100),
(62,'ru','SALE_ORDER_DELIVERY','Доставка заказа разрешена','#ORDER_ID# - код заказа\n#ORDER_ACCOUNT_NUMBER_ENCODE# - код заказа(для ссылок)\n#ORDER_REAL_ID# - реальный ID заказа\n#ORDER_DATE# - дата заказа\n#EMAIL# - E-Mail пользователя\n#SALE_EMAIL# - E-Mail отдела продаж',100),
(63,'ru','SALE_RECURRING_CANCEL','Подписка отменена','#ORDER_ID# - код заказа\n#ORDER_ACCOUNT_NUMBER_ENCODE# - код заказа(для ссылок)\n#ORDER_REAL_ID# - реальный ID заказа\n#ORDER_DATE# - дата заказа\n#EMAIL# - E-Mail пользователя\n#CANCELED_REASON# - причина отмены\n#SALE_EMAIL# - E-Mail отдела продаж',100),
(64,'ru','SALE_SUBSCRIBE_PRODUCT','Уведомление о поступлении товара','#USER_NAME# - имя пользователя\n#EMAIL# - email пользователя\n#NAME# - название товара\n#PAGE_URL# - детальная страница товара',100),
(65,'ru','SALE_ORDER_TRACKING_NUMBER','Уведомление об изменении идентификатора почтового отправления','#ORDER_ID# - код заказа\n#ORDER_ACCOUNT_NUMBER_ENCODE# - код заказа(для ссылок)\n#ORDER_REAL_ID# - реальный ID заказа\n#ORDER_DATE# - дата заказа\n#ORDER_USER# - заказчик\n#ORDER_TRACKING_NUMBER# - идентификатор почтового отправления\n#EMAIL# - E-Mail заказчика\n#BCC# - E-Mail скрытой копии\n#SALE_EMAIL# - E-Mail отдела продаж',100),
(66,'ru','SALE_STATUS_CHANGED_F','Изменение статуса заказа на  \"Выполнен\"','#ORDER_ID# - код заказа\n#ORDER_DATE# - дата заказа\n#ORDER_STATUS# - статус заказа\n#EMAIL# - E-Mail пользователя\n#ORDER_DESCRIPTION# - описание статуса заказа\n#TEXT# - текст\n#SALE_EMAIL# - E-Mail отдела продаж\n',100),
(67,'ru','SALE_STATUS_CHANGED_N','Изменение статуса заказа на  \"Принят, ожидается оплата\"','#ORDER_ID# - код заказа\n#ORDER_DATE# - дата заказа\n#ORDER_STATUS# - статус заказа\n#EMAIL# - E-Mail пользователя\n#ORDER_DESCRIPTION# - описание статуса заказа\n#TEXT# - текст\n#SALE_EMAIL# - E-Mail отдела продаж\n',100),
(68,'en','SALE_NEW_ORDER','New order','#ORDER_ID# - order ID\n#ORDER_ACCOUNT_NUMBER_ENCODE# - order ID (for URL\'s)\n#ORDER_REAL_ID# - real order ID\n#ORDER_DATE# - order date\n#ORDER_USER# - customer\n#PRICE# - order amount\n#EMAIL# - customer e-mail\n#BCC# - BCC e-mail\n#ORDER_LIST# - order contents\n#SALE_EMAIL# - sales dept. e-mail',100),
(69,'en','SALE_NEW_ORDER_RECURRING','New Order for Subscription Renewal','#ORDER_ID# - order ID\n#ORDER_ACCOUNT_NUMBER_ENCODE# - order ID (for URL\'s)\n#ORDER_REAL_ID# - real order ID\n#ORDER_DATE# - order date\n#ORDER_USER# - customer\n#PRICE# - order amount\n#EMAIL# - customer e-mail\n#BCC# - BCC e-mail\n#ORDER_LIST# - order contents\n#SALE_EMAIL# - sales dept. e-mail',100),
(70,'en','SALE_ORDER_REMIND_PAYMENT','Order Payment Reminder','#ORDER_ID# - order ID\n#ORDER_ACCOUNT_NUMBER_ENCODE# - order ID (for URL\'s)\n#ORDER_REAL_ID# - real order ID\n#ORDER_DATE# - order date\n#ORDER_USER# - customer\n#PRICE# - order amount\n#EMAIL# - customer e-mail\n#BCC# - BCC e-mail\n#ORDER_LIST# - order contents\n#SALE_EMAIL# - sales dept. e-mail',100),
(71,'en','SALE_ORDER_CANCEL','Cancel order','#ORDER_ID# - order ID\n#ORDER_ACCOUNT_NUMBER_ENCODE# - order ID (for URL\'s)\n#ORDER_REAL_ID# - real order ID\n#ORDER_DATE# - order date\n#EMAIL# - customer e-mail\n#ORDER_LIST# - order contents\n#ORDER_CANCEL_DESCRIPTION# - reason for cancellation\n#SALE_EMAIL# - sales dept. e-mail\n',100),
(72,'en','SALE_ORDER_PAID','Paid order','#ORDER_ID# - order ID\n#ORDER_ACCOUNT_NUMBER_ENCODE# - order ID (for URL\'s)\n#ORDER_REAL_ID# - real order ID\n#ORDER_DATE# - order date\n#EMAIL# - customer e-mail\n#SALE_EMAIL# - sales dept. e-mail',100),
(73,'en','SALE_ORDER_DELIVERY','Order delivery allowed','#ORDER_ID# - order ID\n#ORDER_ACCOUNT_NUMBER_ENCODE# - order ID (for URL\'s)\n#ORDER_REAL_ID# - real order ID\n#ORDER_DATE# - order date\n#EMAIL# - customer e-mail\n#SALE_EMAIL# - sales dept. e-mail',100),
(74,'en','SALE_RECURRING_CANCEL','Recurring payment canceled','#ORDER_ID# - order ID\n#ORDER_ACCOUNT_NUMBER_ENCODE# - order ID (for URL\'s)\n#ORDER_REAL_ID# - real order ID\n#ORDER_DATE# - order date\n#EMAIL# - customer e-mail\n#CANCELED_REASON# - reason for cancellation\n#SALE_EMAIL# - sales dept. e-mail',100),
(75,'en','SALE_SUBSCRIBE_PRODUCT','Back in stock notification','#USER_NAME# - user name\n#EMAIL# - user e-mail \n#NAME# - product name\n#PAGE_URL# - product details page',100),
(76,'en','SALE_ORDER_TRACKING_NUMBER','Notification of change in tracking number ','#ORDER_ID# - order ID\n#ORDER_ACCOUNT_NUMBER_ENCODE# - order ID (for URL\'s)\n#ORDER_REAL_ID# - real order ID\n#ORDER_DATE# - order date\n#ORDER_USER# - customer\n#ORDER_TRACKING_NUMBER# - tracking number\n#EMAIL# - customer e-mail\n#BCC# - BCC e-mail\n#SALE_EMAIL# - sales dept. e-mail',100),
(77,'en','SALE_STATUS_CHANGED_F','Changing order status to \"Выполнен\"','#ORDER_ID# - order ID\n#ORDER_DATE# - order date\n#ORDER_STATUS# - order status\n#EMAIL# - customer e-mail\n#ORDER_DESCRIPTION# - order status description\n#TEXT# - text\n#SALE_EMAIL# - Sales department e-mail\n',100),
(78,'en','SALE_STATUS_CHANGED_N','Changing order status to \"Принят, ожидается оплата\"','#ORDER_ID# - order ID\n#ORDER_DATE# - order date\n#ORDER_STATUS# - order status\n#EMAIL# - customer e-mail\n#ORDER_DESCRIPTION# - order status description\n#TEXT# - text\n#SALE_EMAIL# - Sales department e-mail\n',100),
(79,'ru','VIRUS_DETECTED','Обнаружен вирус','#EMAIL# - E-Mail администратора сайта (из настроек главного модуля)',100),
(80,'en','VIRUS_DETECTED','Virus detected','#EMAIL# - Site administrator\'s e-mail address (from the Kernel module settings)',100),
(81,'ru','SENDER_SUBSCRIBE_CONFIRM','Подтверждение подписки','#EMAIL# - адрес подписки\n#DATE# - дата добавления/изменения адреса\n#CONFIRM_URL# - адрес подтверждения\n#MAILING_LIST# - список подписок\n',100),
(82,'en','SENDER_SUBSCRIBE_CONFIRM','Confirm subscription','#EMAIL# - subscription URL\n#DATE# - the date the address was added or updated\n#CONFIRM_URL# - confirmation URL\n#MAILING_LIST# - subscriptions\n',100),
(83,'ru','SUBSCRIBE_CONFIRM','Подтверждение подписки','#ID# - идентификатор подписки\n#EMAIL# - адрес подписки\n#CONFIRM_CODE# - код подтверждения\n#SUBSCR_SECTION# - раздел, где находится страница редактирования подписки (задается в настройках)\n#USER_NAME# - имя подписчика (может отсутствовать)\n#DATE_SUBSCR# - дата добавления/изменения адреса\n',100),
(84,'en','SUBSCRIBE_CONFIRM','Confirmation of subscription','#ID# - subscription ID\n#EMAIL# - subscription email\n#CONFIRM_CODE# - confirmation code\n#SUBSCR_SECTION# - section with subscription edit page (specifies in the settings)\n#USER_NAME# - subscriber\'s name (optional)\n#DATE_SUBSCR# - date of adding/change of address\n',100),
(85,'ru','VOTE_FOR','Новый голос','#ID# - ID результата голосования\n#TIME# - время голосования\n#VOTE_TITLE# - наименование опроса\n#VOTE_DESCRIPTION# - описание опроса\n#VOTE_ID# - ID опроса\n#CHANNEL# - наименование группы опроса\n#CHANNEL_ID# - ID группы опроса\n#VOTER_ID# - ID проголосовавшего посетителя\n#USER_NAME# - ФИО пользователя\n#LOGIN# - логин\n#USER_ID# - ID пользователя\n#STAT_GUEST_ID# - ID посетителя модуля статистики\n#SESSION_ID# - ID сессии модуля статистики\n#IP# - IP адрес\n#VOTE_STATISTIC# - Сводная статистика опроса типа ( - Вопрос - Ответ )\n#URL# - Путь к опросу\n',100),
(86,'en','VOTE_FOR','New vote','#ID# - Vote result ID\n#TIME# - Time of vote\n#VOTE_TITLE# - Poll name\n#VOTE_DESCRIPTION# - Poll description\n#VOTE_ID# - Poll ID\n#CHANNEL# - Poll group name\n#CHANNEL_ID# - Poll group ID\n#VOTER_ID# - Voter\'s user ID\n#USER_NAME# - User full name\n#LOGIN# - login\n#USER_ID# - User ID\n#STAT_GUEST_ID# - Visitor ID in web analytics module\n#SESSION_ID# - Session ID in web analytics module\n#IP# - IP address\n#VOTE_STATISTIC# - Summary statistics of this poll type ( - Question - Answer)\n#URL# - Poll URL',100)	;
#	TC`b_favorite`utf8_unicode_ci	;
CREATE TABLE `b_favorite` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `C_SORT` int(18) NOT NULL DEFAULT '100',
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL` text COLLATE utf8_unicode_ci,
  `COMMENTS` text COLLATE utf8_unicode_ci,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_ID` int(11) DEFAULT NULL,
  `CODE_ID` int(18) DEFAULT NULL,
  `COMMON` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `MENU_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_file`utf8_unicode_ci	;
CREATE TABLE `b_file` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HEIGHT` int(18) DEFAULT NULL,
  `WIDTH` int(18) DEFAULT NULL,
  `FILE_SIZE` bigint(20) DEFAULT NULL,
  `CONTENT_TYPE` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'IMAGE',
  `SUBDIR` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILE_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ORIGINAL_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HANDLER_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EXTERNAL_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_FILE_EXTERNAL_ID` (`EXTERNAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_file_search`utf8_unicode_ci	;
CREATE TABLE `b_file_search` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SESS_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `F_PATH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `B_DIR` int(11) NOT NULL DEFAULT '0',
  `F_SIZE` int(11) NOT NULL DEFAULT '0',
  `F_TIME` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_filters`utf8_unicode_ci	;
CREATE TABLE `b_filters` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(18) DEFAULT NULL,
  `FILTER_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `FIELDS` text COLLATE utf8_unicode_ci NOT NULL,
  `COMMON` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRESET` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRESET_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(18) DEFAULT NULL,
  `SORT_FIELD` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_finder_dest`utf8_unicode_ci	;
CREATE TABLE `b_finder_dest` (
  `USER_ID` int(11) NOT NULL,
  `CODE` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `CODE_USER_ID` int(11) DEFAULT NULL,
  `CODE_TYPE` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONTEXT` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_USE_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`USER_ID`,`CODE`,`CONTEXT`),
  KEY `IX_FINDER_DEST` (`CODE_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form`utf8_unicode_ci	;
CREATE TABLE `b_form` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `BUTTON` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `C_SORT` int(18) DEFAULT '100',
  `FIRST_SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IMAGE_ID` int(18) DEFAULT NULL,
  `USE_CAPTCHA` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DESCRIPTION_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'html',
  `FORM_TEMPLATE` text COLLATE utf8_unicode_ci,
  `USE_DEFAULT_TEMPLATE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `SHOW_TEMPLATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MAIL_EVENT_TYPE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SHOW_RESULT_TEMPLATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRINT_RESULT_TEMPLATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EDIT_RESULT_TEMPLATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILTER_RESULT_TEMPLATE` text COLLATE utf8_unicode_ci,
  `TABLE_RESULT_TEMPLATE` text COLLATE utf8_unicode_ci,
  `USE_RESTRICTIONS` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `RESTRICT_USER` int(5) DEFAULT '0',
  `RESTRICT_TIME` int(10) DEFAULT '0',
  `RESTRICT_STATUS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STAT_EVENT1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STAT_EVENT2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STAT_EVENT3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_SID` (`SID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_2_group`utf8_unicode_ci	;
CREATE TABLE `b_form_2_group` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `GROUP_ID` int(18) NOT NULL DEFAULT '0',
  `PERMISSION` int(5) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`),
  KEY `IX_FORM_ID` (`FORM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_2_mail_template`utf8_unicode_ci	;
CREATE TABLE `b_form_2_mail_template` (
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `MAIL_TEMPLATE_ID` int(18) NOT NULL DEFAULT '0',
  PRIMARY KEY (`FORM_ID`,`MAIL_TEMPLATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_2_site`utf8_unicode_ci	;
CREATE TABLE `b_form_2_site` (
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`FORM_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_answer`utf8_unicode_ci	;
CREATE TABLE `b_form_answer` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FIELD_ID` int(18) NOT NULL DEFAULT '0',
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `MESSAGE` text COLLATE utf8_unicode_ci,
  `C_SORT` int(18) NOT NULL DEFAULT '100',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD_TYPE` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `FIELD_WIDTH` int(18) DEFAULT NULL,
  `FIELD_HEIGHT` int(18) DEFAULT NULL,
  `FIELD_PARAM` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_FIELD_ID` (`FIELD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_crm`utf8_unicode_ci	;
CREATE TABLE `b_form_crm` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `URL` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `AUTH_HASH` varchar(32) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_crm_field`utf8_unicode_ci	;
CREATE TABLE `b_form_crm_field` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `LINK_ID` int(18) NOT NULL DEFAULT '0',
  `FIELD_ID` int(18) DEFAULT '0',
  `FIELD_ALT` varchar(100) COLLATE utf8_unicode_ci DEFAULT '',
  `CRM_FIELD` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `ix_b_form_crm_field_1` (`LINK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_crm_link`utf8_unicode_ci	;
CREATE TABLE `b_form_crm_link` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `CRM_ID` int(18) NOT NULL DEFAULT '0',
  `LINK_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'M',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_b_form_crm_link_1` (`FORM_ID`,`CRM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_field`utf8_unicode_ci	;
CREATE TABLE `b_form_field` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `TITLE` text COLLATE utf8_unicode_ci,
  `TITLE_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `SID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `C_SORT` int(18) NOT NULL DEFAULT '100',
  `ADDITIONAL` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `REQUIRED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IN_FILTER` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IN_RESULTS_TABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IN_EXCEL_TABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `FIELD_TYPE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IMAGE_ID` int(18) DEFAULT NULL,
  `COMMENTS` text COLLATE utf8_unicode_ci,
  `FILTER_TITLE` text COLLATE utf8_unicode_ci,
  `RESULTS_TABLE_TITLE` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_FORM_ID` (`FORM_ID`),
  KEY `IX_SID` (`SID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_field_filter`utf8_unicode_ci	;
CREATE TABLE `b_form_field_filter` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FIELD_ID` int(18) NOT NULL DEFAULT '0',
  `PARAMETER_NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FILTER_TYPE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_FIELD_ID` (`FIELD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_field_validator`utf8_unicode_ci	;
CREATE TABLE `b_form_field_validator` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `FIELD_ID` int(18) NOT NULL DEFAULT '0',
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'y',
  `C_SORT` int(18) DEFAULT '100',
  `VALIDATOR_SID` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `PARAMS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_FORM_ID` (`FORM_ID`),
  KEY `IX_FIELD_ID` (`FIELD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_menu`utf8_unicode_ci	;
CREATE TABLE `b_form_menu` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `MENU` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_FORM_ID` (`FORM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_result`utf8_unicode_ci	;
CREATE TABLE `b_form_result` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `STATUS_ID` int(18) NOT NULL DEFAULT '0',
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `USER_ID` int(18) DEFAULT NULL,
  `USER_AUTH` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `STAT_GUEST_ID` int(18) DEFAULT NULL,
  `STAT_SESSION_ID` int(18) DEFAULT NULL,
  `SENT_TO_CRM` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `IX_FORM_ID` (`FORM_ID`),
  KEY `IX_STATUS_ID` (`STATUS_ID`),
  KEY `IX_SENT_TO_CRM` (`SENT_TO_CRM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_result_answer`utf8_unicode_ci	;
CREATE TABLE `b_form_result_answer` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `RESULT_ID` int(18) NOT NULL DEFAULT '0',
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `FIELD_ID` int(18) NOT NULL DEFAULT '0',
  `ANSWER_ID` int(18) DEFAULT NULL,
  `ANSWER_TEXT` text COLLATE utf8_unicode_ci,
  `ANSWER_TEXT_SEARCH` longtext COLLATE utf8_unicode_ci,
  `ANSWER_VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ANSWER_VALUE_SEARCH` longtext COLLATE utf8_unicode_ci,
  `USER_TEXT` longtext COLLATE utf8_unicode_ci,
  `USER_TEXT_SEARCH` longtext COLLATE utf8_unicode_ci,
  `USER_DATE` datetime DEFAULT NULL,
  `USER_FILE_ID` int(18) DEFAULT NULL,
  `USER_FILE_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_FILE_IS_IMAGE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_FILE_HASH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_FILE_SUFFIX` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_FILE_SIZE` int(18) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_RESULT_ID` (`RESULT_ID`),
  KEY `IX_FIELD_ID` (`FIELD_ID`),
  KEY `IX_ANSWER_ID` (`ANSWER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_status`utf8_unicode_ci	;
CREATE TABLE `b_form_status` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `C_SORT` int(18) NOT NULL DEFAULT '100',
  `TITLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DEFAULT_VALUE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CSS` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'statusgreen',
  `HANDLER_OUT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HANDLER_IN` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MAIL_EVENT_TYPE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_FORM_ID` (`FORM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_status_2_group`utf8_unicode_ci	;
CREATE TABLE `b_form_status_2_group` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `STATUS_ID` int(18) NOT NULL DEFAULT '0',
  `GROUP_ID` int(18) NOT NULL DEFAULT '0',
  `PERMISSION` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_FORM_STATUS_GROUP` (`STATUS_ID`,`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_form_status_2_mail_template`utf8_unicode_ci	;
CREATE TABLE `b_form_status_2_mail_template` (
  `STATUS_ID` int(18) NOT NULL DEFAULT '0',
  `MAIL_TEMPLATE_ID` int(18) NOT NULL DEFAULT '0',
  PRIMARY KEY (`STATUS_ID`,`MAIL_TEMPLATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum`utf8_unicode_ci	;
CREATE TABLE `b_forum` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `FORUM_GROUP_ID` int(11) DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `SORT` int(10) NOT NULL DEFAULT '150',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_HTML` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ALLOW_ANCHOR` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_BIU` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_IMG` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_VIDEO` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_LIST` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_QUOTE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_CODE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_FONT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_SMILES` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_UPLOAD` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ALLOW_TABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ALLOW_ALIGN` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_UPLOAD_EXT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ALLOW_MOVE_TOPIC` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_TOPIC_TITLED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ALLOW_NL2BR` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ALLOW_SIGNATURE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `PATH2FORUM_MESSAGE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ASK_GUEST_EMAIL` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `USE_CAPTCHA` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `INDEXATION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `DEDUPLICATION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `MODERATION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ORDER_BY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'P',
  `ORDER_DIRECTION` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'DESC',
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ru',
  `TOPICS` int(11) NOT NULL DEFAULT '0',
  `POSTS` int(11) NOT NULL DEFAULT '0',
  `LAST_POSTER_ID` int(11) DEFAULT NULL,
  `LAST_POSTER_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_POST_DATE` datetime DEFAULT NULL,
  `LAST_MESSAGE_ID` bigint(20) DEFAULT NULL,
  `POSTS_UNAPPROVED` int(11) DEFAULT '0',
  `ABS_LAST_POSTER_ID` int(11) DEFAULT NULL,
  `ABS_LAST_POSTER_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ABS_LAST_POST_DATE` datetime DEFAULT NULL,
  `ABS_LAST_MESSAGE_ID` bigint(20) DEFAULT NULL,
  `EVENT1` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'forum',
  `EVENT2` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'message',
  `EVENT3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HTML` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_FORUM_SORT` (`SORT`),
  KEY `IX_FORUM_ACTIVE` (`ACTIVE`),
  KEY `IX_FORUM_GROUP_ID` (`FORUM_GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum2site`utf8_unicode_ci	;
CREATE TABLE `b_forum2site` (
  `FORUM_ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `PATH2FORUM_MESSAGE` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`FORUM_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_dictionary`utf8_unicode_ci	;
CREATE TABLE `b_forum_dictionary` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_forum_dictionary`utf8_unicode_ci	;
INSERT INTO `b_forum_dictionary` VALUES 
(1,'[ru] Словарь слов','W'),
(2,'[ru] Словарь транслита','T'),
(3,'[en] Bad words','W'),
(4,'[en] Transliteration','T')	;
#	TC`b_forum_email`utf8_unicode_ci	;
CREATE TABLE `b_forum_email` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMAIL_FORUM_ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `FORUM_ID` int(11) NOT NULL,
  `SOCNET_GROUP_ID` int(11) DEFAULT NULL,
  `MAIL_FILTER_ID` int(11) NOT NULL,
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `USE_EMAIL` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL_GROUP` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUBJECT_SUF` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USE_SUBJECT` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL_TEMPLATES_MESSAGE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NOT_MEMBER_POST` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_FORUM_EMAIL_FORUM_SOC` (`FORUM_ID`,`SOCNET_GROUP_ID`),
  KEY `IX_B_FORUM_EMAIL_FILTER_ID` (`MAIL_FILTER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_file`utf8_unicode_ci	;
CREATE TABLE `b_forum_file` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FORUM_ID` int(18) DEFAULT NULL,
  `TOPIC_ID` int(20) DEFAULT NULL,
  `MESSAGE_ID` int(20) DEFAULT NULL,
  `FILE_ID` int(18) NOT NULL,
  `USER_ID` int(18) DEFAULT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `HITS` int(18) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_FORUM_FILE_FILE` (`FILE_ID`),
  KEY `IX_FORUM_FILE_FORUM` (`FORUM_ID`),
  KEY `IX_FORUM_FILE_TOPIC` (`TOPIC_ID`),
  KEY `IX_FORUM_FILE_MESSAGE` (`MESSAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_filter`utf8_unicode_ci	;
CREATE TABLE `b_forum_filter` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DICTIONARY_ID` int(11) DEFAULT NULL,
  `WORDS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PATTERN` text COLLATE utf8_unicode_ci,
  `REPLACEMENT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `USE_IT` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PATTERN_CREATE` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_FORUM_FILTER_2` (`USE_IT`),
  KEY `IX_B_FORUM_FILTER_3` (`PATTERN_CREATE`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_forum_filter`utf8_unicode_ci	;
INSERT INTO `b_forum_filter` VALUES 
(1,1,'*пизд*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])([^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*([ПпPp]+)([ИиIi]+)([ЗзZz3]+)([ДдDd]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(2,1,'*пизж*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])([^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*([ПпPp]+)([ИиIi]+)([ЗзZz3]+)([ЖжGg]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(3,1,'*сра%','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])([^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*([СсCc]+)([РрPpRr]+)([АаAa]+)([[Цц]+([Аа]+|[Оо]+)]+|[[Тт]+([Ьь]+|)[Сс]+[Яя]+]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(4,1,'анобляд*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([АаAa]+)([НнNn]+)([ОоOo]+)([БбBb]+)([ЛлLl]+)([Яя]+)([ДдDd]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(5,1,'взъеб*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвVv]+)([ЗзZz3]+)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(6,1,'бля','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([БбBb]+)([ЛлLl]+)([Яя]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(7,1,'долбоеб*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ДдDd]+)([ОоOo]+)([ЛлLl]+)([БбBb]+)([ОоOo]+)([ЁёЕеEe]+)([БбBb]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(8,1,'дуроеб*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ДдDd]+)([УуUu]+)([РрPpRr]+)([ОоOo]+)([ЁёЕеEe]+)([БбBb]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(9,1,'еби','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([ИиIi]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(10,1,'ебисти*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([ИиIi]+)([СсCc]+)([ТтTt]+)([ИиIi]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(11,1,'ебическ*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([ИиIi]+)([Чч]+)([ЁёЕеEe]+)([СсCc]+)([КкKk]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(12,1,'еблив*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([ЛлLl]+)([ИиIi]+)([ВвVv]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(13,1,'ебло*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([ЛлLl]+)([ОоOo]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(14,1,'еблыс*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([ЛлLl]+)([Ыы]+)([СсCc]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(15,1,'ебля','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([ЛлLl]+)([Яя]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(16,1,'ебс','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([СсCc]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(17,1,'ебукент*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([УуUu]+)([КкKk]+)([ЁёЕеEe]+)([НнNn]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(18,1,'ебурген*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([УуUu]+)([РрPpRr]+)([Гг]+)([ЁёЕеEe]+)([НнNn]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(19,1,'коноебит*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([КкKk]+)([ОоOo]+)([НнNn]+)([ОоOo]+)([ЁёЕеEe]+)([БбBb]+)([ИиIi]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(20,1,'мозгоеб*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([МмMm]+)([ОоOo]+)([ЗзZz3]+)([Гг]+)([ОоOo]+)([ЁёЕеEe]+)([БбBb]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(21,1,'мудоеб*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([МмMm]+)([УуUu]+)([ДдDd]+)([ОоOo]+)([ЁёЕеEe]+)([БбBb]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(22,1,'однохуйствен*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ОоOo]+)([ДдDd]+)([НнNn]+)([ОоOo]+)([ХхXx]+)([УуUu]+)([ЙйИиYy]+)([СсCc]+)([ТтTt]+)([ВвVv]+)([ЁёЕеEe]+)([НнNn]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(23,1,'охуе*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ОоOo]+)([ХхXx]+)([УуUu]+)([ЁёЕеEe]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(24,1,'охуи*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ОоOo]+)([ХхXx]+)([УуUu]+)([ИиIi]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(25,1,'охуя*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ОоOo]+)([ХхXx]+)([УуUu]+)([Яя]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(26,1,'разъеба*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([РрPpRr]+)([АаAa]+)([ЗзZz3]+)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([АаAa]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(27,1,'распиздон*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([РрPpRr]+)([АаAa]+)([СсCc]+)([ПпPp]+)([ИиIi]+)([ЗзZz3]+)([ДдDd]+)([ОоOo]+)([НнNn]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(28,1,'расхуюж*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([РрPpRr]+)([АаAa]+)([СсCc]+)([ХхXx]+)([УуUu]+)([Юю]+|[[Йй]+[Оо]+]+)([ЖжGg]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(29,1,'худоебин*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ДдDd]+)([ОоOo]+)([ЁёЕеEe]+)([БбBb]+)([ИиIi]+)([НнNn]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(30,1,'хуе','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ЁёЕеEe]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(31,1,'хуебрат*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ЁёЕеEe]+)([БбBb]+)([РрPpRr]+)([АаAa]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(32,1,'хуеглот*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ЁёЕеEe]+)([Гг]+)([ЛлLl]+)([ОоOo]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(33,1,'хуеплёт*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ЁёЕеEe]+)([ПпPp]+)([ЛлLl]+)([ЁёЕеEe]+|[[Йй]+[Оо]+]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(34,1,'хует*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ЁёЕеEe]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(35,1,'хуила','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ИиIi]+)([ЛлLl]+)([АаAa]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(36,1,'хул?','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ЛлLl]+).?)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(37,1,'хуя','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([Яя]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(38,1,'^бляд*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([БбBb]+)([ЛлLl]+)([Яя]+)([ДдDd]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(39,1,'^пидор*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ПпPp]+)([ИиIi]+)([ДдDd]+)([ОоOo]+)([РрPpRr]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(40,1,'^хуев*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ХхXx]+)([УуUu]+)([ЁёЕеEe]+)([ВвVv]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(41,1,'^хуем*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ХхXx]+)([УуUu]+)([ЁёЕеEe]+)([МмMm]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(42,1,'^хуй*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ХхXx]+)([УуUu]+)([ЙйИиYy]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(43,1,'^хуяк*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ХхXx]+)([УуUu]+)([Яя]+)([КкKk]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(44,1,'^хуям*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ХхXx]+)([УуUu]+)([Яя]+)([МмMm]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(45,1,'^хуяр*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ХхXx]+)([УуUu]+)([Яя]+)([РрPpRr]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(46,1,'^хуяч*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ХхXx]+)([УуUu]+)([Яя]+)([Чч]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(47,1,'^ъебал*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([АаAa]+)([ЛлLl]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(48,1,'^ъебан*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([АаAa]+)([НнNn]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(49,1,'^ъебар*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([АаAa]+)([РрPpRr]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(50,1,'^ъебат*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([АаAa]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(51,1,'^ъебен*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([ЁёЕеEe]+)([НнNn]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(52,1,'^ъеби','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([ИиIi]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(53,1,'^ъебис*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([ИиIi]+)([СсCc]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(54,1,'^ъебит*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([ИиIi]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(55,1,'^ъёбля*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+|[[Йй]+[Оо]+]+)([БбBb]+)([ЛлLl]+)([Яя]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(56,1,'^ъёбну*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+|[[Йй]+[Оо]+]+)([БбBb]+)([НнNn]+)([УуUu]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(57,1,'^ъебу','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([УуUu]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(58,1,'^ъебуч*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([УуUu]+)([Чч]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(59,1,'^ъебыв*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([Ыы]+)([ВвVv]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(60,1,'/(?<=[s.,;:!?-#*|[]()])(?![Вв][ЕеЁё][Бб])(([ВвЗзСс]+|[Ввы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)|)([ЬьЪъ]+|)([ЁёЕеEe]+|[Йй]+[Оо]+|[Yy]+[Oo]+)([BbБб]+))(?=[s.,;:!?-#*|[]()])/is','','','','Y','PTTRN'),
(61,3,'angry','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(a+n+g+r+y+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(62,3,'ass','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(a+s+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(63,3,'asshole','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(a+s+s+h+o+l+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(64,3,'banger','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+a+n+g+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(65,3,'bastard','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+a+s+t+a+r+d+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(66,3,'batter','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+a+t+t+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(67,3,'bicho','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+i+c+h+o+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(68,3,'bisexual','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+i+s+e+x+u+a+l+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(69,3,'bitch','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+i+t+c+h+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(70,3,'blumpkin','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+l+u+m+p+k+i+n+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(71,3,'booger','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+o+o+g+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(72,3,'bugger*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+u+g+g+e+r+[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(73,3,'bukakke','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+u+k+a+k+k+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(74,3,'bull','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+u+l+l+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(75,3,'bulldyke','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+u+l+l+d+y+k+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(76,3,'bullshit','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+u+l+l+s+h+i+t+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(77,3,'bunny','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+u+n+n+y+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(78,3,'bunnyfuck','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+u+n+n+y+f+u+c+k+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(79,3,'chocha','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+h+o+c+h+a+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(80,3,'chode','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+h+o+d+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(81,3,'clap','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+l+a+p+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(82,3,'coconuts','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+o+c+o+n+u+t+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(83,3,'cohones','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+o+h+o+n+e+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(84,3,'cojones','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+o+j+o+n+e+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(85,3,'coon','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+o+o+n+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(86,3,'cootch','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+o+o+t+c+h+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(87,3,'cooter','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+o+o+t+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(88,3,'cornhole','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+o+r+n+h+o+l+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(89,3,'cracka','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+r+a+c+k+a+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(90,3,'crap','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+r+a+p+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(91,3,'cum','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+u+m+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(92,3,'cunnilingus','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+u+n+n+i+l+i+n+g+u+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(93,3,'cunt*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+u+n+t+[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(94,3,'damn*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+a+m+n+[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(95,3,'dark*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+a+r+k+[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(96,3,'dick','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+i+c+k+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(97,3,'dickhead','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+i+c+k+h+e+a+d+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(98,3,'diddle','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+i+d+d+l+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(99,3,'dildo','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+i+l+d+o+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(100,3,'dilhole','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+i+l+h+o+l+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(101,3,'dingleberry','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+i+n+g+l+e+b+e+r+r+y+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(102,3,'doodle','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+o+o+d+l+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(103,3,'dork','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+o+r+k+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(104,3,'dumpster','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+u+m+p+s+t+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(105,3,'faggot','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(f+a+g+g+o+t+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(106,3,'fart','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(f+a+r+t+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(107,3,'frig','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(f+r+i+g+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(108,3,'fuck*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(f+u+c+k+[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(109,3,'fucker','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(f+u+c+k+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(110,3,'giz','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(g+i+z+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(111,3,'goatse','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(g+o+a+t+s+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(112,3,'gook','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(g+o+o+k+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(113,3,'gringo','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(g+r+i+n+g+o+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(114,3,'hobo','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(h+o+b+o+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(115,3,'honky','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(h+o+n+k+y+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(116,3,'jackass','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(j+a+c+k+a+s+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(117,3,'jackoff','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(j+a+c+k+o+f+f+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(118,3,'jerkoff','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(j+e+r+k+o+f+f+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(119,3,'jiggaboo','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(j+i+g+g+a+b+o+o+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(120,3,'jizz','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(j+i+z+z+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(121,3,'kike','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(k+i+k+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(122,3,'mayo','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(m+a+y+o+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(123,3,'moose','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(m+o+o+s+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(124,3,'nigg*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(n+i+g+g+[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(125,3,'paki','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(p+a+k+i+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(126,3,'pecker','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(p+e+c+k+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(127,3,'piss','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(p+i+s+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(128,3,'poonanni','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(p+o+o+n+a+n+n+i+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(129,3,'poontang','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(p+o+o+n+t+a+n+g+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(130,3,'prick','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(p+r+i+c+k+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(131,3,'punch','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(p+u+n+c+h+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(132,3,'queef','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(q+u+e+e+f+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(133,3,'rogue','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(r+o+g+u+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(134,3,'sanchez','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(s+a+n+c+h+e+z+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(135,3,'schlong','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(s+c+h+l+o+n+g+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(136,3,'shit','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(s+h+i+t+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(137,3,'skank','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(s+k+a+n+k+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(138,3,'spaz','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(s+p+a+z+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(139,3,'spic','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(s+p+i+c+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(140,3,'teabag*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(t+e+a+b+a+g+[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(141,3,'tits','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(t+i+t+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(142,3,'twat','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(t+w+a+t+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(143,3,'twot','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(t+w+o+t+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(144,3,'vart','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(v+a+r+t+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(145,3,'wanker','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(w+a+n+k+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(146,3,'waste','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(w+a+s+t+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(147,3,'wetback','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(w+e+t+b+a+c+k+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(148,3,'whore','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(w+h+o+r+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(149,3,'wigger','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(w+i+g+g+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(150,3,'wog','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(w+o+g+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
(151,3,'wop','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(w+o+p+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL')	;
#	TC`b_forum_group`utf8_unicode_ci	;
CREATE TABLE `b_forum_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SORT` int(11) NOT NULL DEFAULT '150',
  `PARENT_ID` int(11) DEFAULT NULL,
  `LEFT_MARGIN` int(11) DEFAULT NULL,
  `RIGHT_MARGIN` int(11) DEFAULT NULL,
  `DEPTH_LEVEL` int(11) DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_group_lang`utf8_unicode_ci	;
CREATE TABLE `b_forum_group_lang` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FORUM_GROUP_ID` int(11) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_FORUM_GROUP` (`FORUM_GROUP_ID`,`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_letter`utf8_unicode_ci	;
CREATE TABLE `b_forum_letter` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DICTIONARY_ID` int(11) DEFAULT '0',
  `LETTER` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REPLACEMENT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_forum_letter`utf8_unicode_ci	;
INSERT INTO `b_forum_letter` VALUES 
(1,2,'а','АаAa'),
(2,2,'б','БбBb'),
(3,2,'в','ВвVv'),
(4,2,'г','Гг'),
(5,2,'д','ДдDd'),
(6,2,'е','ЁёЕеEe'),
(7,2,'ё','ЁёЕеEe, [Йй]+[Оо]+'),
(8,2,'ж','ЖжGg'),
(9,2,'з','ЗзZz3'),
(10,2,'и','ИиIi'),
(11,2,'й','ЙйИиYy'),
(12,2,'к','КкKk'),
(13,2,'л','ЛлLl'),
(14,2,'м','МмMm'),
(15,2,'н','НнNn'),
(16,2,'о','ОоOo'),
(17,2,'п','ПпPp'),
(18,2,'р','РрPpRr'),
(19,2,'с','СсCc'),
(20,2,'т','ТтTt'),
(21,2,'у','УуUu'),
(22,2,'ф','ФфFf'),
(23,2,'х','ХхXx'),
(24,2,'ц','ЦцCc'),
(25,2,'ч','Чч'),
(26,2,'ш','Шш'),
(27,2,'щ','Щщ'),
(28,2,'ь','ЪъЬь\"\','),
(29,2,'ы','Ыы'),
(30,2,'ъ','ЪъЬь\"\','),
(31,2,'э','Ээ'),
(32,2,'ю','Юю, [Йй]+[Оо]+'),
(33,2,'я','Яя'),
(34,2,'%','[Цц]+([Аа]+|[Оо]+), [Тт]+([Ьь]+|)[Сс]+[Яя]+'),
(35,2,'^',',ВвЗзСс,ВвЫы,ДдОо,ЗзАа,ИиЗзСс,НнАа,НнЕе,ОоТт,([Пп]*[Ее]+[Рр]+[Ее]+)'),
(36,2,'тся','%'),
(37,2,'ться','%')	;
#	TC`b_forum_message`utf8_unicode_ci	;
CREATE TABLE `b_forum_message` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `FORUM_ID` int(10) NOT NULL,
  `TOPIC_ID` bigint(20) NOT NULL,
  `USE_SMILES` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NEW_TOPIC` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `APPROVED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SOURCE_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'WEB',
  `POST_DATE` datetime NOT NULL,
  `POST_MESSAGE` text COLLATE utf8_unicode_ci,
  `POST_MESSAGE_HTML` text COLLATE utf8_unicode_ci,
  `POST_MESSAGE_FILTER` text COLLATE utf8_unicode_ci,
  `POST_MESSAGE_CHECK` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ATTACH_IMG` int(11) DEFAULT NULL,
  `PARAM1` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PARAM2` int(11) DEFAULT NULL,
  `AUTHOR_ID` int(10) DEFAULT NULL,
  `AUTHOR_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AUTHOR_EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AUTHOR_IP` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AUTHOR_REAL_IP` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GUEST_ID` int(10) DEFAULT NULL,
  `EDITOR_ID` int(10) DEFAULT NULL,
  `EDITOR_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EDITOR_EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EDIT_REASON` text COLLATE utf8_unicode_ci,
  `EDIT_DATE` datetime DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HTML` text COLLATE utf8_unicode_ci,
  `MAIL_HEADER` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_FORUM_MESSAGE_FORUM` (`FORUM_ID`,`APPROVED`),
  KEY `IX_FORUM_MESSAGE_TOPIC` (`TOPIC_ID`,`APPROVED`,`ID`),
  KEY `IX_FORUM_MESSAGE_AUTHOR` (`AUTHOR_ID`,`APPROVED`,`FORUM_ID`,`ID`),
  KEY `IX_FORUM_MESSAGE_APPROVED` (`APPROVED`),
  KEY `IX_FORUM_MESSAGE_PARAM2` (`PARAM2`),
  KEY `IX_FORUM_MESSAGE_XML_ID` (`XML_ID`),
  KEY `IX_FORUM_MESSAGE_DATE_AUTHOR_ID` (`POST_DATE`,`AUTHOR_ID`),
  KEY `IX_FORUM_MESSAGE_AUTHOR_TOPIC_ID` (`AUTHOR_ID`,`TOPIC_ID`,`ID`),
  KEY `IX_FORUM_MESSAGE_AUTHOR_FORUM_ID` (`AUTHOR_ID`,`FORUM_ID`,`ID`,`APPROVED`,`TOPIC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_perms`utf8_unicode_ci	;
CREATE TABLE `b_forum_perms` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FORUM_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `PERMISSION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'M',
  PRIMARY KEY (`ID`),
  KEY `IX_FORUM_PERMS_FORUM` (`FORUM_ID`,`GROUP_ID`),
  KEY `IX_FORUM_PERMS_GROUP` (`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_pm_folder`utf8_unicode_ci	;
CREATE TABLE `b_forum_pm_folder` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `SORT` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_FORUM_PM_FOLDER_USER_IST` (`USER_ID`,`ID`,`SORT`,`TITLE`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_forum_pm_folder`utf8_unicode_ci	;
INSERT INTO `b_forum_pm_folder` VALUES 
(1,'SYSTEM_FOLDER_1',0,0),
(2,'SYSTEM_FOLDER_2',0,0),
(3,'SYSTEM_FOLDER_3',0,0),
(4,'SYSTEM_FOLDER_4',0,0)	;
#	TC`b_forum_points`utf8_unicode_ci	;
CREATE TABLE `b_forum_points` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MIN_POINTS` int(11) NOT NULL,
  `CODE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VOTES` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_FORUM_P_MP` (`MIN_POINTS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_points2post`utf8_unicode_ci	;
CREATE TABLE `b_forum_points2post` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MIN_NUM_POSTS` int(11) NOT NULL,
  `POINTS_PER_POST` decimal(18,4) NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_FORUM_P2P_MNP` (`MIN_NUM_POSTS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_points_lang`utf8_unicode_ci	;
CREATE TABLE `b_forum_points_lang` (
  `POINTS_ID` int(11) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`POINTS_ID`,`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_private_message`utf8_unicode_ci	;
CREATE TABLE `b_forum_private_message` (
  `ID` bigint(10) NOT NULL AUTO_INCREMENT,
  `AUTHOR_ID` int(11) DEFAULT '0',
  `RECIPIENT_ID` int(11) DEFAULT '0',
  `POST_DATE` datetime DEFAULT NULL,
  `POST_SUBJ` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `POST_MESSAGE` text COLLATE utf8_unicode_ci NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `FOLDER_ID` int(11) NOT NULL,
  `IS_READ` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REQUEST_IS_READ` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USE_SMILES` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_FORUM_PM_USER` (`USER_ID`),
  KEY `IX_B_FORUM_PM_AFR` (`AUTHOR_ID`,`FOLDER_ID`,`IS_READ`),
  KEY `IX_B_FORUM_PM_UFP` (`USER_ID`,`FOLDER_ID`,`POST_DATE`),
  KEY `IX_B_FORUM_PM_POST_DATE` (`POST_DATE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_rank`utf8_unicode_ci	;
CREATE TABLE `b_forum_rank` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CODE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MIN_NUM_POSTS` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_rank_lang`utf8_unicode_ci	;
CREATE TABLE `b_forum_rank_lang` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RANK_ID` int(11) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_FORUM_RANK` (`RANK_ID`,`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_stat`utf8_unicode_ci	;
CREATE TABLE `b_forum_stat` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(10) DEFAULT NULL,
  `IP_ADDRESS` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PHPSESSID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_VISIT` datetime DEFAULT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORUM_ID` smallint(5) NOT NULL DEFAULT '0',
  `TOPIC_ID` int(10) DEFAULT NULL,
  `SHOW_NAME` varchar(101) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_FORUM_STAT_SITE_ID` (`SITE_ID`,`LAST_VISIT`),
  KEY `IX_B_FORUM_STAT_TOPIC_ID` (`TOPIC_ID`,`LAST_VISIT`),
  KEY `IX_B_FORUM_STAT_FORUM_ID` (`FORUM_ID`,`LAST_VISIT`),
  KEY `IX_B_FORUM_STAT_PHPSESSID` (`PHPSESSID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_subscribe`utf8_unicode_ci	;
CREATE TABLE `b_forum_subscribe` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(10) NOT NULL,
  `FORUM_ID` int(10) NOT NULL,
  `TOPIC_ID` int(10) DEFAULT NULL,
  `START_DATE` datetime NOT NULL,
  `LAST_SEND` int(10) DEFAULT NULL,
  `NEW_TOPIC_ONLY` char(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ru',
  `SOCNET_GROUP_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_FORUM_SUBSCRIBE_USER` (`USER_ID`,`FORUM_ID`,`TOPIC_ID`,`SOCNET_GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_topic`utf8_unicode_ci	;
CREATE TABLE `b_forum_topic` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `FORUM_ID` int(10) NOT NULL,
  `TOPIC_ID` bigint(20) DEFAULT NULL,
  `TITLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TITLE_SEO` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAGS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ICON` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `APPROVED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(10) NOT NULL DEFAULT '150',
  `VIEWS` int(10) NOT NULL DEFAULT '0',
  `USER_START_ID` int(10) DEFAULT NULL,
  `USER_START_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `START_DATE` datetime NOT NULL,
  `POSTS` int(10) NOT NULL DEFAULT '0',
  `LAST_POSTER_ID` int(10) DEFAULT NULL,
  `LAST_POSTER_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_POST_DATE` datetime NOT NULL,
  `LAST_MESSAGE_ID` bigint(20) DEFAULT NULL,
  `POSTS_UNAPPROVED` int(11) DEFAULT '0',
  `ABS_LAST_POSTER_ID` int(10) DEFAULT NULL,
  `ABS_LAST_POSTER_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ABS_LAST_POST_DATE` datetime DEFAULT NULL,
  `ABS_LAST_MESSAGE_ID` bigint(20) DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HTML` text COLLATE utf8_unicode_ci,
  `SOCNET_GROUP_ID` int(10) DEFAULT NULL,
  `OWNER_ID` int(10) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_FORUM_TOPIC_FORUM` (`FORUM_ID`,`APPROVED`),
  KEY `IX_FORUM_TOPIC_APPROVED` (`APPROVED`),
  KEY `IX_FORUM_TOPIC_ABS_L_POST_DATE` (`ABS_LAST_POST_DATE`),
  KEY `IX_FORUM_TOPIC_LAST_POST_DATE` (`LAST_POST_DATE`),
  KEY `IX_FORUM_TOPIC_USER_START_ID` (`USER_START_ID`),
  KEY `IX_FORUM_TOPIC_DATE_USER_START_ID` (`START_DATE`,`USER_START_ID`),
  KEY `IX_FORUM_TOPIC_XML_ID` (`XML_ID`),
  KEY `IX_FORUM_TOPIC_TITLE_SEO` (`FORUM_ID`,`TITLE_SEO`),
  KEY `IX_FORUM_TOPIC_TITLE_SEO2` (`TITLE_SEO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_user`utf8_unicode_ci	;
CREATE TABLE `b_forum_user` (
  `ID` bigint(10) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(10) NOT NULL,
  `ALIAS` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IP_ADDRESS` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AVATAR` int(10) DEFAULT NULL,
  `NUM_POSTS` int(10) DEFAULT '0',
  `INTERESTS` text COLLATE utf8_unicode_ci,
  `LAST_POST` int(10) DEFAULT NULL,
  `ALLOW_POST` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `LAST_VISIT` datetime NOT NULL,
  `DATE_REG` date NOT NULL,
  `REAL_IP_ADDRESS` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SIGNATURE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SHOW_NAME` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `RANK_ID` int(11) DEFAULT NULL,
  `POINTS` int(11) NOT NULL DEFAULT '0',
  `HIDE_FROM_ONLINE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SUBSC_GROUP_MESSAGE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SUBSC_GET_MY_MESSAGE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_FORUM_USER_USER6` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_user_forum`utf8_unicode_ci	;
CREATE TABLE `b_forum_user_forum` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) DEFAULT NULL,
  `FORUM_ID` int(11) DEFAULT NULL,
  `LAST_VISIT` datetime DEFAULT NULL,
  `MAIN_LAST_VISIT` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_FORUM_USER_FORUM_ID1` (`USER_ID`,`FORUM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_user_points`utf8_unicode_ci	;
CREATE TABLE `b_forum_user_points` (
  `FROM_USER_ID` int(11) NOT NULL,
  `TO_USER_ID` int(11) NOT NULL,
  `POINTS` int(11) NOT NULL DEFAULT '0',
  `DATE_UPDATE` datetime DEFAULT NULL,
  PRIMARY KEY (`FROM_USER_ID`,`TO_USER_ID`),
  KEY `IX_B_FORUM_USER_POINTS_TO_USER` (`TO_USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_forum_user_topic`utf8_unicode_ci	;
CREATE TABLE `b_forum_user_topic` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TOPIC_ID` int(11) NOT NULL DEFAULT '0',
  `USER_ID` int(11) NOT NULL DEFAULT '0',
  `FORUM_ID` int(11) DEFAULT NULL,
  `LAST_VISIT` datetime DEFAULT NULL,
  PRIMARY KEY (`TOPIC_ID`,`USER_ID`),
  KEY `ID` (`ID`),
  KEY `IX_B_FORUM_USER_FORUM_ID2` (`USER_ID`,`FORUM_ID`,`TOPIC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_group`utf8_unicode_ci	;
CREATE TABLE `b_group` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `C_SORT` int(18) NOT NULL DEFAULT '100',
  `ANONYMOUS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECURITY_POLICY` text COLLATE utf8_unicode_ci,
  `STRING_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_group`utf8_unicode_ci	;
INSERT INTO `b_group` VALUES 
(1,'2016-10-18 09:08:06','Y',1,'N','Администраторы','Полный доступ к управлению сайтом.','a:12:{s:15:\"SESSION_TIMEOUT\";i:15;s:15:\"SESSION_IP_MASK\";s:15:\"255.255.255.255\";s:13:\"MAX_STORE_NUM\";i:1;s:13:\"STORE_IP_MASK\";s:15:\"255.255.255.255\";s:13:\"STORE_TIMEOUT\";i:4320;s:17:\"CHECKWORD_TIMEOUT\";i:60;s:15:\"PASSWORD_LENGTH\";i:10;s:18:\"PASSWORD_UPPERCASE\";s:1:\"Y\";s:18:\"PASSWORD_LOWERCASE\";s:1:\"Y\";s:15:\"PASSWORD_DIGITS\";s:1:\"Y\";s:20:\"PASSWORD_PUNCTUATION\";s:1:\"Y\";s:14:\"LOGIN_ATTEMPTS\";i:3;}',\N),
(2,'2016-10-18 08:58:51','Y',2,'Y','Все пользователи (в том числе неавторизованные)','Все пользователи, включая неавторизованных.',\N,\N),
(3,'2016-10-18 08:58:51','Y',3,'N','Пользователи, имеющие право голосовать за рейтинг','В эту группу пользователи добавляются автоматически.',\N,'RATING_VOTE'),
(4,'2016-10-18 08:58:51','Y',4,'N','Пользователи имеющие право голосовать за авторитет','В эту группу пользователи добавляются автоматически.',\N,'RATING_VOTE_AUTHORITY'),
(5,'2016-10-18 09:08:06','Y',3,'N','Зарегистрированные пользователи',\N,\N,'REGISTERED_USERS'),
(6,'2016-10-18 09:08:06','Y',4,'N','Пользователи панели управления',\N,\N,'CONTROL_PANEL_USERS')	;
#	TC`b_group_collection_task`utf8_unicode_ci	;
CREATE TABLE `b_group_collection_task` (
  `GROUP_ID` int(11) NOT NULL,
  `TASK_ID` int(11) NOT NULL,
  `COLLECTION_ID` int(11) NOT NULL,
  PRIMARY KEY (`GROUP_ID`,`TASK_ID`,`COLLECTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_group_subordinate`utf8_unicode_ci	;
CREATE TABLE `b_group_subordinate` (
  `ID` int(18) NOT NULL,
  `AR_SUBGROUP_ID` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_group_task`utf8_unicode_ci	;
CREATE TABLE `b_group_task` (
  `GROUP_ID` int(18) NOT NULL,
  `TASK_ID` int(18) NOT NULL,
  `EXTERNAL_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`GROUP_ID`,`TASK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_group_task`utf8_unicode_ci	;
INSERT INTO `b_group_task` VALUES 
(5,2,''),
(6,2,'')	;
#	TC`b_hlblock_entity`utf8_unicode_ci	;
CREATE TABLE `b_hlblock_entity` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `TABLE_NAME` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_hot_keys`utf8_unicode_ci	;
CREATE TABLE `b_hot_keys` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `KEYS_STRING` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `CODE_ID` int(18) NOT NULL,
  `USER_ID` int(18) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ix_b_hot_keys_co_u` (`CODE_ID`,`USER_ID`),
  KEY `ix_hot_keys_code` (`CODE_ID`),
  KEY `ix_hot_keys_user` (`USER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_hot_keys`utf8_unicode_ci	;
INSERT INTO `b_hot_keys` VALUES 
(1,'Ctrl+Alt+85',139,0),
(2,'Ctrl+Alt+80',17,0),
(3,'Ctrl+Alt+70',120,0),
(4,'Ctrl+Alt+68',117,0),
(5,'Ctrl+Alt+81',3,0),
(6,'Ctrl+Alt+75',106,0),
(7,'Ctrl+Alt+79',133,0),
(8,'Ctrl+Alt+70',121,0),
(9,'Ctrl+Alt+69',118,0),
(10,'Ctrl+Shift+83',87,0),
(11,'Ctrl+Shift+88',88,0),
(12,'Ctrl+Shift+76',89,0)	;
#	TC`b_hot_keys_code`utf8_unicode_ci	;
CREATE TABLE `b_hot_keys_code` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `CLASS_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COMMENTS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TITLE_OBJ` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_CUSTOM` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`),
  KEY `ix_hot_keys_code_cn` (`CLASS_NAME`),
  KEY `ix_hot_keys_code_url` (`URL`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_hot_keys_code`utf8_unicode_ci	;
INSERT INTO `b_hot_keys_code` VALUES 
(3,'CAdminTabControl','NextTab();','HK_DB_CADMINTC','HK_DB_CADMINTC_C','tab-container','',0),
(5,'btn_new','var d=BX (\'btn_new\'); if (d) location.href = d.href;','HK_DB_BUT_ADD','HK_DB_BUT_ADD_C','btn_new','',0),
(6,'btn_excel','var d=BX(\'btn_excel\'); if (d) location.href = d.href;','HK_DB_BUT_EXL','HK_DB_BUT_EXL_C','btn_excel','',0),
(7,'btn_settings','var d=BX(\'btn_settings\'); if (d) location.href = d.href;','HK_DB_BUT_OPT','HK_DB_BUT_OPT_C','btn_settings','',0),
(8,'btn_list','var d=BX(\'btn_list\'); if (d) location.href = d.href;','HK_DB_BUT_LST','HK_DB_BUT_LST_C','btn_list','',0),
(9,'Edit_Save_Button','var d=BX .findChild(document, {attribute: {\'name\': \'save\'}}, true );  if (d) d.click();','HK_DB_BUT_SAVE','HK_DB_BUT_SAVE_C','Edit_Save_Button','',0),
(10,'btn_delete','var d=BX(\'btn_delete\'); if (d) location.href = d.href;','HK_DB_BUT_DEL','HK_DB_BUT_DEL_C','btn_delete','',0),
(12,'CAdminFilter','var d=BX .findChild(document, {attribute: {\'name\': \'find\'}}, true ); if (d) d.focus();','HK_DB_FLT_FND','HK_DB_FLT_FND_C','find','',0),
(13,'CAdminFilter','var d=BX .findChild(document, {attribute: {\'name\': \'set_filter\'}}, true );  if (d) d.click();','HK_DB_FLT_BUT_F','HK_DB_FLT_BUT_F_C','set_filter','',0),
(14,'CAdminFilter','var d=BX .findChild(document, {attribute: {\'name\': \'del_filter\'}}, true );  if (d) d.click();','HK_DB_FLT_BUT_CNL','HK_DB_FLT_BUT_CNL_C','del_filter','',0),
(15,'bx-panel-admin-button-help-icon-id','var d=BX(\'bx-panel-admin-button-help-icon-id\'); if (d) location.href = d.href;','HK_DB_BUT_HLP','HK_DB_BUT_HLP_C','bx-panel-admin-button-help-icon-id','',0),
(17,'Global','BXHotKeys.ShowSettings();','HK_DB_SHW_L','HK_DB_SHW_L_C','bx-panel-hotkeys','',0),
(19,'Edit_Apply_Button','var d=BX .findChild(document, {attribute: {\'name\': \'apply\'}}, true );  if (d) d.click();','HK_DB_BUT_APPL','HK_DB_BUT_APPL_C','Edit_Apply_Button','',0),
(20,'Edit_Cancel_Button','var d=BX .findChild(document, {attribute: {\'name\': \'cancel\'}}, true );  if (d) d.click();','HK_DB_BUT_CANCEL','HK_DB_BUT_CANCEL_C','Edit_Cancel_Button','',0),
(54,'top_panel_org_fav','','-=AUTONAME=-',\N,'top_panel_org_fav',\N,0),
(55,'top_panel_module_settings','','-=AUTONAME=-',\N,'top_panel_module_settings','',0),
(56,'top_panel_interface_settings','','-=AUTONAME=-',\N,'top_panel_interface_settings','',0),
(57,'top_panel_help','','-=AUTONAME=-',\N,'top_panel_help','',0),
(58,'top_panel_bizproc_tasks','','-=AUTONAME=-',\N,'top_panel_bizproc_tasks','',0),
(59,'top_panel_add_fav','','-=AUTONAME=-',\N,'top_panel_add_fav',\N,0),
(60,'top_panel_create_page','','-=AUTONAME=-',\N,'top_panel_create_page','',0),
(62,'top_panel_create_folder','','-=AUTONAME=-',\N,'top_panel_create_folder','',0),
(63,'top_panel_edit_page','','-=AUTONAME=-',\N,'top_panel_edit_page','',0),
(64,'top_panel_page_prop','','-=AUTONAME=-',\N,'top_panel_page_prop','',0),
(65,'top_panel_edit_page_html','','-=AUTONAME=-',\N,'top_panel_edit_page_html','',0),
(67,'top_panel_edit_page_php','','-=AUTONAME=-',\N,'top_panel_edit_page_php','',0),
(68,'top_panel_del_page','','-=AUTONAME=-',\N,'top_panel_del_page','',0),
(69,'top_panel_folder_prop','','-=AUTONAME=-',\N,'top_panel_folder_prop','',0),
(70,'top_panel_access_folder_new','','-=AUTONAME=-',\N,'top_panel_access_folder_new','',0),
(71,'main_top_panel_struct_panel','','-=AUTONAME=-',\N,'main_top_panel_struct_panel','',0),
(72,'top_panel_cache_page','','-=AUTONAME=-',\N,'top_panel_cache_page','',0),
(73,'top_panel_cache_comp','','-=AUTONAME=-',\N,'top_panel_cache_comp','',0),
(74,'top_panel_cache_not','','-=AUTONAME=-',\N,'top_panel_cache_not','',0),
(75,'top_panel_edit_mode','','-=AUTONAME=-',\N,'top_panel_edit_mode','',0),
(76,'top_panel_templ_site_css','','-=AUTONAME=-',\N,'top_panel_templ_site_css','',0),
(77,'top_panel_templ_templ_css','','-=AUTONAME=-',\N,'top_panel_templ_templ_css','',0),
(78,'top_panel_templ_site','','-=AUTONAME=-',\N,'top_panel_templ_site','',0),
(81,'top_panel_debug_time','','-=AUTONAME=-',\N,'top_panel_debug_time','',0),
(82,'top_panel_debug_incl','','-=AUTONAME=-',\N,'top_panel_debug_incl','',0),
(83,'top_panel_debug_sql','','-=AUTONAME=-',\N,'top_panel_debug_sql',\N,0),
(84,'top_panel_debug_compr','','-=AUTONAME=-',\N,'top_panel_debug_compr','',0),
(85,'MTP_SHORT_URI1','','-=AUTONAME=-',\N,'MTP_SHORT_URI1','',0),
(86,'MTP_SHORT_URI_LIST','','-=AUTONAME=-',\N,'MTP_SHORT_URI_LIST','',0),
(87,'FMST_PANEL_STICKER_ADD','','-=AUTONAME=-',\N,'FMST_PANEL_STICKER_ADD','',0),
(88,'FMST_PANEL_STICKERS_SHOW','','-=AUTONAME=-',\N,'FMST_PANEL_STICKERS_SHOW','',0),
(89,'FMST_PANEL_CUR_STICKER_LIST','','-=AUTONAME=-',\N,'FMST_PANEL_CUR_STICKER_LIST','',0),
(90,'FMST_PANEL_ALL_STICKER_LIST','','-=AUTONAME=-',\N,'FMST_PANEL_ALL_STICKER_LIST','',0),
(91,'top_panel_menu','var d=BX(\"bx-panel-menu\"); if (d) d.click();','-=AUTONAME=-',\N,'bx-panel-menu','',0),
(92,'top_panel_admin','var d=BX(\'bx-panel-admin-tab\'); if (d) location.href = d.href;','-=AUTONAME=-',\N,'bx-panel-admin-tab','',0),
(93,'admin_panel_site','var d=BX(\'bx-panel-view-tab\'); if (d) location.href = d.href;','-=AUTONAME=-',\N,'bx-panel-view-tab','',0),
(94,'admin_panel_admin','var d=BX(\'bx-panel-admin-tab\'); if (d) location.href = d.href;','-=AUTONAME=-',\N,'bx-panel-admin-tab','',0),
(96,'top_panel_folder_prop_new','','-=AUTONAME=-',\N,'top_panel_folder_prop_new','',0),
(97,'main_top_panel_structure','','-=AUTONAME=-',\N,'main_top_panel_structure','',0),
(98,'top_panel_clear_cache','','-=AUTONAME=-',\N,'top_panel_clear_cache','',0),
(99,'top_panel_templ','','-=AUTONAME=-',\N,'top_panel_templ','',0),
(100,'top_panel_debug','','-=AUTONAME=-',\N,'top_panel_debug','',0),
(101,'MTP_SHORT_URI','','-=AUTONAME=-',\N,'MTP_SHORT_URI','',0),
(102,'FMST_PANEL_STICKERS','','-=AUTONAME=-',\N,'FMST_PANEL_STICKERS','',0),
(103,'top_panel_settings','','-=AUTONAME=-',\N,'top_panel_settings','',0),
(104,'top_panel_fav','','-=AUTONAME=-',\N,'top_panel_fav','',0),
(106,'Global','location.href=\'/bitrix/admin/hot_keys_list.php?lang=ru\';','HK_DB_SHW_HK','','','',0),
(107,'top_panel_edit_new','','-=AUTONAME=-',\N,'top_panel_edit_new','',0),
(108,'FLOW_PANEL_CREATE_WITH_WF','','-=AUTONAME=-',\N,'FLOW_PANEL_CREATE_WITH_WF','',0),
(109,'FLOW_PANEL_EDIT_WITH_WF','','-=AUTONAME=-',\N,'FLOW_PANEL_EDIT_WITH_WF','',0),
(110,'FLOW_PANEL_HISTORY','','-=AUTONAME=-',\N,'FLOW_PANEL_HISTORY','',0),
(111,'top_panel_create_new','','-=AUTONAME=-',\N,'top_panel_create_new','',0),
(112,'top_panel_create_folder_new','','-=AUTONAME=-',\N,'top_panel_create_folder_new','',0),
(116,'bx-panel-toggle','','-=AUTONAME=-',\N,'bx-panel-toggle','',0),
(117,'bx-panel-small-toggle','','-=AUTONAME=-',\N,'bx-panel-small-toggle','',0),
(118,'bx-panel-expander','var d=BX(\'bx-panel-expander\'); if (d) BX.fireEvent(d, \'click\');','-=AUTONAME=-',\N,'bx-panel-expander','',0),
(119,'bx-panel-hider','var d=BX(\'bx-panel-hider\'); if (d) d.click();','-=AUTONAME=-',\N,'bx-panel-hider','',0),
(120,'search-textbox-input','var d=BX(\'search-textbox-input\'); if (d) { d.click(); d.focus();}','-=AUTONAME=-','','search','',0),
(121,'bx-search-input','var d=BX(\'bx-search-input\'); if (d) { d.click(); d.focus(); }','-=AUTONAME=-','','bx-search-input','',0),
(133,'bx-panel-logout','var d=BX(\'bx-panel-logout\'); if (d) location.href = d.href;','-=AUTONAME=-','','bx-panel-logout','',0),
(135,'CDialog','var d=BX(\'cancel\'); if (d) d.click();','HK_DB_D_CANCEL','','cancel','',0),
(136,'CDialog','var d=BX(\'close\'); if (d) d.click();','HK_DB_D_CLOSE','','close','',0),
(137,'CDialog','var d=BX(\'savebtn\'); if (d) d.click();','HK_DB_D_SAVE','','savebtn','',0),
(138,'CDialog','var d=BX(\'btn_popup_save\'); if (d) d.click();','HK_DB_D_EDIT_SAVE','','btn_popup_save','',0),
(139,'Global','location.href=\'/bitrix/admin/user_admin.php?lang=\'+phpVars.LANGUAGE_ID;','HK_DB_SHW_U','','','',0)	;
#	TC`b_iblock`utf8_unicode_ci	;
CREATE TABLE `b_iblock` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `IBLOCK_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `LIST_PAGE_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DETAIL_PAGE_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECTION_PAGE_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CANONICAL_PAGE_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PICTURE` int(18) DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DESCRIPTION_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `RSS_TTL` int(11) NOT NULL DEFAULT '24',
  `RSS_ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `RSS_FILE_ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `RSS_FILE_LIMIT` int(11) DEFAULT NULL,
  `RSS_FILE_DAYS` int(11) DEFAULT NULL,
  `RSS_YANDEX_ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `INDEX_ELEMENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `INDEX_SECTION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `WORKFLOW` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `BIZPROC` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SECTION_CHOOSER` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LIST_MODE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RIGHTS_MODE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECTION_PROPERTY` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PROPERTY_INDEX` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION` int(11) NOT NULL DEFAULT '1',
  `LAST_CONV_ELEMENT` int(11) NOT NULL DEFAULT '0',
  `SOCNET_GROUP_ID` int(18) DEFAULT NULL,
  `EDIT_FILE_BEFORE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EDIT_FILE_AFTER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECTIONS_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECTION_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ELEMENTS_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ELEMENT_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_iblock` (`IBLOCK_TYPE_ID`,`LID`,`ACTIVE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_cache`utf8_unicode_ci	;
CREATE TABLE `b_iblock_cache` (
  `CACHE_KEY` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `CACHE` longtext COLLATE utf8_unicode_ci NOT NULL,
  `CACHE_DATE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`CACHE_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_element`utf8_unicode_ci	;
CREATE TABLE `b_iblock_element` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `IBLOCK_ID` int(11) NOT NULL DEFAULT '0',
  `IBLOCK_SECTION_ID` int(11) DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ACTIVE_FROM` datetime DEFAULT NULL,
  `ACTIVE_TO` datetime DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PREVIEW_PICTURE` int(18) DEFAULT NULL,
  `PREVIEW_TEXT` text COLLATE utf8_unicode_ci,
  `PREVIEW_TEXT_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `DETAIL_PICTURE` int(18) DEFAULT NULL,
  `DETAIL_TEXT` longtext COLLATE utf8_unicode_ci,
  `DETAIL_TEXT_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `SEARCHABLE_CONTENT` text COLLATE utf8_unicode_ci,
  `WF_STATUS_ID` int(18) DEFAULT '1',
  `WF_PARENT_ELEMENT_ID` int(11) DEFAULT NULL,
  `WF_NEW` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WF_LOCKED_BY` int(18) DEFAULT NULL,
  `WF_DATE_LOCK` datetime DEFAULT NULL,
  `WF_COMMENTS` text COLLATE utf8_unicode_ci,
  `IN_SECTIONS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAGS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WF_LAST_HISTORY_ID` int(11) DEFAULT NULL,
  `SHOW_COUNTER` int(18) DEFAULT NULL,
  `SHOW_COUNTER_START` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_iblock_element_1` (`IBLOCK_ID`,`IBLOCK_SECTION_ID`),
  KEY `ix_iblock_element_4` (`IBLOCK_ID`,`XML_ID`,`WF_PARENT_ELEMENT_ID`),
  KEY `ix_iblock_element_3` (`WF_PARENT_ELEMENT_ID`),
  KEY `ix_iblock_element_code` (`IBLOCK_ID`,`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_element_iprop`utf8_unicode_ci	;
CREATE TABLE `b_iblock_element_iprop` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  `ELEMENT_ID` int(11) NOT NULL,
  `IPROP_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ELEMENT_ID`,`IPROP_ID`),
  KEY `ix_b_iblock_element_iprop_0` (`IPROP_ID`),
  KEY `ix_b_iblock_element_iprop_1` (`IBLOCK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_element_lock`utf8_unicode_ci	;
CREATE TABLE `b_iblock_element_lock` (
  `IBLOCK_ELEMENT_ID` int(11) NOT NULL,
  `DATE_LOCK` datetime DEFAULT NULL,
  `LOCKED_BY` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`IBLOCK_ELEMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_element_property`utf8_unicode_ci	;
CREATE TABLE `b_iblock_element_property` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IBLOCK_PROPERTY_ID` int(11) NOT NULL,
  `IBLOCK_ELEMENT_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci NOT NULL,
  `VALUE_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `VALUE_ENUM` int(11) DEFAULT NULL,
  `VALUE_NUM` decimal(18,4) DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_iblock_element_property_1` (`IBLOCK_ELEMENT_ID`,`IBLOCK_PROPERTY_ID`),
  KEY `ix_iblock_element_property_2` (`IBLOCK_PROPERTY_ID`),
  KEY `ix_iblock_element_prop_enum` (`VALUE_ENUM`,`IBLOCK_PROPERTY_ID`),
  KEY `ix_iblock_element_prop_num` (`VALUE_NUM`,`IBLOCK_PROPERTY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_element_right`utf8_unicode_ci	;
CREATE TABLE `b_iblock_element_right` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  `ELEMENT_ID` int(11) NOT NULL,
  `RIGHT_ID` int(11) NOT NULL,
  `IS_INHERITED` char(1) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`RIGHT_ID`,`ELEMENT_ID`,`SECTION_ID`),
  KEY `ix_b_iblock_element_right_1` (`ELEMENT_ID`,`IBLOCK_ID`),
  KEY `ix_b_iblock_element_right_2` (`IBLOCK_ID`,`RIGHT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_fields`utf8_unicode_ci	;
CREATE TABLE `b_iblock_fields` (
  `IBLOCK_ID` int(18) NOT NULL,
  `FIELD_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `IS_REQUIRED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEFAULT_VALUE` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`IBLOCK_ID`,`FIELD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_group`utf8_unicode_ci	;
CREATE TABLE `b_iblock_group` (
  `IBLOCK_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `PERMISSION` char(1) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `ux_iblock_group_1` (`IBLOCK_ID`,`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_iblock_iprop`utf8_unicode_ci	;
CREATE TABLE `b_iblock_iblock_iprop` (
  `IBLOCK_ID` int(11) NOT NULL,
  `IPROP_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`IBLOCK_ID`,`IPROP_ID`),
  KEY `ix_b_iblock_iblock_iprop_0` (`IPROP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_iproperty`utf8_unicode_ci	;
CREATE TABLE `b_iblock_iproperty` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IBLOCK_ID` int(11) NOT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `TEMPLATE` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_iblock_iprop_0` (`IBLOCK_ID`,`ENTITY_TYPE`,`ENTITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_messages`utf8_unicode_ci	;
CREATE TABLE `b_iblock_messages` (
  `IBLOCK_ID` int(18) NOT NULL,
  `MESSAGE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE_TEXT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`IBLOCK_ID`,`MESSAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_offers_tmp`utf8_unicode_ci	;
CREATE TABLE `b_iblock_offers_tmp` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `PRODUCT_IBLOCK_ID` int(11) unsigned NOT NULL,
  `OFFERS_IBLOCK_ID` int(11) unsigned NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_property`utf8_unicode_ci	;
CREATE TABLE `b_iblock_property` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `IBLOCK_ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEFAULT_VALUE` text COLLATE utf8_unicode_ci,
  `PROPERTY_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `ROW_COUNT` int(11) NOT NULL DEFAULT '1',
  `COL_COUNT` int(11) NOT NULL DEFAULT '30',
  `LIST_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'L',
  `MULTIPLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `XML_ID` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILE_TYPE` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MULTIPLE_CNT` int(11) DEFAULT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINK_IBLOCK_ID` int(18) DEFAULT NULL,
  `WITH_DESCRIPTION` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEARCHABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `FILTRABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IS_REQUIRED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION` int(11) NOT NULL DEFAULT '1',
  `USER_TYPE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_TYPE_SETTINGS` text COLLATE utf8_unicode_ci,
  `HINT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_iblock_property_1` (`IBLOCK_ID`),
  KEY `ix_iblock_property_3` (`LINK_IBLOCK_ID`),
  KEY `ix_iblock_property_2` (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_property_enum`utf8_unicode_ci	;
CREATE TABLE `b_iblock_property_enum` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PROPERTY_ID` int(11) NOT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `XML_ID` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_iblock_property_enum` (`PROPERTY_ID`,`XML_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_right`utf8_unicode_ci	;
CREATE TABLE `b_iblock_right` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IBLOCK_ID` int(11) NOT NULL,
  `GROUP_CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_TYPE` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `DO_INHERIT` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `TASK_ID` int(11) NOT NULL,
  `OP_SREAD` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `OP_EREAD` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `XML_ID` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_iblock_right_iblock_id` (`IBLOCK_ID`,`ENTITY_TYPE`,`ENTITY_ID`),
  KEY `ix_b_iblock_right_group_code` (`GROUP_CODE`,`IBLOCK_ID`),
  KEY `ix_b_iblock_right_entity` (`ENTITY_ID`,`ENTITY_TYPE`),
  KEY `ix_b_iblock_right_op_eread` (`ID`,`OP_EREAD`,`GROUP_CODE`),
  KEY `ix_b_iblock_right_op_sread` (`ID`,`OP_SREAD`,`GROUP_CODE`),
  KEY `ix_b_iblock_right_task_id` (`TASK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_rss`utf8_unicode_ci	;
CREATE TABLE `b_iblock_rss` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IBLOCK_ID` int(11) NOT NULL,
  `NODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NODE_VALUE` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_section`utf8_unicode_ci	;
CREATE TABLE `b_iblock_section` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `IBLOCK_ID` int(11) NOT NULL,
  `IBLOCK_SECTION_ID` int(11) DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `GLOBAL_ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PICTURE` int(18) DEFAULT NULL,
  `LEFT_MARGIN` int(18) DEFAULT NULL,
  `RIGHT_MARGIN` int(18) DEFAULT NULL,
  `DEPTH_LEVEL` int(18) DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DESCRIPTION_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `SEARCHABLE_CONTENT` text COLLATE utf8_unicode_ci,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DETAIL_PICTURE` int(18) DEFAULT NULL,
  `SOCNET_GROUP_ID` int(18) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_iblock_section_1` (`IBLOCK_ID`,`IBLOCK_SECTION_ID`),
  KEY `ix_iblock_section_depth_level` (`IBLOCK_ID`,`DEPTH_LEVEL`),
  KEY `ix_iblock_section_left_margin` (`IBLOCK_ID`,`LEFT_MARGIN`,`RIGHT_MARGIN`),
  KEY `ix_iblock_section_right_margin` (`IBLOCK_ID`,`RIGHT_MARGIN`,`LEFT_MARGIN`),
  KEY `ix_iblock_section_code` (`IBLOCK_ID`,`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_section_element`utf8_unicode_ci	;
CREATE TABLE `b_iblock_section_element` (
  `IBLOCK_SECTION_ID` int(11) NOT NULL,
  `IBLOCK_ELEMENT_ID` int(11) NOT NULL,
  `ADDITIONAL_PROPERTY_ID` int(18) DEFAULT NULL,
  UNIQUE KEY `ux_iblock_section_element` (`IBLOCK_SECTION_ID`,`IBLOCK_ELEMENT_ID`,`ADDITIONAL_PROPERTY_ID`),
  KEY `UX_IBLOCK_SECTION_ELEMENT2` (`IBLOCK_ELEMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_section_iprop`utf8_unicode_ci	;
CREATE TABLE `b_iblock_section_iprop` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  `IPROP_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`SECTION_ID`,`IPROP_ID`),
  KEY `ix_b_iblock_section_iprop_0` (`IPROP_ID`),
  KEY `ix_b_iblock_section_iprop_1` (`IBLOCK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_section_property`utf8_unicode_ci	;
CREATE TABLE `b_iblock_section_property` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  `PROPERTY_ID` int(11) NOT NULL,
  `SMART_FILTER` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DISPLAY_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DISPLAY_EXPANDED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILTER_HINT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`IBLOCK_ID`,`SECTION_ID`,`PROPERTY_ID`),
  KEY `ix_b_iblock_section_property_1` (`PROPERTY_ID`),
  KEY `ix_b_iblock_section_property_2` (`SECTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_section_right`utf8_unicode_ci	;
CREATE TABLE `b_iblock_section_right` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  `RIGHT_ID` int(11) NOT NULL,
  `IS_INHERITED` char(1) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`RIGHT_ID`,`SECTION_ID`),
  KEY `ix_b_iblock_section_right_1` (`SECTION_ID`,`IBLOCK_ID`),
  KEY `ix_b_iblock_section_right_2` (`IBLOCK_ID`,`RIGHT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_sequence`utf8_unicode_ci	;
CREATE TABLE `b_iblock_sequence` (
  `IBLOCK_ID` int(18) NOT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SEQ_VALUE` int(11) DEFAULT NULL,
  PRIMARY KEY (`IBLOCK_ID`,`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_site`utf8_unicode_ci	;
CREATE TABLE `b_iblock_site` (
  `IBLOCK_ID` int(18) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`IBLOCK_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_type`utf8_unicode_ci	;
CREATE TABLE `b_iblock_type` (
  `ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SECTIONS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `EDIT_FILE_BEFORE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EDIT_FILE_AFTER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IN_RSS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SORT` int(18) NOT NULL DEFAULT '500',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_iblock_type_lang`utf8_unicode_ci	;
CREATE TABLE `b_iblock_type_lang` (
  `IBLOCK_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `SECTION_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ELEMENT_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_lang`utf8_unicode_ci	;
CREATE TABLE `b_lang` (
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(18) NOT NULL DEFAULT '100',
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DIR` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FORMAT_DATE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_DATETIME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WEEK_START` int(11) DEFAULT NULL,
  `CHARSET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `DOC_ROOT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DOMAIN_LIMITED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SERVER_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SITE_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CULTURE_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_lang`utf8_unicode_ci	;
INSERT INTO `b_lang` VALUES 
('s1',1,'Y','Y','ОАО &quot;Минскжелезобетон&quot;','/',\N,\N,\N,\N,\N,'ru',\N,'N',\N,\N,\N,1)	;
#	TC`b_lang_domain`utf8_unicode_ci	;
CREATE TABLE `b_lang_domain` (
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `DOMAIN` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`LID`,`DOMAIN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_language`utf8_unicode_ci	;
CREATE TABLE `b_language` (
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FORMAT_DATE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_DATETIME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WEEK_START` int(11) DEFAULT NULL,
  `CHARSET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DIRECTION` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CULTURE_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_language`utf8_unicode_ci	;
INSERT INTO `b_language` VALUES 
('en',2,'N','Y','English',\N,\N,\N,\N,\N,\N,2),
('ru',1,'Y','Y','Russian',\N,\N,\N,\N,\N,\N,1)	;
#	TC`b_list_rubric`utf8_unicode_ci	;
CREATE TABLE `b_list_rubric` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `CODE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `AUTO` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DAYS_OF_MONTH` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DAYS_OF_WEEK` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIMES_OF_DAY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TEMPLATE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_EXECUTED` datetime DEFAULT NULL,
  `VISIBLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `FROM_FIELD` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_medialib_collection`utf8_unicode_ci	;
CREATE TABLE `b_medialib_collection` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `DATE_UPDATE` datetime NOT NULL,
  `OWNER_ID` int(11) DEFAULT NULL,
  `PARENT_ID` int(11) DEFAULT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `KEYWORDS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ITEMS_COUNT` int(11) DEFAULT NULL,
  `ML_TYPE` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_medialib_collection_item`utf8_unicode_ci	;
CREATE TABLE `b_medialib_collection_item` (
  `COLLECTION_ID` int(11) NOT NULL,
  `ITEM_ID` int(11) NOT NULL,
  PRIMARY KEY (`ITEM_ID`,`COLLECTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_medialib_item`utf8_unicode_ci	;
CREATE TABLE `b_medialib_item` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ITEM_TYPE` char(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DATE_CREATE` datetime NOT NULL,
  `DATE_UPDATE` datetime NOT NULL,
  `SOURCE_ID` int(11) NOT NULL,
  `KEYWORDS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEARCHABLE_CONTENT` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_medialib_type`utf8_unicode_ci	;
CREATE TABLE `b_medialib_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `EXT` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SYSTEM` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_medialib_type`utf8_unicode_ci	;
INSERT INTO `b_medialib_type` VALUES 
(1,'image_name','image','jpg,jpeg,gif,png','Y','image_desc'),
(2,'video_name','video','flv,mp4,wmv','Y','video_desc'),
(3,'sound_name','sound','mp3,wma,aac','Y','sound_desc')	;
#	TC`b_mobileapp_app`utf8_unicode_ci	;
CREATE TABLE `b_mobileapp_app` (
  `CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SHORT_NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci NOT NULL,
  `FILES` text COLLATE utf8_unicode_ci NOT NULL,
  `LAUNCH_ICONS` text COLLATE utf8_unicode_ci NOT NULL,
  `LAUNCH_SCREENS` text COLLATE utf8_unicode_ci NOT NULL,
  `FOLDER` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATE` datetime NOT NULL,
  PRIMARY KEY (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_mobileapp_config`utf8_unicode_ci	;
CREATE TABLE `b_mobileapp_config` (
  `APP_CODE` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `PLATFORM` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATE` datetime NOT NULL,
  PRIMARY KEY (`APP_CODE`,`PLATFORM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_module`utf8_unicode_ci	;
CREATE TABLE `b_module` (
  `ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_ACTIVE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_module`utf8_unicode_ci	;
INSERT INTO `b_module` VALUES 
('abtest','2016-10-18 08:59:18'),
('bitrix.eshop','2016-10-18 08:59:26'),
('bitrix.sitecorporate','2016-10-18 08:59:38'),
('bitrixcloud','2016-10-18 08:59:46'),
('blog','2016-10-18 08:59:56'),
('catalog','2016-10-18 09:00:26'),
('clouds','2016-10-18 09:00:36'),
('compression','2016-10-18 09:00:37'),
('conversion','2016-10-18 09:00:38'),
('currency','2016-10-18 09:00:40'),
('fileman','2016-10-18 09:00:49'),
('form','2016-10-18 09:01:06'),
('forum','2016-10-18 09:01:13'),
('highloadblock','2016-10-18 09:01:27'),
('iblock','2016-10-18 09:01:40'),
('main','2016-10-18 08:58:51'),
('mobileapp','2016-10-18 09:02:15'),
('perfmon','2016-10-18 09:02:21'),
('photogallery','2016-10-18 09:02:27'),
('pull','2016-10-18 09:02:38'),
('sale','2016-10-18 09:02:54'),
('scale','2016-10-18 09:03:22'),
('search','2016-10-18 09:03:24'),
('security','2016-10-18 09:03:28'),
('sender','2016-10-18 09:03:32'),
('seo','2016-10-18 09:03:35'),
('socialservices','2016-10-18 09:03:37'),
('storeassist','2016-10-18 09:03:39'),
('subscribe','2016-10-18 09:03:42'),
('translate','2016-10-18 09:03:45'),
('vote','2016-10-18 09:03:50')	;
#	TC`b_module_group`utf8_unicode_ci	;
CREATE TABLE `b_module_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `G_ACCESS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_GROUP_MODULE` (`MODULE_ID`,`GROUP_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_module_to_module`utf8_unicode_ci	;
CREATE TABLE `b_module_to_module` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SORT` int(18) NOT NULL DEFAULT '100',
  `FROM_MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TO_MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TO_PATH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TO_CLASS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TO_METHOD` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TO_METHOD_ARG` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION` int(18) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_module_to_module` (`FROM_MODULE_ID`(20),`MESSAGE_ID`(20),`TO_MODULE_ID`(20),`TO_CLASS`(20),`TO_METHOD`(20))
) ENGINE=InnoDB AUTO_INCREMENT=416 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_module_to_module`utf8_unicode_ci	;
INSERT INTO `b_module_to_module` VALUES 
(1,'2016-10-18 08:58:51',100,'iblock','OnIBlockPropertyBuildList','main','/modules/main/tools/prop_userid.php','CIBlockPropertyUserID','GetUserTypeDescription','',1),
(2,'2016-10-18 08:58:51',100,'main','OnUserDelete','main','/modules/main/classes/mysql/favorites.php','CFavorites','OnUserDelete','',1),
(3,'2016-10-18 08:58:51',100,'main','OnLanguageDelete','main','/modules/main/classes/mysql/favorites.php','CFavorites','OnLanguageDelete','',1),
(4,'2016-10-18 08:58:51',100,'main','OnUserDelete','main','','CUserOptions','OnUserDelete','',1),
(5,'2016-10-18 08:58:51',100,'main','OnChangeFile','main','','CMain','OnChangeFileComponent','',1),
(6,'2016-10-18 08:58:51',100,'main','OnUserTypeRightsCheck','main','','CUser','UserTypeRightsCheck','',1),
(7,'2016-10-18 08:58:51',100,'main','OnUserLogin','main','','UpdateTools','CheckUpdates','',1),
(8,'2016-10-18 08:58:51',100,'main','OnModuleUpdate','main','','UpdateTools','SetUpdateResult','',1),
(9,'2016-10-18 08:58:51',100,'main','OnUpdateCheck','main','','UpdateTools','SetUpdateError','',1),
(10,'2016-10-18 08:58:51',100,'main','OnPanelCreate','main','','CUndo','CheckNotifyMessage','',1),
(11,'2016-10-18 08:58:51',100,'main','OnAfterAddRating','main','','CRatingsComponentsMain','OnAfterAddRating','',1),
(12,'2016-10-18 08:58:51',100,'main','OnAfterUpdateRating','main','','CRatingsComponentsMain','OnAfterUpdateRating','',1),
(13,'2016-10-18 08:58:51',100,'main','OnSetRatingsConfigs','main','','CRatingsComponentsMain','OnSetRatingConfigs','',1),
(14,'2016-10-18 08:58:51',100,'main','OnGetRatingsConfigs','main','','CRatingsComponentsMain','OnGetRatingConfigs','',1),
(15,'2016-10-18 08:58:51',100,'main','OnGetRatingsObjects','main','','CRatingsComponentsMain','OnGetRatingObject','',1),
(16,'2016-10-18 08:58:51',100,'main','OnGetRatingContentOwner','main','','CRatingsComponentsMain','OnGetRatingContentOwner','',1),
(17,'2016-10-18 08:58:51',100,'main','OnAfterAddRatingRule','main','','CRatingRulesMain','OnAfterAddRatingRule','',1),
(18,'2016-10-18 08:58:51',100,'main','OnAfterUpdateRatingRule','main','','CRatingRulesMain','OnAfterUpdateRatingRule','',1),
(19,'2016-10-18 08:58:51',100,'main','OnGetRatingRuleObjects','main','','CRatingRulesMain','OnGetRatingRuleObjects','',1),
(20,'2016-10-18 08:58:51',100,'main','OnGetRatingRuleConfigs','main','','CRatingRulesMain','OnGetRatingRuleConfigs','',1),
(21,'2016-10-18 08:58:51',100,'main','OnAfterUserAdd','main','','CRatings','OnAfterUserRegister','',1),
(22,'2016-10-18 08:58:51',100,'main','OnUserDelete','main','','CRatings','OnUserDelete','',1),
(23,'2016-10-18 08:58:51',100,'main','OnUserDelete','main','','CAccess','OnUserDelete','',1),
(24,'2016-10-18 08:58:51',100,'main','OnAfterGroupAdd','main','','CGroupAuthProvider','OnAfterGroupAdd','',1),
(25,'2016-10-18 08:58:51',100,'main','OnBeforeGroupUpdate','main','','CGroupAuthProvider','OnBeforeGroupUpdate','',1),
(26,'2016-10-18 08:58:51',100,'main','OnBeforeGroupDelete','main','','CGroupAuthProvider','OnBeforeGroupDelete','',1),
(27,'2016-10-18 08:58:51',100,'main','OnAfterSetUserGroup','main','','CGroupAuthProvider','OnAfterSetUserGroup','',1),
(28,'2016-10-18 08:58:51',100,'main','OnUserLogin','main','','CGroupAuthProvider','OnUserLogin','',1),
(29,'2016-10-18 08:58:51',100,'main','OnEventLogGetAuditTypes','main','','CEventMain','GetAuditTypes','',1),
(30,'2016-10-18 08:58:51',100,'main','OnEventLogGetAuditHandlers','main','','CEventMain','MakeMainObject','',1),
(31,'2016-10-18 08:58:51',100,'perfmon','OnGetTableSchema','main','','CTableSchema','OnGetTableSchema','',1),
(32,'2016-10-18 08:58:51',100,'sender','OnConnectorList','main','','\\Bitrix\\Main\\SenderEventHandler','onConnectorListUser','',1),
(33,'2016-10-18 08:58:51',110,'main','OnUserTypeBuildList','main','','CUserTypeString','GetUserTypeDescription','',1),
(34,'2016-10-18 08:58:51',120,'main','OnUserTypeBuildList','main','','CUserTypeInteger','GetUserTypeDescription','',1),
(35,'2016-10-18 08:58:51',130,'main','OnUserTypeBuildList','main','','CUserTypeDouble','GetUserTypeDescription','',1),
(36,'2016-10-18 08:58:51',140,'main','OnUserTypeBuildList','main','','CUserTypeDateTime','GetUserTypeDescription','',1),
(37,'2016-10-18 08:58:51',145,'main','OnUserTypeBuildList','main','','CUserTypeDate','GetUserTypeDescription','',1),
(38,'2016-10-18 08:58:51',150,'main','OnUserTypeBuildList','main','','CUserTypeBoolean','GetUserTypeDescription','',1),
(39,'2016-10-18 08:58:51',160,'main','OnUserTypeBuildList','main','','CUserTypeFile','GetUserTypeDescription','',1),
(40,'2016-10-18 08:58:51',170,'main','OnUserTypeBuildList','main','','CUserTypeEnum','GetUserTypeDescription','',1),
(41,'2016-10-18 08:58:51',180,'main','OnUserTypeBuildList','main','','CUserTypeIBlockSection','GetUserTypeDescription','',1),
(42,'2016-10-18 08:58:51',190,'main','OnUserTypeBuildList','main','','CUserTypeIBlockElement','GetUserTypeDescription','',1),
(43,'2016-10-18 08:58:51',200,'main','OnUserTypeBuildList','main','','CUserTypeStringFormatted','GetUserTypeDescription','',1),
(44,'2016-10-18 08:58:51',210,'main','OnUserTypeBuildList','main','','\\Bitrix\\Main\\UrlPreview\\UrlPreviewUserType','getUserTypeDescription','',1),
(45,'2016-10-18 08:58:51',100,'main','OnBeforeEndBufferContent','main','','\\Bitrix\\Main\\Analytics\\Counter','onBeforeEndBufferContent','',1),
(46,'2016-10-18 08:58:51',100,'main','OnBeforeRestartBuffer','main','','\\Bitrix\\Main\\Analytics\\Counter','onBeforeRestartBuffer','',1),
(47,'2016-10-18 08:58:51',100,'disk','onAfterAjaxActionCreateFolderWithSharing','main','','\\Bitrix\\Main\\FinderDestTable','onAfterDiskAjaxAction','',1),
(48,'2016-10-18 08:58:51',100,'disk','onAfterAjaxActionAppendSharing','main','','\\Bitrix\\Main\\FinderDestTable','onAfterDiskAjaxAction','',1),
(49,'2016-10-18 08:58:51',100,'disk','onAfterAjaxActionChangeSharingAndRights','main','','\\Bitrix\\Main\\FinderDestTable','onAfterDiskAjaxAction','',1),
(50,'2016-10-18 08:58:51',100,'socialnetwork','OnSocNetLogDelete','main','','CUserCounter','OnSocNetLogDelete','',1),
(51,'2016-10-18 08:58:51',100,'socialnetwork','OnSocNetLogCommentDelete','main','','CUserCounter','OnSocNetLogCommentDelete','',1),
(52,'2016-10-18 08:58:51',100,'sale','OnSaleBasketItemSaved','main','','\\Bitrix\\Main\\Analytics\\Catalog','catchCatalogBasket','',2),
(53,'2016-10-18 08:58:51',100,'sale','OnSaleOrderSaved','main','','\\Bitrix\\Main\\Analytics\\Catalog','catchCatalogOrder','',2),
(54,'2016-10-18 08:58:51',100,'sale','OnSaleOrderPaid','main','','\\Bitrix\\Main\\Analytics\\Catalog','catchCatalogOrderPayment','',2),
(55,'2016-10-18 08:59:18',100,'main','OnGetCurrentSiteTemplate','abtest','','\\Bitrix\\ABTest\\EventHandler','onGetCurrentSiteTemplate','',2),
(56,'2016-10-18 08:59:18',100,'main','OnFileRewrite','abtest','','\\Bitrix\\ABTest\\EventHandler','onFileRewrite','',2),
(57,'2016-10-18 08:59:18',100,'main','OnPageStart','abtest','','\\Bitrix\\ABTest\\EventHandler','onPageStart','',1),
(58,'2016-10-18 08:59:18',100,'main','OnPanelCreate','abtest','','\\Bitrix\\ABTest\\EventHandler','onPanelCreate','',1),
(59,'2016-10-18 08:59:18',100,'conversion','OnGetAttributeTypes','abtest','','\\Bitrix\\ABTest\\EventHandler','onGetAttributeTypes','',1),
(60,'2016-10-18 08:59:18',100,'conversion','OnSetDayContextAttributes','abtest','','\\Bitrix\\ABTest\\EventHandler','onConversionSetContextAttributes','',1),
(61,'2016-10-18 08:59:26',100,'main','OnBeforeProlog','bitrix.eshop','','CEShop','ShowPanel','',1),
(62,'2016-10-18 08:59:38',100,'main','OnBeforeProlog','bitrix.sitecorporate','','CSiteCorporate','ShowPanel','',1),
(63,'2016-10-18 08:59:46',100,'main','OnAdminInformerInsertItems','bitrixcloud','','CBitrixCloudCDN','OnAdminInformerInsertItems','',1),
(64,'2016-10-18 08:59:46',100,'main','OnAdminInformerInsertItems','bitrixcloud','','CBitrixCloudBackup','OnAdminInformerInsertItems','',1),
(65,'2016-10-18 08:59:46',100,'mobileapp','OnBeforeAdminMobileMenuBuild','bitrixcloud','','CBitrixCloudMobile','OnBeforeAdminMobileMenuBuild','',1),
(66,'2016-10-18 08:59:56',100,'search','OnReindex','blog','','CBlogSearch','OnSearchReindex','',1),
(67,'2016-10-18 08:59:56',100,'main','OnUserDelete','blog','','CBlogUser','Delete','',1),
(68,'2016-10-18 08:59:56',100,'main','OnSiteDelete','blog','','CBlogSitePath','DeleteBySiteID','',1),
(69,'2016-10-18 08:59:56',100,'socialnetwork','OnSocNetGroupDelete','blog','','CBlogSoNetPost','OnGroupDelete','',1),
(70,'2016-10-18 08:59:56',100,'socialnetwork','OnSocNetFeaturesAdd','blog','','CBlogSearch','SetSoNetFeatureIndexSearch','',1),
(71,'2016-10-18 08:59:56',100,'socialnetwork','OnSocNetFeaturesUpdate','blog','','CBlogSearch','SetSoNetFeatureIndexSearch','',1),
(72,'2016-10-18 08:59:56',100,'socialnetwork','OnSocNetFeaturesPermsAdd','blog','','CBlogSearch','SetSoNetFeaturePermIndexSearch','',1),
(73,'2016-10-18 08:59:56',100,'socialnetwork','OnSocNetFeaturesPermsUpdate','blog','','CBlogSearch','SetSoNetFeaturePermIndexSearch','',1),
(74,'2016-10-18 08:59:56',200,'main','OnAfterAddRating','blog','','CRatingsComponentsBlog','OnAfterAddRating','',1),
(75,'2016-10-18 08:59:56',200,'main','OnAfterUpdateRating','blog','','CRatingsComponentsBlog','OnAfterUpdateRating','',1),
(76,'2016-10-18 08:59:56',200,'main','OnSetRatingsConfigs','blog','','CRatingsComponentsBlog','OnSetRatingConfigs','',1),
(77,'2016-10-18 08:59:56',200,'main','OnGetRatingsConfigs','blog','','CRatingsComponentsBlog','OnGetRatingConfigs','',1),
(78,'2016-10-18 08:59:56',200,'main','OnGetRatingsObjects','blog','','CRatingsComponentsBlog','OnGetRatingObject','',1),
(79,'2016-10-18 08:59:56',200,'main','OnGetRatingContentOwner','blog','','CRatingsComponentsBlog','OnGetRatingContentOwner','',1),
(80,'2016-10-18 08:59:56',100,'im','OnGetNotifySchema','blog','','CBlogNotifySchema','OnGetNotifySchema','',1),
(81,'2016-10-18 08:59:56',100,'main','OnAfterRegisterModule','main','/modules/blog/install/index.php','blog','installUserFields','',1),
(82,'2016-10-18 08:59:56',100,'conversion','OnGetCounterTypes','blog','','\\Bitrix\\Blog\\Internals\\ConversionHandlers','onGetCounterTypes','',1),
(83,'2016-10-18 08:59:56',100,'conversion','OnGetRateTypes','blog','','\\Bitrix\\Blog\\Internals\\ConversionHandlers','onGetRateTypes','',1),
(84,'2016-10-18 08:59:56',100,'blog','OnPostAdd','blog','','\\Bitrix\\Blog\\Internals\\ConversionHandlers','onPostAdd','',1),
(85,'2016-10-18 08:59:56',100,'mail','onReplyReceivedBLOG_POST','blog','','\\Bitrix\\Blog\\Internals\\MailHandler','handleReplyReceivedBlogPost','',2),
(86,'2016-10-18 08:59:56',100,'mail','onForwardReceivedBLOG_POST','blog','','\\Bitrix\\Blog\\Internals\\MailHandler','handleForwardReceivedBlogPost','',2),
(87,'2016-10-18 09:00:26',100,'sale','onBuildCouponProviders','catalog','','\\Bitrix\\Catalog\\DiscountCouponTable','couponManager','',2),
(88,'2016-10-18 09:00:26',100,'sale','onBuildDiscountProviders','catalog','','\\Bitrix\\Catalog\\Discount\\DiscountManager','catalogDiscountManager','',2),
(89,'2016-10-18 09:00:26',100,'sale','onExtendOrderData','catalog','','\\Bitrix\\Catalog\\Discount\\DiscountManager','extendOrderData','',2),
(90,'2016-10-18 09:00:26',100,'currency','onAfterUpdateCurrencyBaseRate','catalog','','\\Bitrix\\Catalog\\Product\\Price','handlerAfterUpdateCurrencyBaseRate','',2),
(91,'2016-10-18 09:00:26',100,'main','onUserDelete','catalog','','\\Bitrix\\Catalog\\SubscribeTable','onUserDelete','',1),
(92,'2016-10-18 09:00:26',100,'iblock','OnIBlockElementDelete','catalog','','\\Bitrix\\Catalog\\SubscribeTable','onIblockElementDelete','',1),
(93,'2016-10-18 09:00:26',100,'catalog','OnProductUpdate','catalog','','\\Bitrix\\Catalog\\SubscribeTable','onProductUpdate','',1),
(94,'2016-10-18 09:00:26',100,'catalog','OnProductSetAvailableUpdate','catalog','','\\Bitrix\\Catalog\\SubscribeTable','onProductSetAvailableUpdate','',1),
(95,'2016-10-18 09:00:26',100,'catalog','onAddContactType','catalog','','\\Bitrix\\Catalog\\SubscribeTable','onAddContactType','',1),
(96,'2016-10-18 09:00:26',100,'sale','OnSaleOrderSaved','catalog','','\\Bitrix\\Catalog\\SubscribeTable','onSaleOrderSaved','',2),
(97,'2016-10-18 09:00:26',100,'iblock','OnIBlockDelete','catalog','','CCatalog','OnIBlockDelete','',1),
(98,'2016-10-18 09:00:26',100,'iblock','OnIBlockElementDelete','catalog','','CCatalogProduct','OnIBlockElementDelete','',1),
(99,'2016-10-18 09:00:26',100,'iblock','OnIBlockElementDelete','catalog','','CPrice','OnIBlockElementDelete','',1),
(100,'2016-10-18 09:00:26',100,'iblock','OnIBlockElementDelete','catalog','','CCatalogStoreProduct','OnIBlockElementDelete','',1),
(101,'2016-10-18 09:00:26',100,'iblock','OnIBlockElementDelete','catalog','','CCatalogDocs','OnIBlockElementDelete','',1),
(102,'2016-10-18 09:00:26',100,'iblock','OnBeforeIBlockElementDelete','catalog','','CCatalogDocs','OnBeforeIBlockElementDelete','',1),
(103,'2016-10-18 09:00:26',100,'currency','OnCurrencyDelete','catalog','','CPrice','OnCurrencyDelete','',1),
(104,'2016-10-18 09:00:26',100,'main','OnGroupDelete','catalog','','CCatalogProductGroups','OnGroupDelete','',1),
(105,'2016-10-18 09:00:26',100,'iblock','OnAfterIBlockElementUpdate','catalog','','CCatalogProduct','OnAfterIBlockElementUpdate','',1),
(106,'2016-10-18 09:00:26',100,'currency','OnModuleUnInstall','catalog','','','CurrencyModuleUnInstallCatalog','',1),
(107,'2016-10-18 09:00:26',300,'iblock','OnBeforeIBlockDelete','catalog','','CCatalog','OnBeforeCatalogDelete','',1),
(108,'2016-10-18 09:00:26',10000,'iblock','OnBeforeIBlockElementDelete','catalog','','CCatalog','OnBeforeIBlockElementDelete','',1),
(109,'2016-10-18 09:00:26',100,'main','OnEventLogGetAuditTypes','catalog','','CCatalogEvent','GetAuditTypes','',1),
(110,'2016-10-18 09:00:26',100,'main','OnBuildGlobalMenu','catalog','','CCatalogAdmin','OnBuildGlobalMenu','',1),
(111,'2016-10-18 09:00:26',100,'main','OnAdminListDisplay','catalog','','CCatalogAdmin','OnAdminListDisplay','',1),
(112,'2016-10-18 09:00:26',100,'main','OnBuildGlobalMenu','catalog','','CCatalogAdmin','OnBuildSaleMenu','',1),
(113,'2016-10-18 09:00:26',100,'catalog','OnCondCatControlBuildList','catalog','','CCatalogCondCtrlGroup','GetControlDescr','',1),
(114,'2016-10-18 09:00:26',200,'catalog','OnCondCatControlBuildList','catalog','','CCatalogCondCtrlIBlockFields','GetControlDescr','',1),
(115,'2016-10-18 09:00:26',300,'catalog','OnCondCatControlBuildList','catalog','','CCatalogCondCtrlIBlockProps','GetControlDescr','',1),
(116,'2016-10-18 09:00:26',100,'catalog','OnDocumentBarcodeDelete','catalog','','CCatalogStoreDocsElement','OnDocumentBarcodeDelete','',1),
(117,'2016-10-18 09:00:26',100,'catalog','OnBeforeDocumentDelete','catalog','','CCatalogStoreDocsBarcode','OnBeforeDocumentDelete','',1),
(118,'2016-10-18 09:00:26',100,'catalog','OnCatalogStoreDelete','catalog','','CCatalogDocs','OnCatalogStoreDelete','',1),
(119,'2016-10-18 09:00:26',100,'iblock','OnBeforeIBlockPropertyDelete','catalog','','CCatalog','OnBeforeIBlockPropertyDelete','',1),
(120,'2016-10-18 09:00:26',1100,'sale','OnCondSaleControlBuildList','catalog','','CCatalogCondCtrlBasketProductFields','GetControlDescr','',1),
(121,'2016-10-18 09:00:26',1200,'sale','OnCondSaleControlBuildList','catalog','','CCatalogCondCtrlBasketProductProps','GetControlDescr','',1),
(122,'2016-10-18 09:00:26',1200,'sale','OnCondSaleActionsControlBuildList','catalog','','CCatalogActionCtrlBasketProductFields','GetControlDescr','',1),
(123,'2016-10-18 09:00:26',1300,'sale','OnCondSaleActionsControlBuildList','catalog','','CCatalogActionCtrlBasketProductProps','GetControlDescr','',1),
(124,'2016-10-18 09:00:26',200,'sale','OnCondSaleActionsControlBuildList','catalog','','CCatalogGifterProduct','GetControlDescr','',1),
(125,'2016-10-18 09:00:26',100,'sale','OnExtendBasketItems','catalog','','CCatalogDiscount','ExtendBasketItems','',1),
(126,'2016-10-18 09:00:26',100,'iblock','OnModuleUnInstall','catalog','','CCatalog','OnIBlockModuleUnInstall','',1),
(127,'2016-10-18 09:00:26',100,'iblock','OnIBlockElementAdd','catalog','','\\Bitrix\\Catalog\\Product\\Sku','handlerIblockElementAdd','',1),
(128,'2016-10-18 09:00:26',100,'iblock','OnAfterIBlockElementAdd','catalog','','\\Bitrix\\Catalog\\Product\\Sku','handlerAfterIblockElementAdd','',1),
(129,'2016-10-18 09:00:26',100,'iblock','OnIBlockElementUpdate','catalog','','\\Bitrix\\Catalog\\Product\\Sku','handlerIblockElementUpdate','',1),
(130,'2016-10-18 09:00:26',100,'iblock','OnAfterIBlockElementUpdate','catalog','','\\Bitrix\\Catalog\\Product\\Sku','handlerAfterIblockElementUpdate','',1),
(131,'2016-10-18 09:00:26',100,'iblock','OnIBlockElementDelete','catalog','','\\Bitrix\\Catalog\\Product\\Sku','handlerIblockElementDelete','',1),
(132,'2016-10-18 09:00:26',100,'iblock','OnAfterIBlockElementDelete','catalog','','\\Bitrix\\Catalog\\Product\\Sku','handlerAfterIblockElementDelete','',1),
(133,'2016-10-18 09:00:26',100,'iblock','OnIBlockElementSetPropertyValues','catalog','','\\Bitrix\\Catalog\\Product\\Sku','handlerIblockElementSetPropertyValues','',1),
(134,'2016-10-18 09:00:26',100,'iblock','OnAfterIBlockElementSetPropertyValues','catalog','','\\Bitrix\\Catalog\\Product\\Sku','handlerAfterIBlockElementSetPropertyValues','',1),
(135,'2016-10-18 09:00:26',100,'perfmon','OnGetTableSchema','catalog','','catalog','getTableSchema','',1),
(136,'2016-10-18 09:00:36',100,'main','OnEventLogGetAuditTypes','clouds','','CCloudStorage','GetAuditTypes','',1),
(137,'2016-10-18 09:00:36',100,'main','OnBeforeProlog','clouds','','CCloudStorage','OnBeforeProlog','',1),
(138,'2016-10-18 09:00:36',100,'main','OnAdminListDisplay','clouds','','CCloudStorage','OnAdminListDisplay','',1),
(139,'2016-10-18 09:00:36',100,'main','OnBuildGlobalMenu','clouds','','CCloudStorage','OnBuildGlobalMenu','',1),
(140,'2016-10-18 09:00:36',100,'main','OnFileSave','clouds','','CCloudStorage','OnFileSave','',1),
(141,'2016-10-18 09:00:36',100,'main','OnGetFileSRC','clouds','','CCloudStorage','OnGetFileSRC','',1),
(142,'2016-10-18 09:00:36',100,'main','OnFileCopy','clouds','','CCloudStorage','OnFileCopy','',1),
(143,'2016-10-18 09:00:36',100,'main','OnFileDelete','clouds','','CCloudStorage','OnFileDelete','',1),
(144,'2016-10-18 09:00:36',100,'main','OnMakeFileArray','clouds','','CCloudStorage','OnMakeFileArray','',1),
(145,'2016-10-18 09:00:36',100,'main','OnBeforeResizeImage','clouds','','CCloudStorage','OnBeforeResizeImage','',1),
(146,'2016-10-18 09:00:36',100,'main','OnAfterResizeImage','clouds','','CCloudStorage','OnAfterResizeImage','',1),
(147,'2016-10-18 09:00:36',100,'clouds','OnGetStorageService','clouds','','CCloudStorageService_AmazonS3','GetObject','',1),
(148,'2016-10-18 09:00:36',100,'clouds','OnGetStorageService','clouds','','CCloudStorageService_GoogleStorage','GetObject','',1),
(149,'2016-10-18 09:00:36',100,'clouds','OnGetStorageService','clouds','','CCloudStorageService_OpenStackStorage','GetObject','',1),
(150,'2016-10-18 09:00:36',100,'clouds','OnGetStorageService','clouds','','CCloudStorageService_RackSpaceCloudFiles','GetObject','',1),
(151,'2016-10-18 09:00:36',100,'clouds','OnGetStorageService','clouds','','CCloudStorageService_ClodoRU','GetObject','',1),
(152,'2016-10-18 09:00:36',100,'clouds','OnGetStorageService','clouds','','CCloudStorageService_Selectel','GetObject','',1),
(153,'2016-10-18 09:00:37',1,'main','OnPageStart','compression','','CCompress','OnPageStart','',1),
(154,'2016-10-18 09:00:37',10000,'main','OnAfterEpilog','compression','','CCompress','OnAfterEpilog','',1),
(155,'2016-10-18 09:00:38',100,'conversion','OnGetCounterTypes','conversion','','\\Bitrix\\Conversion\\Internals\\Handlers','onGetCounterTypes','',1),
(156,'2016-10-18 09:00:38',100,'conversion','OnGetAttributeTypes','conversion','','\\Bitrix\\Conversion\\Internals\\Handlers','onGetAttributeTypes','',1),
(157,'2016-10-18 09:00:38',100,'conversion','OnGetAttributeGroupTypes','conversion','','\\Bitrix\\Conversion\\Internals\\Handlers','onGetAttributeGroupTypes','',1),
(158,'2016-10-18 09:00:38',100,'conversion','OnSetDayContextAttributes','conversion','','\\Bitrix\\Conversion\\Internals\\Handlers','onSetDayContextAttributes','',1),
(159,'2016-10-18 09:00:38',100,'main','OnProlog','conversion','','\\Bitrix\\Conversion\\Internals\\Handlers','onProlog','',1),
(160,'2016-10-18 09:00:49',100,'main','OnGroupDelete','fileman','','CFileman','OnGroupDelete','',1),
(161,'2016-10-18 09:00:49',100,'main','OnPanelCreate','fileman','','CFileman','OnPanelCreate','',1),
(162,'2016-10-18 09:00:49',100,'main','OnModuleUpdate','fileman','','CFileman','OnModuleUpdate','',1),
(163,'2016-10-18 09:00:49',100,'main','OnModuleInstalled','fileman','','CFileman','ClearComponentsListCache','',1),
(164,'2016-10-18 09:00:49',100,'iblock','OnIBlockPropertyBuildList','fileman','','CIBlockPropertyMapGoogle','GetUserTypeDescription','',1),
(165,'2016-10-18 09:00:49',100,'iblock','OnIBlockPropertyBuildList','fileman','','CIBlockPropertyMapYandex','GetUserTypeDescription','',1),
(166,'2016-10-18 09:00:49',100,'iblock','OnIBlockPropertyBuildList','fileman','','CIBlockPropertyVideo','GetUserTypeDescription','',1),
(167,'2016-10-18 09:00:49',100,'main','OnUserTypeBuildList','fileman','','CUserTypeVideo','GetUserTypeDescription','',1),
(168,'2016-10-18 09:00:49',100,'main','OnEventLogGetAuditTypes','fileman','','CEventFileman','GetAuditTypes','',1),
(169,'2016-10-18 09:00:49',100,'main','OnEventLogGetAuditHandlers','fileman','','CEventFileman','MakeFilemanObject','',1),
(170,'2016-10-18 09:01:06',100,'sender','OnConnectorList','form','','\\Bitrix\\Form\\SenderEventHandler','onConnectorListForm','',1),
(171,'2016-10-18 09:01:13',100,'main','OnAfterUserUpdate','forum','','CForumUser','OnAfterUserUpdate','',1),
(172,'2016-10-18 09:01:13',100,'main','OnGroupDelete','forum','','CForumNew','OnGroupDelete','',1),
(173,'2016-10-18 09:01:13',100,'main','OnBeforeLangDelete','forum','','CForumNew','OnBeforeLangDelete','',1),
(174,'2016-10-18 09:01:13',100,'main','OnFileDelete','forum','','CForumFiles','OnFileDelete','',1),
(175,'2016-10-18 09:01:13',100,'search','OnReindex','forum','','CForumNew','OnReindex','',1),
(176,'2016-10-18 09:01:13',100,'main','OnUserDelete','forum','','CForumUser','OnUserDelete','',1),
(177,'2016-10-18 09:01:13',100,'iblock','OnIBlockPropertyBuildList','main','/modules/forum/tools/prop_topicid.php','CIBlockPropertyTopicID','GetUserTypeDescription','',1),
(178,'2016-10-18 09:01:13',100,'iblock','OnBeforeIBlockElementDelete','forum','','CForumTopic','OnBeforeIBlockElementDelete','',1),
(179,'2016-10-18 09:01:13',100,'main','OnEventLogGetAuditTypes','forum','','CForumEventLog','GetAuditTypes','',1),
(180,'2016-10-18 09:01:13',100,'main','OnEventLogGetAuditHandlers','forum','','CEventForum','MakeForumObject','',1),
(181,'2016-10-18 09:01:13',100,'socialnetwork','OnSocNetGroupDelete','forum','','CForumUser','OnSocNetGroupDelete','',1),
(182,'2016-10-18 09:01:13',100,'socialnetwork','OnSocNetLogFormatEvent','forum','','CForumMessage','OnSocNetLogFormatEvent','',1),
(183,'2016-10-18 09:01:13',100,'mail','OnGetFilterList','forum','','CForumEMail','OnGetSocNetFilterList','',1),
(184,'2016-10-18 09:01:13',100,'main','OnAfterAddRating','forum','','CRatingsComponentsForum','OnAfterAddRating','',1),
(185,'2016-10-18 09:01:13',100,'main','OnAfterUpdateRating','forum','','CRatingsComponentsForum','OnAfterUpdateRating','',1),
(186,'2016-10-18 09:01:13',100,'main','OnSetRatingsConfigs','forum','','CRatingsComponentsForum','OnSetRatingConfigs','',1),
(187,'2016-10-18 09:01:13',100,'main','OnGetRatingsConfigs','forum','','CRatingsComponentsForum','OnGetRatingConfigs','',1),
(188,'2016-10-18 09:01:13',100,'main','OnGetRatingsObjects','forum','','CRatingsComponentsForum','OnGetRatingObject','',1),
(189,'2016-10-18 09:01:13',100,'main','OnGetRatingContentOwner','forum','','CRatingsComponentsForum','OnGetRatingContentOwner','',1),
(190,'2016-10-18 09:01:13',100,'im','OnGetNotifySchema','forum','','CForumNotifySchema','OnGetNotifySchema','',1),
(191,'2016-10-18 09:01:13',100,'main','OnAfterRegisterModule','main','/modules/forum/install/index.php','forum','InstallUserFields','',1),
(192,'2016-10-18 09:01:13',100,'conversion','OnGetCounterTypes','forum','','\\Bitrix\\Forum\\Internals\\ConversionHandlers','onGetCounterTypes','',1),
(193,'2016-10-18 09:01:13',100,'conversion','OnGetRateTypes','forum','','\\Bitrix\\Forum\\Internals\\ConversionHandlers','onGetRateTypes','',1),
(194,'2016-10-18 09:01:13',100,'forum','onAfterTopicAdd','forum','','\\Bitrix\\Forum\\Internals\\ConversionHandlers','onTopicAdd','',1),
(195,'2016-10-18 09:01:13',100,'forum','onAfterMessageAdd','forum','','\\Bitrix\\Forum\\Internals\\ConversionHandlers','onMessageAdd','',1),
(196,'2016-10-18 09:01:27',100,'main','OnBeforeUserTypeAdd','highloadblock','','\\Bitrix\\Highloadblock\\HighloadBlockTable','OnBeforeUserTypeAdd','',1),
(197,'2016-10-18 09:01:27',100,'main','OnAfterUserTypeAdd','highloadblock','','\\Bitrix\\Highloadblock\\HighloadBlockTable','onAfterUserTypeAdd','',1),
(198,'2016-10-18 09:01:27',100,'main','OnBeforeUserTypeDelete','highloadblock','','\\Bitrix\\Highloadblock\\HighloadBlockTable','OnBeforeUserTypeDelete','',1),
(199,'2016-10-18 09:01:27',100,'main','OnUserTypeBuildList','highloadblock','','CUserTypeHlblock','GetUserTypeDescription','',1),
(200,'2016-10-18 09:01:27',100,'iblock','OnIBlockPropertyBuildList','highloadblock','','CIBlockPropertyDirectory','GetUserTypeDescription','',1),
(201,'2016-10-18 09:01:40',100,'main','OnGroupDelete','iblock','','CIBlock','OnGroupDelete','',1),
(202,'2016-10-18 09:01:40',100,'main','OnBeforeLangDelete','iblock','','CIBlock','OnBeforeLangDelete','',1),
(203,'2016-10-18 09:01:40',100,'main','OnLangDelete','iblock','','CIBlock','OnLangDelete','',1),
(204,'2016-10-18 09:01:40',100,'main','OnUserTypeRightsCheck','iblock','','CIBlockSection','UserTypeRightsCheck','',1),
(205,'2016-10-18 09:01:40',100,'search','OnReindex','iblock','','CIBlock','OnSearchReindex','',1),
(206,'2016-10-18 09:01:40',100,'search','OnSearchGetURL','iblock','','CIBlock','OnSearchGetURL','',1),
(207,'2016-10-18 09:01:40',100,'main','OnEventLogGetAuditTypes','iblock','','CIBlock','GetAuditTypes','',1),
(208,'2016-10-18 09:01:40',100,'main','OnEventLogGetAuditHandlers','iblock','','CEventIBlock','MakeIBlockObject','',1),
(209,'2016-10-18 09:01:40',200,'main','OnGetRatingContentOwner','iblock','','CRatingsComponentsIBlock','OnGetRatingContentOwner','',1),
(210,'2016-10-18 09:01:40',100,'main','OnTaskOperationsChanged','iblock','','CIBlockRightsStorage','OnTaskOperationsChanged','',1),
(211,'2016-10-18 09:01:40',100,'main','OnGroupDelete','iblock','','CIBlockRightsStorage','OnGroupDelete','',1),
(212,'2016-10-18 09:01:40',100,'main','OnUserDelete','iblock','','CIBlockRightsStorage','OnUserDelete','',1),
(213,'2016-10-18 09:01:40',100,'perfmon','OnGetTableSchema','iblock','','iblock','OnGetTableSchema','',1),
(214,'2016-10-18 09:01:40',100,'sender','OnConnectorList','iblock','','\\Bitrix\\Iblock\\SenderEventHandler','onConnectorListIblock','',1),
(215,'2016-10-18 09:01:40',10,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_Date_GetUserTypeDescription','',1),
(216,'2016-10-18 09:01:40',20,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_DateTime_GetUserTypeDescription','',1),
(217,'2016-10-18 09:01:40',30,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_XmlID_GetUserTypeDescription','',1),
(218,'2016-10-18 09:01:40',40,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_FileMan_GetUserTypeDescription','',1),
(219,'2016-10-18 09:01:40',50,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_HTML_GetUserTypeDescription','',1),
(220,'2016-10-18 09:01:40',60,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_ElementList_GetUserTypeDescription','',1),
(221,'2016-10-18 09:01:40',70,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_Sequence_GetUserTypeDescription','',1),
(222,'2016-10-18 09:01:40',80,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_ElementAutoComplete_GetUserTypeDescription','',1),
(223,'2016-10-18 09:01:40',90,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_SKU_GetUserTypeDescription','',1),
(224,'2016-10-18 09:01:40',100,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_SectionAutoComplete_GetUserTypeDescription','',1),
(225,'2016-10-18 09:02:15',100,'pull','OnGetDependentModule','mobileapp','','CMobileAppPullSchema','OnGetDependentModule','',1),
(226,'2016-10-18 09:02:21',100,'perfmon','OnGetTableSchema','perfmon','','perfmon','OnGetTableSchema','',1),
(227,'2016-10-18 09:02:27',100,'iblock','OnBeforeIBlockElementDelete','photogallery','','CPhotogalleryElement','OnBeforeIBlockElementDelete','',1),
(228,'2016-10-18 09:02:27',100,'iblock','OnAfterIBlockElementAdd','photogallery','','CPhotogalleryElement','OnAfterIBlockElementAdd','',1),
(229,'2016-10-18 09:02:27',100,'search','BeforeIndex','photogallery','','CRatingsComponentsPhotogallery','BeforeIndex','',1),
(230,'2016-10-18 09:02:27',100,'im','OnGetNotifySchema','photogallery','','CPhotogalleryNotifySchema','OnGetNotifySchema','',1),
(231,'2016-10-18 09:02:38',50,'main','OnBeforeProlog','main','/modules/pull/ajax_hit_before.php','','','',1),
(232,'2016-10-18 09:02:38',3,'main','OnProlog','main','/modules/pull/ajax_hit.php','','','',1),
(233,'2016-10-18 09:02:38',100,'main','OnEpilog','pull','','CPullWatch','DeferredSql','',1),
(234,'2016-10-18 09:02:38',100,'main','OnEpilog','pull','','CPullOptions','OnEpilog','',1),
(235,'2016-10-18 09:02:38',100,'perfmon','OnGetTableSchema','pull','','CPullTableSchema','OnGetTableSchema','',1),
(236,'2016-10-18 09:02:38',100,'main','OnAfterRegisterModule','pull','','CPullOptions','ClearCheckCache','',1),
(237,'2016-10-18 09:02:38',100,'main','OnAfterUnRegisterModule','pull','','CPullOptions','ClearCheckCache','',1),
(238,'2016-10-18 09:02:54',100,'main','OnUserLogout','sale','','\\Bitrix\\Sale\\DiscountCouponsManager','logout','',1),
(239,'2016-10-18 09:02:54',100,'sale','OnSaleBasketItemRefreshData','sale','','\\Bitrix\\Sale\\Compatible\\DiscountCompatibility','OnSaleBasketItemRefreshData','',2),
(240,'2016-10-18 09:02:54',100,'main','OnUserLogin','sale','','CSaleUser','OnUserLogin','',1),
(241,'2016-10-18 09:02:54',100,'main','OnUserLogout','sale','','CSaleUser','OnUserLogout','',1),
(242,'2016-10-18 09:02:54',100,'main','OnBeforeLangDelete','sale','','CSalePersonType','OnBeforeLangDelete','',1),
(243,'2016-10-18 09:02:54',100,'main','OnLanguageDelete','sale','','CSaleLocation','OnLangDelete','',1),
(244,'2016-10-18 09:02:54',100,'main','OnLanguageDelete','sale','','CSaleLocationGroup','OnLangDelete','',1),
(245,'2016-10-18 09:02:54',100,'main','OnUserDelete','sale','','CSaleOrderUserProps','OnUserDelete','',1),
(246,'2016-10-18 09:02:54',100,'main','OnUserDelete','sale','','CSaleUserAccount','OnUserDelete','',1),
(247,'2016-10-18 09:02:54',100,'main','OnUserDelete','sale','','CSaleAuxiliary','OnUserDelete','',1),
(248,'2016-10-18 09:02:54',100,'main','OnUserDelete','sale','','CSaleUser','OnUserDelete','',1),
(249,'2016-10-18 09:02:54',100,'main','OnUserDelete','sale','','CSaleRecurring','OnUserDelete','',1),
(250,'2016-10-18 09:02:54',100,'main','OnUserDelete','sale','','CSaleUserCards','OnUserDelete','',1),
(251,'2016-10-18 09:02:54',100,'main','OnBeforeUserDelete','sale','','CSaleOrder','OnBeforeUserDelete','',1),
(252,'2016-10-18 09:02:54',100,'main','OnBeforeUserDelete','sale','','CSaleAffiliate','OnBeforeUserDelete','',1),
(253,'2016-10-18 09:02:54',100,'main','OnBeforeUserDelete','sale','','CSaleUserAccount','OnBeforeUserDelete','',1),
(254,'2016-10-18 09:02:54',100,'main','OnBeforeProlog','main','/modules/sale/affiliate.php','','','',1),
(255,'2016-10-18 09:02:54',100,'main','OnEventLogGetAuditTypes','sale','','CSaleYMHandler','OnEventLogGetAuditTypes','',1),
(256,'2016-10-18 09:02:54',100,'main','OnEventLogGetAuditTypes','sale','','CSalePaySystemAction','OnEventLogGetAuditTypes','',1),
(257,'2016-10-18 09:02:54',100,'currency','OnBeforeCurrencyDelete','sale','','CSaleOrder','OnBeforeCurrencyDelete','',1),
(258,'2016-10-18 09:02:54',100,'currency','OnBeforeCurrencyDelete','sale','','CSaleLang','OnBeforeCurrencyDelete','',1),
(259,'2016-10-18 09:02:54',100,'currency','OnModuleUnInstall','sale','','','CurrencyModuleUnInstallSale','',1),
(260,'2016-10-18 09:02:54',100,'catalog','OnSaleOrderSumm','sale','','CSaleOrder','__SaleOrderCount','',1),
(261,'2016-10-18 09:02:54',100,'mobileapp','OnBeforeAdminMobileMenuBuild','sale','','CSaleMobileOrderUtils','buildSaleAdminMobileMenu','',1),
(262,'2016-10-18 09:02:54',100,'sender','OnConnectorList','sale','','\\Bitrix\\Sale\\SenderEventHandler','onConnectorListBuyer','',1),
(263,'2016-10-18 09:02:54',100,'sender','OnTriggerList','sale','','\\Bitrix\\Sale\\Sender\\EventHandler','onTriggerList','',1),
(264,'2016-10-18 09:02:54',100,'sender','OnPresetMailingList','sale','','\\Bitrix\\Sale\\Sender\\EventHandler','onPresetMailingList','',1),
(265,'2016-10-18 09:02:54',100,'sender','OnPresetTemplateList','sale','','\\Bitrix\\Sale\\Sender\\EventHandler','onPresetTemplateList','',1),
(266,'2016-10-18 09:02:54',100,'sender','OnConnectorList','sale','','Bitrix\\Sale\\Bigdata\\TargetSaleMailConnector','onConnectorList','',1),
(267,'2016-10-18 09:02:54',100,'sale','OnCondSaleControlBuildList','sale','','CSaleCondCtrlGroup','GetControlDescr','',1),
(268,'2016-10-18 09:02:54',200,'sale','OnCondSaleControlBuildList','sale','','CSaleCondCtrlBasketGroup','GetControlDescr','',1),
(269,'2016-10-18 09:02:54',200,'sale','OnCondSaleActionsControlBuildList','sale','','CSaleActionGiftCtrlGroup','GetControlDescr','',1),
(270,'2016-10-18 09:02:54',300,'sale','OnCondSaleControlBuildList','sale','','CSaleCondCtrlBasketFields','GetControlDescr','',1),
(271,'2016-10-18 09:02:54',1000,'sale','OnCondSaleControlBuildList','sale','','CSaleCondCtrlOrderFields','GetControlDescr','',1),
(272,'2016-10-18 09:02:54',10000,'sale','OnCondSaleControlBuildList','sale','','CSaleCondCtrlCommon','GetControlDescr','',1),
(273,'2016-10-18 09:02:54',100,'sale','OnCondSaleActionsControlBuildList','sale','','CSaleActionCtrlGroup','GetControlDescr','',1),
(274,'2016-10-18 09:02:54',200,'sale','OnCondSaleActionsControlBuildList','sale','','CSaleActionCtrlDelivery','GetControlDescr','',1),
(275,'2016-10-18 09:02:54',300,'sale','OnCondSaleActionsControlBuildList','sale','','CSaleActionCtrlBasketGroup','GetControlDescr','',1),
(276,'2016-10-18 09:02:54',1000,'sale','OnCondSaleActionsControlBuildList','sale','','CSaleActionCtrlSubGroup','GetControlDescr','',1),
(277,'2016-10-18 09:02:54',1100,'sale','OnCondSaleActionsControlBuildList','sale','','CSaleActionCondCtrlBasketFields','GetControlDescr','',1),
(278,'2016-10-18 09:02:54',100,'sale','OnOrderDelete','sale','','CSaleMobileOrderPull','onOrderDelete','',1),
(279,'2016-10-18 09:02:54',100,'sale','OnOrderAdd','sale','','CSaleMobileOrderPull','onOrderAdd','',1),
(280,'2016-10-18 09:02:54',100,'sale','OnOrderUpdate','sale','','CSaleMobileOrderPull','onOrderUpdate','',1),
(281,'2016-10-18 09:02:54',100,'sale','OnBasketOrder','sale','','\\Bitrix\\Sale\\Product2ProductTable','onSaleOrderAdd','',1),
(282,'2016-10-18 09:02:54',100,'sale','OnSaleStatusOrder','sale','','\\Bitrix\\Sale\\Product2ProductTable','onSaleStatusOrderHandler','',1),
(283,'2016-10-18 09:02:54',100,'sale','OnSaleDeliveryOrder','sale','','\\Bitrix\\Sale\\Product2ProductTable','onSaleDeliveryOrderHandler','',1),
(284,'2016-10-18 09:02:55',100,'sale','OnSaleDeductOrder','sale','','\\Bitrix\\Sale\\Product2ProductTable','onSaleDeductOrderHandler','',1),
(285,'2016-10-18 09:02:55',100,'sale','OnSaleCancelOrder','sale','','\\Bitrix\\Sale\\Product2ProductTable','onSaleCancelOrderHandler','',1),
(286,'2016-10-18 09:02:55',100,'sale','OnSalePayOrder','sale','','\\Bitrix\\Sale\\Product2ProductTable','onSalePayOrderHandler','',1),
(287,'2016-10-18 09:02:55',100,'conversion','OnGetCounterTypes','sale','','\\Bitrix\\Sale\\Internals\\ConversionHandlers','onGetCounterTypes','',1),
(288,'2016-10-18 09:02:55',100,'conversion','OnGetRateTypes','sale','','\\Bitrix\\Sale\\Internals\\ConversionHandlers','onGetRateTypes','',1),
(289,'2016-10-18 09:02:55',100,'conversion','OnGenerateInitialData','sale','','\\Bitrix\\Sale\\Internals\\ConversionHandlers','onGenerateInitialData','',1),
(290,'2016-10-18 09:02:55',100,'sale','OnBeforeBasketAdd','sale','','\\Bitrix\\Sale\\Internals\\ConversionHandlers','onBeforeBasketAdd','',1),
(291,'2016-10-18 09:02:55',100,'sale','OnBasketAdd','sale','','\\Bitrix\\Sale\\Internals\\ConversionHandlers','onBasketAdd','',1),
(292,'2016-10-18 09:02:55',100,'sale','OnBeforeBasketUpdate','sale','','\\Bitrix\\Sale\\Internals\\ConversionHandlers','onBeforeBasketUpdate','',1),
(293,'2016-10-18 09:02:55',100,'sale','OnBasketUpdate','sale','','\\Bitrix\\Sale\\Internals\\ConversionHandlers','onBasketUpdate','',1),
(294,'2016-10-18 09:02:55',100,'sale','OnBeforeBasketDelete','sale','','\\Bitrix\\Sale\\Internals\\ConversionHandlers','onBeforeBasketDelete','',1),
(295,'2016-10-18 09:02:55',100,'sale','OnBasketDelete','sale','','\\Bitrix\\Sale\\Internals\\ConversionHandlers','onBasketDelete','',1),
(296,'2016-10-18 09:02:55',100,'sale','OnOrderAdd','sale','','\\Bitrix\\Sale\\Internals\\ConversionHandlers','onOrderAdd','',1),
(297,'2016-10-18 09:02:55',100,'sale','OnSalePayOrder','sale','','\\Bitrix\\Sale\\Internals\\ConversionHandlers','onSalePayOrder','',1),
(298,'2016-10-18 09:02:55',100,'sale','OnGetBusinessValueGroups','sale','','\\Bitrix\\Sale\\PaySystem\\Manager','getBusValueGroups','',1),
(299,'2016-10-18 09:02:55',100,'sale','OnGetBusinessValueConsumers','sale','','\\Bitrix\\Sale\\PaySystem\\Manager','getConsumersList','',1),
(300,'2016-10-18 09:02:55',100,'perfmon','OnGetTableSchema','sale','','sale','OnGetTableSchema','',1),
(301,'2016-10-18 09:02:55',100,'sale','OnSaleBasketItemEntitySaved','sale','','\\Bitrix\\Sale\\Internals\\Events','onSaleBasketItemEntitySaved','',2),
(302,'2016-10-18 09:02:55',100,'sale','OnSaleBasketItemDeleted','sale','','\\Bitrix\\Sale\\Internals\\Events','onSaleBasketItemDeleted','',2),
(303,'2016-10-18 09:02:55',100,'sale','OnSaleOrderPaid','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onSalePayOrder','',2),
(304,'2016-10-18 09:02:55',100,'sale','OnSaleOrderBeforeSaved','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onOrderBeforeSaved','',2),
(305,'2016-10-18 09:02:55',100,'sale','OnSaleBeforeOrderDelete','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onBeforeOrderDelete','',2),
(306,'2016-10-18 09:02:55',100,'sale','OnSaleOrderDeleted','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onOrderDelete','',2),
(307,'2016-10-18 09:02:55',100,'sale','OnSaleShipmentDelivery','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onSaleDeliveryOrder','',2),
(308,'2016-10-18 09:02:55',100,'sale','OnSaleBeforeOrderCanceled','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onSaleBeforeCancelOrder','',2),
(309,'2016-10-18 09:02:55',100,'sale','OnSaleOrderCanceled','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onSaleCancelOrder','',2),
(310,'2016-10-18 09:02:55',100,'sale','OnSaleOrderPaidSendMail','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onSaleOrderPaidSendMail','',2),
(311,'2016-10-18 09:02:55',100,'sale','OnSaleOrderCancelSendEmail','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onSaleOrderCancelSendEmail','',2),
(312,'2016-10-18 09:02:55',100,'sale','OnSaleOrderEntitySaved','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onOrderSave','',2),
(313,'2016-10-18 09:02:55',100,'sale','OnSaleOrderSaved','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onOrderSaved','',2),
(314,'2016-10-18 09:02:55',100,'sale','OnSaleBasketItemBeforeSaved','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onBasketItemBeforeChange','',2),
(315,'2016-10-18 09:02:55',100,'sale','OnSaleBasketItemEntitySaved','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onBasketItemChange','',2),
(316,'2016-10-18 09:02:55',100,'sale','OnShipmentTrackingNumberChange','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onShipmentTrackingNumberChange','',2),
(317,'2016-10-18 09:02:55',100,'sale','OnSaleBeforeStatusOrderChange','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onSaleBeforeStatusOrderChange','',2),
(318,'2016-10-18 09:02:55',100,'sale','OnSaleStatusOrderChange','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onSaleStatusOrderChange','',2),
(319,'2016-10-18 09:02:55',100,'sale','OnSaleOrderStatusChangeSendEmail','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onSaleOrderStatusChangeSendEmail','',2),
(320,'2016-10-18 09:02:55',100,'sale','OnSaleOrderSaved','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onOrderNewSendEmail','',2),
(321,'2016-10-18 09:02:55',100,'sale','OnOrderNewSendEmail','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onCallOrderNewSendEmail','',1),
(322,'2016-10-18 09:02:55',100,'sale','OnBeforeSaleBasketItemEntityDeleted','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','OnBeforeBasketDelete','',2),
(323,'2016-10-18 09:02:55',100,'sale','OnSaleBasketItemDeleted','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','OnBasketDelete','',2),
(324,'2016-10-18 09:02:55',100,'sale','OnShipmentAllowDelivery','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onShipmentAllowDelivery','',2),
(325,'2016-10-18 09:02:55',100,'sale','OnOrderCancelSendEmail','sale','','\\Bitrix\\Sale\\Compatible\\EventCompatibility','onCallOrderCancelSendEmail','',1),
(326,'2016-10-18 09:02:55',100,'sale','OnSaleOrderSaved','sale','','\\Bitrix\\Sale\\Product2ProductTable','onSaleOrderAddEvent','',2),
(327,'2016-10-18 09:02:55',100,'sale','OnSaleStatusOrderChange','sale','','\\Bitrix\\Sale\\Product2ProductTable','onSaleStatusOrderHandlerEvent','',2),
(328,'2016-10-18 09:02:55',100,'sale','OnShipmentAllowDelivery','sale','','\\Bitrix\\Sale\\Product2ProductTable','onSaleDeliveryOrderHandlerEvent','',2),
(329,'2016-10-18 09:02:55',100,'sale','OnShipmentDeducted','sale','','\\Bitrix\\Sale\\Product2ProductTable','onSaleDeductOrderHandlerEvent','',2),
(330,'2016-10-18 09:02:55',100,'sale','OnSaleOrderCanceled','sale','','\\Bitrix\\Sale\\Product2ProductTable','onSaleCancelOrderHandlerEvent','',2),
(331,'2016-10-18 09:02:55',100,'sale','OnSaleOrderPaid','sale','','\\Bitrix\\Sale\\Product2ProductTable','onSalePayOrderHandlerEvent','',2),
(332,'2016-10-18 09:03:22',100,'main','OnEventLogGetAuditTypes','scale','','\\Bitrix\\Scale\\Logger','onEventLogGetAuditTypes','',1),
(333,'2016-10-18 09:03:24',100,'main','OnChangePermissions','search','','CSearch','OnChangeFilePermissions','',1),
(334,'2016-10-18 09:03:24',100,'main','OnChangeFile','search','','CSearch','OnChangeFile','',1),
(335,'2016-10-18 09:03:24',100,'main','OnGroupDelete','search','','CSearch','OnGroupDelete','',1),
(336,'2016-10-18 09:03:24',100,'main','OnLangDelete','search','','CSearch','OnLangDelete','',1),
(337,'2016-10-18 09:03:24',100,'main','OnAfterUserUpdate','search','','CSearchUser','OnAfterUserUpdate','',1),
(338,'2016-10-18 09:03:24',100,'main','OnUserDelete','search','','CSearchUser','DeleteByUserID','',1),
(339,'2016-10-18 09:03:24',100,'cluster','OnGetTableList','search','','search','OnGetTableList','',1),
(340,'2016-10-18 09:03:24',100,'perfmon','OnGetTableSchema','search','','search','OnGetTableSchema','',1),
(341,'2016-10-18 09:03:25',90,'main','OnEpilog','search','','CSearchStatistic','OnEpilog','',1),
(342,'2016-10-18 09:03:28',100,'main','OnUserDelete','security','','CSecurityUser','OnUserDelete','',1),
(343,'2016-10-18 09:03:28',100,'main','OnEventLogGetAuditTypes','security','','CSecurityFilter','GetAuditTypes','',1),
(344,'2016-10-18 09:03:28',100,'main','OnEventLogGetAuditTypes','security','','CSecurityAntiVirus','GetAuditTypes','',1),
(345,'2016-10-18 09:03:28',100,'main','OnAdminInformerInsertItems','security','','CSecurityFilter','OnAdminInformerInsertItems','',1),
(346,'2016-10-18 09:03:28',100,'main','OnAdminInformerInsertItems','security','','CSecuritySiteChecker','OnAdminInformerInsertItems','',1),
(347,'2016-10-18 09:03:28',5,'main','OnBeforeProlog','security','','CSecurityFilter','OnBeforeProlog','',1),
(348,'2016-10-18 09:03:28',9999,'main','OnEndBufferContent','security','','CSecurityXSSDetect','OnEndBufferContent','',1),
(349,'2016-10-18 09:03:29',1,'main','OnBeforeLocalRedirect','security','','CSecurityRedirect','BeforeLocalRedirect','',1),
(350,'2016-10-18 09:03:29',1,'main','OnEndBufferContent','security','','CSecurityRedirect','EndBufferContent','',1),
(351,'2016-10-18 09:03:32',100,'main','OnMailEventMailRead','sender','','bitrix\\sender\\postingmanager','onMailEventMailRead','',1),
(352,'2016-10-18 09:03:32',100,'main','OnMailEventMailClick','sender','','bitrix\\sender\\postingmanager','onMailEventMailClick','',1),
(353,'2016-10-18 09:03:32',100,'main','OnMailEventSubscriptionDisable','sender','','Bitrix\\Sender\\Subscription','onMailEventSubscriptionDisable','',1),
(354,'2016-10-18 09:03:32',100,'main','OnMailEventSubscriptionEnable','sender','','Bitrix\\Sender\\Subscription','onMailEventSubscriptionEnable','',1),
(355,'2016-10-18 09:03:32',100,'main','OnMailEventSubscriptionList','sender','','Bitrix\\Sender\\Subscription','onMailEventSubscriptionList','',1),
(356,'2016-10-18 09:03:32',100,'sender','OnConnectorList','sender','','bitrix\\sender\\connectormanager','onConnectorListContact','',1),
(357,'2016-10-18 09:03:32',100,'sender','OnConnectorList','sender','','bitrix\\sender\\connectormanager','onConnectorListRecipient','',1),
(358,'2016-10-18 09:03:32',100,'sender','OnPresetTemplateList','sender','','Bitrix\\Sender\\Preset\\TemplateBase','onPresetTemplateList','',1),
(359,'2016-10-18 09:03:32',100,'sender','OnPresetTemplateList','sender','','Bitrix\\Sender\\TemplateTable','onPresetTemplateList','',1),
(360,'2016-10-18 09:03:32',100,'sender','OnPresetMailBlockList','sender','','Bitrix\\Sender\\Preset\\MailBlockBase','OnPresetMailBlockList','',1),
(361,'2016-10-18 09:03:32',100,'sender','OnPresetTemplateList','sender','','Bitrix\\Sender\\Preset\\TemplateBase','onPresetTemplateListSite','',1),
(362,'2016-10-18 09:03:32',100,'sender','OnTriggerList','sender','','bitrix\\sender\\triggermanager','onTriggerList','',1),
(363,'2016-10-18 09:03:32',100,'sender','OnAfterRecipientUnsub','sender','','Bitrix\\Sender\\TriggerManager','onAfterRecipientUnsub','',1),
(364,'2016-10-18 09:03:32',100,'sender','OnAfterRecipientClick','sender','','Bitrix\\Sender\\Internals\\ConversionHandler','onAfterRecipientClick','',1),
(365,'2016-10-18 09:03:32',100,'conversion','OnSetDayContextAttributes','sender','','Bitrix\\Sender\\Internals\\ConversionHandler','onSetDayContextAttributes','',1),
(366,'2016-10-18 09:03:32',100,'main','OnBeforeProlog','sender','','Bitrix\\Sender\\Internals\\ConversionHandler','onBeforeProlog','',1),
(367,'2016-10-18 09:03:32',100,'conversion','OnGetAttributeTypes','sender','','Bitrix\\Sender\\Internals\\ConversionHandler','onGetAttributeTypes','',1),
(368,'2016-10-18 09:03:33',100,'sender','OnAfterMailingChainSend','sender','','Bitrix\\Sender\\TriggerManager','onAfterMailingChainSend','',2),
(369,'2016-10-18 09:03:33',100,'sender','OnAfterPostingSendRecipient','sender','','Bitrix\\Sender\\TriggerManager','onAfterPostingSendRecipient','',2),
(370,'2016-10-18 09:03:35',100,'main','OnPanelCreate','seo','','CSeoEventHandlers','SeoOnPanelCreate','',2),
(371,'2016-10-18 09:03:35',100,'fileman','OnIncludeHTMLEditorScript','seo','','CSeoEventHandlers','OnIncludeHTMLEditorScript','',2),
(372,'2016-10-18 09:03:35',100,'fileman','OnBeforeHTMLEditorScriptRuns','seo','','CSeoEventHandlers','OnBeforeHTMLEditorScriptRuns','',2),
(373,'2016-10-18 09:03:35',100,'iblock','OnAfterIBlockSectionAdd','seo','','\\Bitrix\\Seo\\SitemapIblock','addSection','',2),
(374,'2016-10-18 09:03:35',100,'iblock','OnAfterIBlockElementAdd','seo','','\\Bitrix\\Seo\\SitemapIblock','addElement','',2),
(375,'2016-10-18 09:03:35',100,'iblock','OnBeforeIBlockSectionDelete','seo','','\\Bitrix\\Seo\\SitemapIblock','beforeDeleteSection','',2),
(376,'2016-10-18 09:03:35',100,'iblock','OnBeforeIBlockElementDelete','seo','','\\Bitrix\\Seo\\SitemapIblock','beforeDeleteElement','',2),
(377,'2016-10-18 09:03:35',100,'iblock','OnAfterIBlockSectionDelete','seo','','\\Bitrix\\Seo\\SitemapIblock','deleteSection','',2),
(378,'2016-10-18 09:03:35',100,'iblock','OnAfterIBlockElementDelete','seo','','\\Bitrix\\Seo\\SitemapIblock','deleteElement','',2),
(379,'2016-10-18 09:03:35',100,'iblock','OnBeforeIBlockSectionUpdate','seo','','\\Bitrix\\Seo\\SitemapIblock','beforeUpdateSection','',2),
(380,'2016-10-18 09:03:35',100,'iblock','OnBeforeIBlockElementUpdate','seo','','\\Bitrix\\Seo\\SitemapIblock','beforeUpdateElement','',2),
(381,'2016-10-18 09:03:35',100,'iblock','OnAfterIBlockSectionUpdate','seo','','\\Bitrix\\Seo\\SitemapIblock','updateSection','',2),
(382,'2016-10-18 09:03:35',100,'iblock','OnAfterIBlockElementUpdate','seo','','\\Bitrix\\Seo\\SitemapIblock','updateElement','',2),
(383,'2016-10-18 09:03:35',100,'forum','onAfterTopicAdd','seo','','\\Bitrix\\Seo\\SitemapForum','addTopic','',2),
(384,'2016-10-18 09:03:35',100,'forum','onAfterTopicUpdate','seo','','\\Bitrix\\Seo\\SitemapForum','updateTopic','',2),
(385,'2016-10-18 09:03:35',100,'forum','onAfterTopicDelete','seo','','\\Bitrix\\Seo\\SitemapForum','deleteTopic','',2),
(386,'2016-10-18 09:03:35',100,'main','OnAdminIBlockElementEdit','seo','','\\Bitrix\\Seo\\AdvTabEngine','eventHandler','',2),
(387,'2016-10-18 09:03:35',100,'main','OnBeforeProlog','seo','','\\Bitrix\\Seo\\AdvSession','checkSession','',2),
(388,'2016-10-18 09:03:35',100,'sale','OnOrderSave','seo','','\\Bitrix\\Seo\\AdvSession','onOrderSave','',2),
(389,'2016-10-18 09:03:35',100,'sale','OnBasketOrder','seo','','\\Bitrix\\Seo\\AdvSession','onBasketOrder','',2),
(390,'2016-10-18 09:03:35',100,'sale','onSalePayOrder','seo','','\\Bitrix\\Seo\\AdvSession','onSalePayOrder','',2),
(391,'2016-10-18 09:03:35',100,'sale','onSaleDeductOrder','seo','','\\Bitrix\\Seo\\AdvSession','onSaleDeductOrder','',2),
(392,'2016-10-18 09:03:36',100,'sale','onSaleDeliveryOrder','seo','','\\Bitrix\\Seo\\AdvSession','onSaleDeliveryOrder','',2),
(393,'2016-10-18 09:03:36',100,'sale','onSaleStatusOrder','seo','','\\Bitrix\\Seo\\AdvSession','onSaleStatusOrder','',2),
(394,'2016-10-18 09:03:36',100,'conversion','OnSetDayContextAttributes','seo','','\\Bitrix\\Seo\\ConversionHandler','onSetDayContextAttributes','',2),
(395,'2016-10-18 09:03:36',100,'conversion','OnGetAttributeTypes','seo','','\\Bitrix\\Seo\\ConversionHandler','onGetAttributeTypes','',2),
(396,'2016-10-18 09:03:36',100,'catalog','OnProductUpdate','seo','','\\Bitrix\\Seo\\Adv\\Auto','checkQuantity','',2),
(397,'2016-10-18 09:03:36',100,'catalog','OnProductSetAvailableUpdate','seo','','\\Bitrix\\Seo\\Adv\\Auto','checkQuantity','',2),
(398,'2016-10-18 09:03:37',100,'main','OnUserDelete','socialservices','','CSocServAuthDB','OnUserDelete','',1),
(399,'2016-10-18 09:03:37',100,'timeman','OnAfterTMReportDailyAdd','socialservices','','CSocServAuthDB','OnAfterTMReportDailyAdd','',1),
(400,'2016-10-18 09:03:37',100,'timeman','OnAfterTMDayStart','socialservices','','CSocServAuthDB','OnAfterTMDayStart','',1),
(401,'2016-10-18 09:03:37',100,'timeman','OnTimeManShow','socialservices','','CSocServEventHandlers','OnTimeManShow','',1),
(402,'2016-10-18 09:03:37',100,'main','OnFindExternalUser','socialservices','','CSocServAuthDB','OnFindExternalUser','',1),
(403,'2016-10-18 09:03:39',100,'main','OnPrologAdminTitle','storeassist','','CStoreAssist','onPrologAdminTitle','',1),
(404,'2016-10-18 09:03:39',100,'main','OnBuildGlobalMenu','storeassist','','CStoreAssist','onBuildGlobalMenu','',1),
(405,'2016-10-18 09:03:42',100,'main','OnBeforeLangDelete','subscribe','','CRubric','OnBeforeLangDelete','',1),
(406,'2016-10-18 09:03:42',100,'main','OnUserDelete','subscribe','','CSubscription','OnUserDelete','',1),
(407,'2016-10-18 09:03:42',100,'main','OnUserLogout','subscribe','','CSubscription','OnUserLogout','',1),
(408,'2016-10-18 09:03:42',100,'main','OnGroupDelete','subscribe','','CPosting','OnGroupDelete','',1),
(409,'2016-10-18 09:03:42',100,'sender','OnConnectorList','subscribe','','Bitrix\\Subscribe\\SenderEventHandler','onConnectorListSubscriber','',1),
(410,'2016-10-18 09:03:45',100,'main','OnPanelCreate','translate','','CTranslateEventHandlers','TranslatOnPanelCreate','',1),
(411,'2016-10-18 09:03:50',100,'main','OnBeforeProlog','main','/modules/vote/keepvoting.php','','','',1),
(412,'2016-10-18 09:03:50',200,'main','OnUserTypeBuildList','vote','','CUserTypeVote','GetUserTypeDescription','',1),
(413,'2016-10-18 09:03:50',200,'main','OnUserLogin','vote','','CVoteUser','OnUserLogin','',1),
(414,'2016-10-18 09:03:50',100,'im','OnGetNotifySchema','vote','','CVoteNotifySchema','OnGetNotifySchema','',1),
(415,'2016-10-18 09:05:31',100,'main','OnBeforeProlog','main','/modules/main/install/wizard_sol/panel_button.php','CWizardSolPanel','ShowPanel','',1)	;
#	TC`b_operation`utf8_unicode_ci	;
CREATE TABLE `b_operation` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BINDING` varchar(50) COLLATE utf8_unicode_ci DEFAULT 'module',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_operation`utf8_unicode_ci	;
INSERT INTO `b_operation` VALUES 
(1,'edit_php','main',\N,'module'),
(2,'view_own_profile','main',\N,'module'),
(3,'edit_own_profile','main',\N,'module'),
(4,'view_all_users','main',\N,'module'),
(5,'view_groups','main',\N,'module'),
(6,'view_tasks','main',\N,'module'),
(7,'view_other_settings','main',\N,'module'),
(8,'view_subordinate_users','main',\N,'module'),
(9,'edit_subordinate_users','main',\N,'module'),
(10,'edit_all_users','main',\N,'module'),
(11,'edit_groups','main',\N,'module'),
(12,'edit_tasks','main',\N,'module'),
(13,'edit_other_settings','main',\N,'module'),
(14,'cache_control','main',\N,'module'),
(15,'lpa_template_edit','main',\N,'module'),
(16,'view_event_log','main',\N,'module'),
(17,'edit_ratings','main',\N,'module'),
(18,'manage_short_uri','main',\N,'module'),
(19,'fm_view_permission','main',\N,'file'),
(20,'fm_view_file','main',\N,'file'),
(21,'fm_view_listing','main',\N,'file'),
(22,'fm_edit_existent_folder','main',\N,'file'),
(23,'fm_create_new_file','main',\N,'file'),
(24,'fm_edit_existent_file','main',\N,'file'),
(25,'fm_create_new_folder','main',\N,'file'),
(26,'fm_delete_file','main',\N,'file'),
(27,'fm_delete_folder','main',\N,'file'),
(28,'fm_edit_in_workflow','main',\N,'file'),
(29,'fm_rename_file','main',\N,'file'),
(30,'fm_rename_folder','main',\N,'file'),
(31,'fm_upload_file','main',\N,'file'),
(32,'fm_add_to_menu','main',\N,'file'),
(33,'fm_download_file','main',\N,'file'),
(34,'fm_lpa','main',\N,'file'),
(35,'fm_edit_permission','main',\N,'file'),
(36,'catalog_view','catalog',\N,'module'),
(37,'catalog_read','catalog',\N,'module'),
(38,'catalog_price','catalog',\N,'module'),
(39,'catalog_group','catalog',\N,'module'),
(40,'catalog_discount','catalog',\N,'module'),
(41,'catalog_vat','catalog',\N,'module'),
(42,'catalog_extra','catalog',\N,'module'),
(43,'catalog_store','catalog',\N,'module'),
(44,'catalog_purchas_info','catalog',\N,'module'),
(45,'catalog_export_edit','catalog',\N,'module'),
(46,'catalog_export_exec','catalog',\N,'module'),
(47,'catalog_import_edit','catalog',\N,'module'),
(48,'catalog_import_exec','catalog',\N,'module'),
(49,'catalog_measure','catalog',\N,'module'),
(50,'catalog_settings','catalog',\N,'module'),
(51,'clouds_browse','clouds',\N,'module'),
(52,'clouds_upload','clouds',\N,'module'),
(53,'clouds_config','clouds',\N,'module'),
(54,'fileman_view_all_settings','fileman','','module'),
(55,'fileman_edit_menu_types','fileman','','module'),
(56,'fileman_add_element_to_menu','fileman','','module'),
(57,'fileman_edit_menu_elements','fileman','','module'),
(58,'fileman_edit_existent_files','fileman','','module'),
(59,'fileman_edit_existent_folders','fileman','','module'),
(60,'fileman_admin_files','fileman','','module'),
(61,'fileman_admin_folders','fileman','','module'),
(62,'fileman_view_permissions','fileman','','module'),
(63,'fileman_edit_all_settings','fileman','','module'),
(64,'fileman_upload_files','fileman','','module'),
(65,'fileman_view_file_structure','fileman','','module'),
(66,'fileman_install_control','fileman','','module'),
(67,'medialib_view_collection','fileman','','medialib'),
(68,'medialib_new_collection','fileman','','medialib'),
(69,'medialib_edit_collection','fileman','','medialib'),
(70,'medialib_del_collection','fileman','','medialib'),
(71,'medialib_access','fileman','','medialib'),
(72,'medialib_new_item','fileman','','medialib'),
(73,'medialib_edit_item','fileman','','medialib'),
(74,'medialib_del_item','fileman','','medialib'),
(75,'sticker_view','fileman','','stickers'),
(76,'sticker_edit','fileman','','stickers'),
(77,'sticker_new','fileman','','stickers'),
(78,'sticker_del','fileman','','stickers'),
(79,'section_read','iblock',\N,'iblock'),
(80,'element_read','iblock',\N,'iblock'),
(81,'section_element_bind','iblock',\N,'iblock'),
(82,'iblock_admin_display','iblock',\N,'iblock'),
(83,'element_edit','iblock',\N,'iblock'),
(84,'element_edit_price','iblock',\N,'iblock'),
(85,'element_delete','iblock',\N,'iblock'),
(86,'element_bizproc_start','iblock',\N,'iblock'),
(87,'section_edit','iblock',\N,'iblock'),
(88,'section_delete','iblock',\N,'iblock'),
(89,'section_section_bind','iblock',\N,'iblock'),
(90,'element_edit_any_wf_status','iblock',\N,'iblock'),
(91,'iblock_edit','iblock',\N,'iblock'),
(92,'iblock_delete','iblock',\N,'iblock'),
(93,'iblock_rights_edit','iblock',\N,'iblock'),
(94,'iblock_export','iblock',\N,'iblock'),
(95,'section_rights_edit','iblock',\N,'iblock'),
(96,'element_rights_edit','iblock',\N,'iblock'),
(97,'sale_status_view','sale',\N,'status'),
(98,'sale_status_cancel','sale',\N,'status'),
(99,'sale_status_mark','sale',\N,'status'),
(100,'sale_status_delivery','sale',\N,'status'),
(101,'sale_status_deduction','sale',\N,'status'),
(102,'sale_status_payment','sale',\N,'status'),
(103,'sale_status_to','sale',\N,'status'),
(104,'sale_status_update','sale',\N,'status'),
(105,'sale_status_delete','sale',\N,'status'),
(106,'sale_status_from','sale',\N,'status'),
(107,'security_filter_bypass','security',\N,'module'),
(108,'security_edit_user_otp','security',\N,'module'),
(109,'security_module_settings_read','security',\N,'module'),
(110,'security_panel_view','security',\N,'module'),
(111,'security_filter_settings_read','security',\N,'module'),
(112,'security_otp_settings_read','security',\N,'module'),
(113,'security_iprule_admin_settings_read','security',\N,'module'),
(114,'security_session_settings_read','security',\N,'module'),
(115,'security_redirect_settings_read','security',\N,'module'),
(116,'security_stat_activity_settings_read','security',\N,'module'),
(117,'security_iprule_settings_read','security',\N,'module'),
(118,'security_antivirus_settings_read','security',\N,'module'),
(119,'security_frame_settings_read','security',\N,'module'),
(120,'security_module_settings_write','security',\N,'module'),
(121,'security_filter_settings_write','security',\N,'module'),
(122,'security_otp_settings_write','security',\N,'module'),
(123,'security_iprule_admin_settings_write','security',\N,'module'),
(124,'security_session_settings_write','security',\N,'module'),
(125,'security_redirect_settings_write','security',\N,'module'),
(126,'security_stat_activity_settings_write','security',\N,'module'),
(127,'security_iprule_settings_write','security',\N,'module'),
(128,'security_file_verifier_sign','security',\N,'module'),
(129,'security_file_verifier_collect','security',\N,'module'),
(130,'security_file_verifier_verify','security',\N,'module'),
(131,'security_antivirus_settings_write','security',\N,'module'),
(132,'security_frame_settings_write','security',\N,'module'),
(133,'seo_settings','seo','','module'),
(134,'seo_tools','seo','','module')	;
#	TC`b_option`utf8_unicode_ci	;
CREATE TABLE `b_option` (
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  UNIQUE KEY `ix_option` (`MODULE_ID`,`NAME`,`SITE_ID`),
  KEY `ix_option_name` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_option`utf8_unicode_ci	;
INSERT INTO `b_option` VALUES 
('main','rating_authority_rating','4',\N,\N),
('main','rating_assign_rating_group_add','1',\N,\N),
('main','rating_assign_rating_group_delete','1',\N,\N),
('main','rating_assign_rating_group','3',\N,\N),
('main','rating_assign_authority_group_add','2',\N,\N),
('main','rating_assign_authority_group_delete','2',\N,\N),
('main','rating_assign_authority_group','4',\N,\N),
('main','rating_community_size','0',\N,\N),
('main','rating_community_authority','',\N,\N),
('main','rating_vote_weight','1',\N,\N),
('main','rating_normalization_type','auto',\N,\N),
('main','rating_normalization','10',\N,\N),
('main','rating_count_vote','10',\N,\N),
('main','rating_authority_weight_formula','Y',\N,\N),
('main','rating_community_last_visit','90',\N,\N),
('main','rating_text_like_y','Нравится',\N,\N),
('main','rating_text_like_n','Не нравится',\N,\N),
('main','rating_text_like_d','Это нравится',\N,\N),
('main','rating_assign_type','auto',\N,\N),
('main','rating_vote_type','standart',\N,\N),
('main','rating_self_vote','Y',\N,\N),
('main','rating_vote_show','Y',\N,\N),
('main','rating_vote_template','like',\N,\N),
('main','rating_start_authority','3',\N,\N),
('main','PARAM_MAX_SITES','2',\N,\N),
('main','PARAM_MAX_USERS','0',\N,\N),
('main','distributive6','Y',\N,\N),
('main','~new_license11_sign','Y',\N,\N),
('main','GROUP_DEFAULT_TASK','1',\N,\N),
('main','vendor','1c_bitrix',\N,\N),
('main','admin_lid','ru',\N,\N),
('main','update_site','www.bitrixsoft.com',\N,\N),
('main','update_site_ns','Y',\N,\N),
('main','optimize_css_files','Y',\N,\N),
('main','optimize_js_files','Y',\N,\N),
('main','admin_passwordh','FVkQeWYUBwYtCUVcARcACgsTAQ==',\N,\N),
('main','server_uniq_id','6cef5e7f012739d1fba1e69aa1db6b90',\N,\N),
('blog','socNetNewPerms','Y',\N,\N),
('catalog','subscribe_repeated_notify','Y',\N,\N),
('conversion','START_DATE_TIME','2016-10-18 08:00:38',\N,\N),
('conversion','GENERATE_INITIAL_DATA','generated',\N,\N),
('currency','installed_currencies','RUB,USD,EUR,UAH,BYN',\N,\N),
('fileman','use_editor_3','Y',\N,\N),
('forum','FILTER_DICT_W','1',\N,'ru'),
('forum','FILTER_DICT_T','2',\N,'ru'),
('forum','FILTER_DICT_W','3',\N,'en'),
('forum','FILTER_DICT_T','4',\N,'en'),
('forum','FILTER','N',\N,\N),
('sale','viewed_capability','N',\N,\N),
('sale','viewed_count','10',\N,\N),
('sale','viewed_time','5',\N,\N),
('main','~sale_converted_15','Y',\N,\N),
('main','~sale_paysystem_converted','Y',\N,\N),
('sale','expiration_processing_events','Y',\N,\N),
('sale','p2p_status_list','a:7:{i:0;s:1:\"N\";i:1;s:1:\"P\";i:2;s:1:\"F\";i:3;s:10:\"F_CANCELED\";i:4;s:10:\"F_DELIVERY\";i:5;s:5:\"F_PAY\";i:6;s:5:\"F_OUT\";}',\N,\N),
('sale','basket_discount_converted','Y',\N,\N),
('sale','product_reserve_clear_period','3',\N,\N),
('sale','sale_locationpro_import_performed','Y',\N,\N),
('sale','sale_locationpro_migrated','Y',\N,\N),
('sale','sale_locationpro_enabled','Y',\N,\N),
('search','version','v2.0',\N,\N),
('search','dbnode_id','N',\N,\N),
('search','dbnode_status','ok',\N,\N),
('security','ipcheck_disable_file','/bitrix/modules/ipcheck_disable_69c88a9497416621c51553e721c17787',\N,\N),
('security','redirect_sid','20prn2wrqen0aqzimc5gbss1ylfh0jdm',\N,\N),
('vote','VOTE_DIR','',\N,\N),
('vote','VOTE_COMPATIBLE_OLD_TEMPLATE','N',\N,\N),
('main','email_from','bolonikov@medialine.by',\N,\N),
('main','wizard_site_logo','',\N,\N),
('main','server_name','mgb',\N,\N),
('main','site_name','ОАО &quot;Минскжелезобетон&quot;',\N,\N),
('main','wizard_company_slogan','',\N,\N),
('socialnetwork','tooltip_rating_id','a:2:{i:0;i:3;i:1;i:4;}',\N,'WI'),
('socialnetwork','tooltip_show_rating','Y',\N,'WI'),
('forum','SHOW_VOTES','N',\N,\N),
('main','new_user_registration_def_group','5',\N,\N),
('main','show_panel_for_users','a:1:{i:0;s:2:\"G6\";}',\N,\N),
('main','upload_dir','upload',\N,\N),
('main','component_cache_on','Y',\N,\N),
('main','save_original_file_name','Y',\N,\N),
('main','captcha_registration','Y',\N,\N),
('main','use_secure_password_cookies','Y',\N,\N),
('main','new_user_registration','Y',\N,\N),
('main','auth_comp2','Y',\N,\N),
('main','update_autocheck','7',\N,\N),
('main','map_top_menu_type','top',\N,\N),
('main','map_left_menu_type','left',\N,\N),
('main','event_log_logout','Y',\N,\N),
('main','event_log_login_success','Y',\N,\N),
('main','event_log_login_fail','Y',\N,\N),
('main','event_log_register','Y',\N,\N),
('main','event_log_register_fail','Y',\N,\N),
('main','event_log_password_request','Y',\N,\N),
('main','event_log_password_change','Y',\N,\N),
('main','event_log_user_delete','Y',\N,\N),
('main','CAPTCHA_presets','2',\N,\N),
('main','CAPTCHA_transparentTextPercent','0',\N,\N),
('main','CAPTCHA_arBGColor_1','FFFFFF',\N,\N),
('main','CAPTCHA_arBGColor_2','FFFFFF',\N,\N),
('main','CAPTCHA_numEllipses','0',\N,\N),
('main','CAPTCHA_numLines','0',\N,\N),
('main','CAPTCHA_textStartX','40',\N,\N),
('main','CAPTCHA_textFontSize','26',\N,\N),
('main','CAPTCHA_arTextColor_1','000000',\N,\N),
('main','CAPTCHA_arTextColor_2','000000',\N,\N),
('main','CAPTCHA_textAngel_1','-15',\N,\N),
('main','CAPTCHA_textAngel_2','15',\N,\N),
('main','CAPTCHA_textDistance_1','-2',\N,\N),
('main','CAPTCHA_textDistance_2','-2',\N,\N),
('main','CAPTCHA_bWaveTransformation','N',\N,\N),
('main','CAPTCHA_arBorderColor','000000',\N,\N),
('main','CAPTCHA_arTTFFiles','bitrix_captcha.ttf',\N,\N),
('fileman','menutypes','a:2:{s:4:\\\"left\\\";s:23:\\\"Меню раздела\\\";s:3:\\\"top\\\";s:23:\\\"Главное меню\\\";}',\N,'s1'),
('fileman','menutypes','a:2:{s:4:\\\"left\\\";s:23:\\\"Меню раздела\\\";s:3:\\\"top\\\";s:23:\\\"Главное меню\\\";}',\N,\N),
('fileman','default_edit','html',\N,\N),
('fileman','propstypes','a:4:{s:11:\"description\";s:33:\"Описание страницы\";s:8:\"keywords\";s:27:\"Ключевые слова\";s:5:\"title\";s:44:\"Заголовок окна браузера\";s:14:\"keywords_inner\";s:35:\"Продвигаемые слова\";}',\N,\N),
('socialservices','auth_services','a:12:{s:9:\"VKontakte\";s:1:\"N\";s:8:\"MyMailRu\";s:1:\"N\";s:7:\"Twitter\";s:1:\"N\";s:8:\"Facebook\";s:1:\"N\";s:11:\"Livejournal\";s:1:\"Y\";s:12:\"YandexOpenID\";s:1:\"Y\";s:7:\"Rambler\";s:1:\"Y\";s:12:\"MailRuOpenID\";s:1:\"Y\";s:12:\"Liveinternet\";s:1:\"Y\";s:7:\"Blogger\";s:1:\"Y\";s:6:\"OpenID\";s:1:\"Y\";s:6:\"LiveID\";s:1:\"N\";}',\N,\N),
('search','use_word_distance','Y',\N,\N),
('search','use_social_rating','Y',\N,\N),
('search','use_stemming','Y',\N,\N),
('search','use_tf_cache','Y',\N,\N),
('search','exclude_mask','/bitrix/*;/404.php;/upload/*;/auth*;*/search*;*/tags*;/personal/*;/e-store/affiliates/*;/content/*/my/*;/examples/*;/map.php;*/detail.php;/communication/voting/*;/club/index.php',\N,\N),
('main','LAST_DB_OPTIMIZATION_TIME','1476767288',\N,\N),
('fileman','stickers_use_hotkeys','N',\N,\N)	;
#	TC`b_perf_cache`utf8_unicode_ci	;
CREATE TABLE `b_perf_cache` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `HIT_ID` int(18) DEFAULT NULL,
  `COMPONENT_ID` int(18) DEFAULT NULL,
  `NN` int(18) DEFAULT NULL,
  `CACHE_SIZE` float DEFAULT NULL,
  `OP_MODE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MODULE_NAME` text COLLATE utf8_unicode_ci,
  `COMPONENT_NAME` text COLLATE utf8_unicode_ci,
  `BASE_DIR` text COLLATE utf8_unicode_ci,
  `INIT_DIR` text COLLATE utf8_unicode_ci,
  `FILE_NAME` text COLLATE utf8_unicode_ci,
  `FILE_PATH` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_B_PERF_CACHE_0` (`HIT_ID`,`NN`),
  KEY `IX_B_PERF_CACHE_1` (`COMPONENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_perf_cluster`utf8_unicode_ci	;
CREATE TABLE `b_perf_cluster` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `THREADS` int(11) DEFAULT NULL,
  `HITS` int(11) DEFAULT NULL,
  `ERRORS` int(11) DEFAULT NULL,
  `PAGES_PER_SECOND` float DEFAULT NULL,
  `PAGE_EXEC_TIME` float DEFAULT NULL,
  `PAGE_RESP_TIME` float DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_perf_component`utf8_unicode_ci	;
CREATE TABLE `b_perf_component` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `HIT_ID` int(18) DEFAULT NULL,
  `NN` int(18) DEFAULT NULL,
  `CACHE_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CACHE_SIZE` int(11) DEFAULT NULL,
  `CACHE_COUNT_R` int(11) DEFAULT NULL,
  `CACHE_COUNT_W` int(11) DEFAULT NULL,
  `CACHE_COUNT_C` int(11) DEFAULT NULL,
  `COMPONENT_TIME` float DEFAULT NULL,
  `QUERIES` int(11) DEFAULT NULL,
  `QUERIES_TIME` float DEFAULT NULL,
  `COMPONENT_NAME` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_B_PERF_COMPONENT_0` (`HIT_ID`,`NN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_perf_error`utf8_unicode_ci	;
CREATE TABLE `b_perf_error` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `HIT_ID` int(18) DEFAULT NULL,
  `ERRNO` int(18) DEFAULT NULL,
  `ERRSTR` text COLLATE utf8_unicode_ci,
  `ERRFILE` text COLLATE utf8_unicode_ci,
  `ERRLINE` int(18) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_PERF_ERROR_0` (`HIT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_perf_history`utf8_unicode_ci	;
CREATE TABLE `b_perf_history` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `TOTAL_MARK` float DEFAULT NULL,
  `ACCELERATOR_ENABLED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_perf_hit`utf8_unicode_ci	;
CREATE TABLE `b_perf_hit` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DATE_HIT` datetime DEFAULT NULL,
  `IS_ADMIN` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REQUEST_METHOD` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SERVER_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SERVER_PORT` int(11) DEFAULT NULL,
  `SCRIPT_NAME` text COLLATE utf8_unicode_ci,
  `REQUEST_URI` text COLLATE utf8_unicode_ci,
  `INCLUDED_FILES` int(11) DEFAULT NULL,
  `MEMORY_PEAK_USAGE` int(11) DEFAULT NULL,
  `CACHE_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CACHE_SIZE` int(11) DEFAULT NULL,
  `CACHE_COUNT_R` int(11) DEFAULT NULL,
  `CACHE_COUNT_W` int(11) DEFAULT NULL,
  `CACHE_COUNT_C` int(11) DEFAULT NULL,
  `QUERIES` int(11) DEFAULT NULL,
  `QUERIES_TIME` float DEFAULT NULL,
  `COMPONENTS` int(11) DEFAULT NULL,
  `COMPONENTS_TIME` float DEFAULT NULL,
  `SQL_LOG` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PAGE_TIME` float DEFAULT NULL,
  `PROLOG_TIME` float DEFAULT NULL,
  `PROLOG_BEFORE_TIME` float DEFAULT NULL,
  `AGENTS_TIME` float DEFAULT NULL,
  `PROLOG_AFTER_TIME` float DEFAULT NULL,
  `WORK_AREA_TIME` float DEFAULT NULL,
  `EPILOG_TIME` float DEFAULT NULL,
  `EPILOG_BEFORE_TIME` float DEFAULT NULL,
  `EVENTS_TIME` float DEFAULT NULL,
  `EPILOG_AFTER_TIME` float DEFAULT NULL,
  `MENU_RECALC` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_PERF_HIT_0` (`DATE_HIT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_perf_index_ban`utf8_unicode_ci	;
CREATE TABLE `b_perf_index_ban` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BAN_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TABLE_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COLUMN_NAMES` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_perf_index_complete`utf8_unicode_ci	;
CREATE TABLE `b_perf_index_complete` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BANNED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TABLE_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COLUMN_NAMES` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `INDEX_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_perf_index_complete_0` (`TABLE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_perf_index_suggest`utf8_unicode_ci	;
CREATE TABLE `b_perf_index_suggest` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SQL_MD5` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SQL_COUNT` int(11) DEFAULT NULL,
  `SQL_TIME` float DEFAULT NULL,
  `TABLE_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TABLE_ALIAS` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COLUMN_NAMES` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SQL_TEXT` text COLLATE utf8_unicode_ci,
  `SQL_EXPLAIN` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `ix_b_perf_index_suggest_0` (`SQL_MD5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_perf_index_suggest_sql`utf8_unicode_ci	;
CREATE TABLE `b_perf_index_suggest_sql` (
  `SUGGEST_ID` int(11) NOT NULL DEFAULT '0',
  `SQL_ID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`SUGGEST_ID`,`SQL_ID`),
  KEY `ix_b_perf_index_suggest_sql_0` (`SQL_ID`,`SUGGEST_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_perf_sql`utf8_unicode_ci	;
CREATE TABLE `b_perf_sql` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `HIT_ID` int(18) DEFAULT NULL,
  `COMPONENT_ID` int(18) DEFAULT NULL,
  `NN` int(18) DEFAULT NULL,
  `QUERY_TIME` float DEFAULT NULL,
  `NODE_ID` int(18) DEFAULT NULL,
  `MODULE_NAME` text COLLATE utf8_unicode_ci,
  `COMPONENT_NAME` text COLLATE utf8_unicode_ci,
  `SQL_TEXT` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_B_PERF_SQL_0` (`HIT_ID`,`NN`),
  KEY `IX_B_PERF_SQL_1` (`COMPONENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_perf_sql_backtrace`utf8_unicode_ci	;
CREATE TABLE `b_perf_sql_backtrace` (
  `SQL_ID` int(18) NOT NULL DEFAULT '0',
  `NN` int(18) NOT NULL DEFAULT '0',
  `FILE_NAME` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINE_NO` int(18) DEFAULT NULL,
  `CLASS_NAME` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FUNCTION_NAME` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`SQL_ID`,`NN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_perf_tab_column_stat`utf8_unicode_ci	;
CREATE TABLE `b_perf_tab_column_stat` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TABLE_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COLUMN_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TABLE_ROWS` float DEFAULT NULL,
  `COLUMN_ROWS` float DEFAULT NULL,
  `VALUE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_perf_tab_column_stat` (`TABLE_NAME`,`COLUMN_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_perf_tab_stat`utf8_unicode_ci	;
CREATE TABLE `b_perf_tab_stat` (
  `TABLE_NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `TABLE_SIZE` float DEFAULT NULL,
  `TABLE_ROWS` float DEFAULT NULL,
  PRIMARY KEY (`TABLE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_perf_test`utf8_unicode_ci	;
CREATE TABLE `b_perf_test` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `REFERENCE_ID` int(18) DEFAULT NULL,
  `NAME` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_PERF_TEST_0` (`REFERENCE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_posting`utf8_unicode_ci	;
CREATE TABLE `b_posting` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `STATUS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'D',
  `VERSION` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_SENT` datetime DEFAULT NULL,
  `SENT_BCC` mediumtext COLLATE utf8_unicode_ci,
  `FROM_FIELD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TO_FIELD` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BCC_FIELD` mediumtext COLLATE utf8_unicode_ci,
  `EMAIL_FILTER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUBJECT` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `BODY_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `BODY` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `DIRECT_SEND` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CHARSET` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MSG_CHARSET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUBSCR_FORMAT` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ERROR_EMAIL` mediumtext COLLATE utf8_unicode_ci,
  `AUTO_SEND_TIME` datetime DEFAULT NULL,
  `BCC_TO_SEND` mediumtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_posting_email`utf8_unicode_ci	;
CREATE TABLE `b_posting_email` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `POSTING_ID` int(11) NOT NULL,
  `STATUS` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SUBSCRIPTION_ID` int(11) DEFAULT NULL,
  `USER_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_posting_email_status` (`POSTING_ID`,`STATUS`),
  KEY `ix_posting_email_email` (`POSTING_ID`,`EMAIL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_posting_file`utf8_unicode_ci	;
CREATE TABLE `b_posting_file` (
  `POSTING_ID` int(11) NOT NULL,
  `FILE_ID` int(11) NOT NULL,
  UNIQUE KEY `UK_POSTING_POSTING_FILE` (`POSTING_ID`,`FILE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_posting_group`utf8_unicode_ci	;
CREATE TABLE `b_posting_group` (
  `POSTING_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  UNIQUE KEY `UK_POSTING_POSTING_GROUP` (`POSTING_ID`,`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_posting_rubric`utf8_unicode_ci	;
CREATE TABLE `b_posting_rubric` (
  `POSTING_ID` int(11) NOT NULL,
  `LIST_RUBRIC_ID` int(11) NOT NULL,
  UNIQUE KEY `UK_POSTING_POSTING_RUBRIC` (`POSTING_ID`,`LIST_RUBRIC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_pull_channel`utf8_unicode_ci	;
CREATE TABLE `b_pull_channel` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(18) NOT NULL,
  `CHANNEL_TYPE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CHANNEL_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_ID` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_PULL_CN_UID` (`USER_ID`,`CHANNEL_TYPE`),
  KEY `IX_PULL_CN_CID` (`CHANNEL_ID`),
  KEY `IX_PULL_CN_D` (`DATE_CREATE`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_pull_channel`utf8_unicode_ci	;
INSERT INTO `b_pull_channel` VALUES 
(1,1,'private','3923c7ad2d2f1f1572961103ab6b0ce3',0,'2016-10-18 09:05:43')	;
#	TC`b_pull_push`utf8_unicode_ci	;
CREATE TABLE `b_pull_push` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(18) NOT NULL,
  `DEVICE_TYPE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `APP_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UNIQUE_HASH` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEVICE_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEVICE_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEVICE_TOKEN` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATE` datetime NOT NULL,
  `DATE_AUTH` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_PULL_PSH_UID` (`USER_ID`),
  KEY `IX_PULL_PSH_UH` (`UNIQUE_HASH`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_pull_push_queue`utf8_unicode_ci	;
CREATE TABLE `b_pull_push_queue` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(18) NOT NULL,
  `TAG` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUB_TAG` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MESSAGE` text COLLATE utf8_unicode_ci,
  `PARAMS` text COLLATE utf8_unicode_ci,
  `ADVANCED_PARAMS` text COLLATE utf8_unicode_ci,
  `BADGE` int(11) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `APP_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_PULL_PSHQ_UT` (`USER_ID`,`TAG`),
  KEY `IX_PULL_PSHQ_UST` (`USER_ID`,`SUB_TAG`),
  KEY `IX_PULL_PSHQ_UID` (`USER_ID`),
  KEY `IX_PULL_PSHQ_DC` (`DATE_CREATE`),
  KEY `IX_PULL_PSHQ_AID` (`APP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_pull_stack`utf8_unicode_ci	;
CREATE TABLE `b_pull_stack` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `CHANNEL_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE` text COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATE` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_PULL_STACK_CID` (`CHANNEL_ID`),
  KEY `IX_PULL_STACK_D` (`DATE_CREATE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_pull_watch`utf8_unicode_ci	;
CREATE TABLE `b_pull_watch` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(18) NOT NULL,
  `CHANNEL_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TAG` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATE` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_PULL_W_UT` (`USER_ID`,`TAG`),
  KEY `IX_PULL_W_D` (`DATE_CREATE`),
  KEY `IX_PULL_W_T` (`TAG`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_rating`utf8_unicode_ci	;
CREATE TABLE `b_rating` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CALCULATION_METHOD` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'SUM',
  `CREATED` datetime DEFAULT NULL,
  `LAST_MODIFIED` datetime DEFAULT NULL,
  `LAST_CALCULATED` datetime DEFAULT NULL,
  `POSITION` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `AUTHORITY` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `CALCULATED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CONFIGS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_rating`utf8_unicode_ci	;
INSERT INTO `b_rating` VALUES 
(3,'Y','Рейтинг','USER','SUM','2016-10-18 09:08:05','2016-10-18 09:08:05','2016-10-18 09:08:05','Y','N','Y','a:3:{s:4:\"MAIN\";a:1:{s:6:\"RATING\";a:1:{s:5:\"BONUS\";a:2:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";}}}s:5:\"FORUM\";a:2:{s:4:\"VOTE\";a:2:{s:5:\"TOPIC\";a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:3:\"0.5\";s:5:\"LIMIT\";s:2:\"30\";}s:4:\"POST\";a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:3:\"0.1\";s:5:\"LIMIT\";s:2:\"30\";}}s:6:\"RATING\";a:1:{s:8:\"ACTIVITY\";a:9:{s:6:\"ACTIVE\";s:1:\"Y\";s:16:\"TODAY_TOPIC_COEF\";s:3:\"0.4\";s:15:\"WEEK_TOPIC_COEF\";s:3:\"0.2\";s:16:\"MONTH_TOPIC_COEF\";s:3:\"0.1\";s:14:\"ALL_TOPIC_COEF\";s:1:\"0\";s:15:\"TODAY_POST_COEF\";s:3:\"0.2\";s:14:\"WEEK_POST_COEF\";s:3:\"0.1\";s:15:\"MONTH_POST_COEF\";s:4:\"0.05\";s:13:\"ALL_POST_COEF\";s:1:\"0\";}}}s:4:\"BLOG\";a:2:{s:4:\"VOTE\";a:2:{s:4:\"POST\";a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}s:7:\"COMMENT\";a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}}s:6:\"RATING\";a:1:{s:8:\"ACTIVITY\";a:9:{s:6:\"ACTIVE\";s:1:\"Y\";s:15:\"TODAY_POST_COEF\";s:3:\"0.4\";s:14:\"WEEK_POST_COEF\";s:3:\"0.2\";s:15:\"MONTH_POST_COEF\";s:3:\"0.1\";s:13:\"ALL_POST_COEF\";s:1:\"0\";s:18:\"TODAY_COMMENT_COEF\";s:3:\"0.2\";s:17:\"WEEK_COMMENT_COEF\";s:3:\"0.1\";s:18:\"MONTH_COMMENT_COEF\";s:4:\"0.05\";s:16:\"ALL_COMMENT_COEF\";s:1:\"0\";}}}}'),
(4,'Y','Авторитет','USER','SUM','2016-10-18 09:08:05','2016-10-18 09:08:05','2016-10-18 09:08:06','Y','Y','Y','a:3:{s:4:\"MAIN\";a:2:{s:4:\"VOTE\";a:1:{s:4:\"USER\";a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}}s:6:\"RATING\";a:1:{s:5:\"BONUS\";a:2:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";}}}s:5:\"FORUM\";N;s:4:\"BLOG\";N;}')	;
#	TC`b_rating_component`utf8_unicode_ci	;
CREATE TABLE `b_rating_component` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RATING_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ENTITY_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `RATING_TYPE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `COMPLEX_NAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `CLASS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CALC_METHOD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `EXCEPTION_METHOD` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_MODIFIED` datetime DEFAULT NULL,
  `LAST_CALCULATED` datetime DEFAULT NULL,
  `NEXT_CALCULATION` datetime DEFAULT NULL,
  `REFRESH_INTERVAL` int(11) NOT NULL,
  `CONFIG` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_RATING_ID_1` (`RATING_ID`,`ACTIVE`,`NEXT_CALCULATION`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_rating_component`utf8_unicode_ci	;
INSERT INTO `b_rating_component` VALUES 
(1,3,'Y','USER','MAIN','RATING','BONUS','USER_MAIN_RATING_BONUS','CRatingsComponentsMain','CalcUserBonus',\N,'2016-10-18 09:08:05','2016-10-18 09:08:05','2016-10-18 09:08:05',3600,'a:2:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";}'),
(2,3,'Y','USER','FORUM','VOTE','TOPIC','USER_FORUM_VOTE_TOPIC','CRatingsComponentsForum','CalcUserVoteForumTopic',\N,'2016-10-18 09:08:05','2016-10-18 09:08:05','2016-10-18 09:08:05',3600,'a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:3:\"0.5\";s:5:\"LIMIT\";s:2:\"30\";}'),
(3,3,'Y','USER','FORUM','VOTE','POST','USER_FORUM_VOTE_POST','CRatingsComponentsForum','CalcUserVoteForumPost',\N,'2016-10-18 09:08:05','2016-10-18 09:08:05','2016-10-18 09:08:05',3600,'a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:3:\"0.1\";s:5:\"LIMIT\";s:2:\"30\";}'),
(4,3,'Y','USER','FORUM','RATING','ACTIVITY','USER_FORUM_RATING_ACTIVITY','CRatingsComponentsForum','CalcUserRatingForumActivity','ExceptionUserRatingForumActivity','2016-10-18 09:08:05','2016-10-18 09:08:05','2016-10-18 10:08:05',7200,'a:9:{s:6:\"ACTIVE\";s:1:\"Y\";s:16:\"TODAY_TOPIC_COEF\";s:3:\"0.4\";s:15:\"WEEK_TOPIC_COEF\";s:3:\"0.2\";s:16:\"MONTH_TOPIC_COEF\";s:3:\"0.1\";s:14:\"ALL_TOPIC_COEF\";s:1:\"0\";s:15:\"TODAY_POST_COEF\";s:3:\"0.2\";s:14:\"WEEK_POST_COEF\";s:3:\"0.1\";s:15:\"MONTH_POST_COEF\";s:4:\"0.05\";s:13:\"ALL_POST_COEF\";s:1:\"0\";}'),
(5,3,'Y','USER','BLOG','VOTE','POST','USER_BLOG_VOTE_POST','CRatingsComponentsBlog','CalcPost',\N,'2016-10-18 09:08:05','2016-10-18 09:08:05','2016-10-18 09:08:05',3600,'a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}'),
(6,3,'Y','USER','BLOG','VOTE','COMMENT','USER_BLOG_VOTE_COMMENT','CRatingsComponentsBlog','CalcComment',\N,'2016-10-18 09:08:05','2016-10-18 09:08:05','2016-10-18 09:08:05',3600,'a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}'),
(7,3,'Y','USER','BLOG','RATING','ACTIVITY','USER_BLOG_RATING_ACTIVITY','CRatingsComponentsBlog','CalcActivity',\N,'2016-10-18 09:08:05','2016-10-18 09:08:05','2016-10-18 10:08:05',7200,'a:9:{s:6:\"ACTIVE\";s:1:\"Y\";s:15:\"TODAY_POST_COEF\";s:3:\"0.4\";s:14:\"WEEK_POST_COEF\";s:3:\"0.2\";s:15:\"MONTH_POST_COEF\";s:3:\"0.1\";s:13:\"ALL_POST_COEF\";s:1:\"0\";s:18:\"TODAY_COMMENT_COEF\";s:3:\"0.2\";s:17:\"WEEK_COMMENT_COEF\";s:3:\"0.1\";s:18:\"MONTH_COMMENT_COEF\";s:4:\"0.05\";s:16:\"ALL_COMMENT_COEF\";s:1:\"0\";}'),
(8,4,'Y','USER','MAIN','VOTE','USER','USER_MAIN_VOTE_USER','CRatingsComponentsMain','CalcVoteUser',\N,'2016-10-18 09:08:05','2016-10-18 09:08:05','2016-10-18 09:08:05',3600,'a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}'),
(9,4,'Y','USER','MAIN','RATING','BONUS','USER_MAIN_RATING_BONUS','CRatingsComponentsMain','CalcUserBonus',\N,'2016-10-18 09:08:05','2016-10-18 09:08:05','2016-10-18 09:08:05',3600,'a:2:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";}')	;
#	TC`b_rating_component_results`utf8_unicode_ci	;
CREATE TABLE `b_rating_component_results` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RATING_ID` int(11) NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `RATING_TYPE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `COMPLEX_NAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `CURRENT_VALUE` decimal(18,4) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_ENTITY_TYPE_ID` (`ENTITY_TYPE_ID`),
  KEY `IX_COMPLEX_NAME` (`COMPLEX_NAME`),
  KEY `IX_RATING_ID_2` (`RATING_ID`,`COMPLEX_NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_rating_component_results`utf8_unicode_ci	;
INSERT INTO `b_rating_component_results` VALUES 
(2,3,'USER',1,'MAIN','RATING','BONUS','USER_MAIN_RATING_BONUS',0.0000),
(3,4,'USER',1,'MAIN','RATING','BONUS','USER_MAIN_RATING_BONUS',3.0000)	;
#	TC`b_rating_prepare`utf8_unicode_ci	;
CREATE TABLE `b_rating_prepare` (
  `ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_rating_results`utf8_unicode_ci	;
CREATE TABLE `b_rating_results` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RATING_ID` int(11) NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `CURRENT_VALUE` decimal(18,4) DEFAULT NULL,
  `PREVIOUS_VALUE` decimal(18,4) DEFAULT NULL,
  `CURRENT_POSITION` int(11) DEFAULT '0',
  `PREVIOUS_POSITION` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `IX_RATING_3` (`RATING_ID`,`ENTITY_TYPE_ID`,`ENTITY_ID`),
  KEY `IX_RATING_4` (`RATING_ID`,`ENTITY_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_rating_results`utf8_unicode_ci	;
INSERT INTO `b_rating_results` VALUES 
(1,4,'USER',1,3.0000,30.0000,1,0),
(2,3,'USER',1,0.0000,0.0000,1,0)	;
#	TC`b_rating_rule`utf8_unicode_ci	;
CREATE TABLE `b_rating_rule` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `NAME` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION_NAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION_MODULE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONDITION_CLASS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION_METHOD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION_CONFIG` text COLLATE utf8_unicode_ci,
  `ACTION_NAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ACTION_CONFIG` text COLLATE utf8_unicode_ci,
  `ACTIVATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ACTIVATE_CLASS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVATE_METHOD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DEACTIVATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DEACTIVATE_CLASS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DEACTIVATE_METHOD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CREATED` datetime DEFAULT NULL,
  `LAST_MODIFIED` datetime DEFAULT NULL,
  `LAST_APPLIED` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_rating_rule`utf8_unicode_ci	;
INSERT INTO `b_rating_rule` VALUES 
(1,'N','Добавление в группу пользователей, имеющих право голосовать за рейтинг','USER','AUTHORITY',\N,'CRatingRulesMain','ratingCheck','a:1:{s:9:\"AUTHORITY\";a:2:{s:16:\"RATING_CONDITION\";i:1;s:12:\"RATING_VALUE\";i:1;}}','ADD_TO_GROUP','a:1:{s:12:\"ADD_TO_GROUP\";a:1:{s:8:\"GROUP_ID\";s:1:\"3\";}}','N','CRatingRulesMain','addToGroup','N','CRatingRulesMain ','addToGroup','2016-10-18 08:58:51','2016-10-18 08:58:51',\N),
(2,'N','Удаление из группы пользователей, не имеющих права голосовать за рейтинг','USER','AUTHORITY',\N,'CRatingRulesMain','ratingCheck','a:1:{s:9:\"AUTHORITY\";a:2:{s:16:\"RATING_CONDITION\";i:2;s:12:\"RATING_VALUE\";i:1;}}','REMOVE_FROM_GROUP','a:1:{s:17:\"REMOVE_FROM_GROUP\";a:1:{s:8:\"GROUP_ID\";s:1:\"3\";}}','N','CRatingRulesMain','removeFromGroup','N','CRatingRulesMain ','removeFromGroup','2016-10-18 08:58:51','2016-10-18 08:58:51',\N),
(3,'N','Добавление в группу пользователей, имеющих право голосовать за авторитет','USER','AUTHORITY',\N,'CRatingRulesMain','ratingCheck','a:1:{s:9:\"AUTHORITY\";a:2:{s:16:\"RATING_CONDITION\";i:1;s:12:\"RATING_VALUE\";i:2;}}','ADD_TO_GROUP','a:1:{s:12:\"ADD_TO_GROUP\";a:1:{s:8:\"GROUP_ID\";s:1:\"4\";}}','N','CRatingRulesMain','addToGroup','N','CRatingRulesMain ','addToGroup','2016-10-18 08:58:51','2016-10-18 08:58:51',\N),
(4,'N','Удаление из группы пользователей, не имеющих права голосовать за авторитет','USER','AUTHORITY',\N,'CRatingRulesMain','ratingCheck','a:1:{s:9:\"AUTHORITY\";a:2:{s:16:\"RATING_CONDITION\";i:2;s:12:\"RATING_VALUE\";i:2;}}','REMOVE_FROM_GROUP','a:1:{s:17:\"REMOVE_FROM_GROUP\";a:1:{s:8:\"GROUP_ID\";s:1:\"4\";}}','N','CRatingRulesMain','removeFromGroup','N','CRatingRulesMain ','removeFromGroup','2016-10-18 08:58:51','2016-10-18 08:58:51',\N),
(5,'Y','Автоматическое голосование за авторитет пользователя','USER','VOTE',\N,'CRatingRulesMain','voteCheck','a:1:{s:4:\"VOTE\";a:6:{s:10:\"VOTE_LIMIT\";i:90;s:11:\"VOTE_RESULT\";i:10;s:16:\"VOTE_FORUM_TOPIC\";d:0.5;s:15:\"VOTE_FORUM_POST\";d:0.10000000000000001;s:14:\"VOTE_BLOG_POST\";d:0.5;s:17:\"VOTE_BLOG_COMMENT\";d:0.10000000000000001;}}','empty','a:0:{}','N','empty','empty','N','empty ','empty','2016-10-18 08:58:51','2016-10-18 08:58:51',\N)	;
#	TC`b_rating_rule_vetting`utf8_unicode_ci	;
CREATE TABLE `b_rating_rule_vetting` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RULE_ID` int(11) NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `ACTIVATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `APPLIED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `RULE_ID` (`RULE_ID`,`ENTITY_TYPE_ID`,`ENTITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_rating_user`utf8_unicode_ci	;
CREATE TABLE `b_rating_user` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RATING_ID` int(11) NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `BONUS` decimal(18,4) DEFAULT '0.0000',
  `VOTE_WEIGHT` decimal(18,4) DEFAULT '0.0000',
  `VOTE_COUNT` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `RATING_ID` (`RATING_ID`,`ENTITY_ID`),
  KEY `IX_B_RAT_USER_2` (`ENTITY_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_rating_user`utf8_unicode_ci	;
INSERT INTO `b_rating_user` VALUES 
(2,4,1,3.0000,3.0000,13),
(3,3,1,0.0000,0.0000,0)	;
#	TC`b_rating_vote`utf8_unicode_ci	;
CREATE TABLE `b_rating_vote` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RATING_VOTING_ID` int(11) NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `VALUE` decimal(18,4) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `CREATED` datetime NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `USER_IP` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_RAT_VOTE_ID` (`RATING_VOTING_ID`,`USER_ID`),
  KEY `IX_RAT_VOTE_ID_2` (`ENTITY_TYPE_ID`,`ENTITY_ID`,`USER_ID`),
  KEY `IX_RAT_VOTE_ID_3` (`OWNER_ID`,`CREATED`),
  KEY `IX_RAT_VOTE_ID_4` (`USER_ID`),
  KEY `IX_RAT_VOTE_ID_5` (`CREATED`,`VALUE`),
  KEY `IX_RAT_VOTE_ID_6` (`ACTIVE`),
  KEY `IX_RAT_VOTE_ID_7` (`RATING_VOTING_ID`,`CREATED`),
  KEY `IX_RAT_VOTE_ID_8` (`ENTITY_TYPE_ID`,`CREATED`),
  KEY `IX_RAT_VOTE_ID_9` (`CREATED`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_rating_vote_group`utf8_unicode_ci	;
CREATE TABLE `b_rating_vote_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GROUP_ID` int(11) NOT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `RATING_ID` (`GROUP_ID`,`TYPE`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_rating_vote_group`utf8_unicode_ci	;
INSERT INTO `b_rating_vote_group` VALUES 
(5,1,'A'),
(1,1,'R'),
(3,1,'R'),
(2,3,'R'),
(4,3,'R'),
(6,4,'A')	;
#	TC`b_rating_voting`utf8_unicode_ci	;
CREATE TABLE `b_rating_voting` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `CREATED` datetime DEFAULT NULL,
  `LAST_CALCULATED` datetime DEFAULT NULL,
  `TOTAL_VALUE` decimal(18,4) NOT NULL,
  `TOTAL_VOTES` int(11) NOT NULL,
  `TOTAL_POSITIVE_VOTES` int(11) NOT NULL,
  `TOTAL_NEGATIVE_VOTES` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_ENTITY_TYPE_ID_2` (`ENTITY_TYPE_ID`,`ENTITY_ID`,`ACTIVE`),
  KEY `IX_ENTITY_TYPE_ID_4` (`TOTAL_VALUE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_rating_voting_prepare`utf8_unicode_ci	;
CREATE TABLE `b_rating_voting_prepare` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RATING_VOTING_ID` int(11) NOT NULL,
  `TOTAL_VALUE` decimal(18,4) NOT NULL,
  `TOTAL_VOTES` int(11) NOT NULL,
  `TOTAL_POSITIVE_VOTES` int(11) NOT NULL,
  `TOTAL_NEGATIVE_VOTES` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_RATING_VOTING_ID` (`RATING_VOTING_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_rating_weight`utf8_unicode_ci	;
CREATE TABLE `b_rating_weight` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RATING_FROM` decimal(18,4) NOT NULL,
  `RATING_TO` decimal(18,4) NOT NULL,
  `WEIGHT` decimal(18,4) DEFAULT '0.0000',
  `COUNT` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_rating_weight`utf8_unicode_ci	;
INSERT INTO `b_rating_weight` VALUES 
(1,-1000000.0000,1000000.0000,1.0000,10)	;
#	TC`b_sale_affiliate`utf8_unicode_ci	;
CREATE TABLE `b_sale_affiliate` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `AFFILIATE_ID` int(11) DEFAULT NULL,
  `PLAN_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DATE_CREATE` datetime NOT NULL,
  `PAID_SUM` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `APPROVED_SUM` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `PENDING_SUM` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `ITEMS_NUMBER` int(11) NOT NULL DEFAULT '0',
  `ITEMS_SUM` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `LAST_CALCULATE` datetime DEFAULT NULL,
  `AFF_SITE` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AFF_DESCRIPTION` text COLLATE utf8_unicode_ci,
  `FIX_PLAN` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_SAA_USER_ID` (`USER_ID`,`SITE_ID`),
  KEY `IX_SAA_AFFILIATE_ID` (`AFFILIATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_affiliate_plan`utf8_unicode_ci	;
CREATE TABLE `b_sale_affiliate_plan` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `BASE_RATE` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `BASE_RATE_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'P',
  `BASE_RATE_CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MIN_PAY` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `MIN_PLAN_VALUE` decimal(18,4) DEFAULT NULL,
  `VALUE_CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_affiliate_plan_section`utf8_unicode_ci	;
CREATE TABLE `b_sale_affiliate_plan_section` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PLAN_ID` int(11) NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'catalog',
  `SECTION_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `RATE` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `RATE_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'P',
  `RATE_CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_SAP_PLAN_ID` (`PLAN_ID`,`MODULE_ID`,`SECTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_affiliate_tier`utf8_unicode_ci	;
CREATE TABLE `b_sale_affiliate_tier` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `RATE1` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `RATE2` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `RATE3` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `RATE4` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `RATE5` decimal(18,4) NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_SAT_SITE_ID` (`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_affiliate_transact`utf8_unicode_ci	;
CREATE TABLE `b_sale_affiliate_transact` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AFFILIATE_ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `TRANSACT_DATE` datetime NOT NULL,
  `AMOUNT` decimal(18,4) NOT NULL,
  `CURRENCY` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `DEBIT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DESCRIPTION` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `EMPLOYEE_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_SAT_AFFILIATE_ID` (`AFFILIATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_auxiliary`utf8_unicode_ci	;
CREATE TABLE `b_sale_auxiliary` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ITEM` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ITEM_MD5` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `DATE_INSERT` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_STT_USER_ITEM` (`USER_ID`,`ITEM_MD5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_basket`utf8_unicode_ci	;
CREATE TABLE `b_sale_basket` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FUSER_ID` int(11) NOT NULL,
  `ORDER_ID` int(11) DEFAULT NULL,
  `PRODUCT_ID` int(11) NOT NULL,
  `PRODUCT_PRICE_ID` int(11) DEFAULT NULL,
  `PRICE` decimal(18,4) NOT NULL,
  `CURRENCY` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `BASE_PRICE` decimal(18,4) DEFAULT NULL,
  `VAT_INCLUDED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `DATE_INSERT` datetime NOT NULL,
  `DATE_UPDATE` datetime NOT NULL,
  `WEIGHT` double(18,2) DEFAULT NULL,
  `QUANTITY` double(18,4) NOT NULL DEFAULT '0.0000',
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `DELAY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CAN_BUY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `MODULE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CALLBACK_FUNC` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NOTES` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ORDER_CALLBACK_FUNC` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DETAIL_PAGE_URL` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DISCOUNT_PRICE` decimal(18,4) NOT NULL,
  `CANCEL_CALLBACK_FUNC` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PAY_CALLBACK_FUNC` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRODUCT_PROVIDER_CLASS` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CATALOG_XML_ID` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRODUCT_XML_ID` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DISCOUNT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DISCOUNT_VALUE` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DISCOUNT_COUPON` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VAT_RATE` decimal(18,4) DEFAULT '0.0000',
  `SUBSCRIBE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DEDUCTED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `RESERVED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `BARCODE_MULTI` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `RESERVE_QUANTITY` double DEFAULT NULL,
  `CUSTOM_PRICE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DIMENSIONS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TYPE` int(11) DEFAULT NULL,
  `SET_PARENT_ID` int(11) DEFAULT NULL,
  `MEASURE_CODE` int(11) DEFAULT NULL,
  `MEASURE_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RECOMMENDATION` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  PRIMARY KEY (`ID`),
  KEY `IXS_BASKET_LID` (`LID`),
  KEY `IXS_BASKET_USER_ID` (`FUSER_ID`),
  KEY `IXS_BASKET_ORDER_ID` (`ORDER_ID`),
  KEY `IXS_BASKET_PRODUCT_ID` (`PRODUCT_ID`),
  KEY `IXS_BASKET_PRODUCT_PRICE_ID` (`PRODUCT_PRICE_ID`),
  KEY `IXS_SBAS_XML_ID` (`PRODUCT_XML_ID`,`CATALOG_XML_ID`),
  KEY `IXS_BASKET_DATE_INSERT` (`DATE_INSERT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_basket_props`utf8_unicode_ci	;
CREATE TABLE `b_sale_basket_props` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BASKET_ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  PRIMARY KEY (`ID`),
  KEY `IXS_BASKET_PROPS_BASKET` (`BASKET_ID`),
  KEY `IXS_BASKET_PROPS_CODE` (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_bizval`utf8_unicode_ci	;
CREATE TABLE `b_sale_bizval` (
  `CODE_KEY` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CONSUMER_KEY` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `PERSON_TYPE_ID` int(11) NOT NULL,
  `PROVIDER_KEY` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `PROVIDER_VALUE` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`CODE_KEY`,`CONSUMER_KEY`,`PERSON_TYPE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_bizval_code_1C`utf8_unicode_ci	;
CREATE TABLE `b_sale_bizval_code_1C` (
  `PERSON_TYPE_ID` int(11) NOT NULL,
  `CODE_INDEX` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`PERSON_TYPE_ID`,`CODE_INDEX`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_bizval_persondomain`utf8_unicode_ci	;
CREATE TABLE `b_sale_bizval_persondomain` (
  `PERSON_TYPE_ID` int(11) NOT NULL,
  `DOMAIN` char(1) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`PERSON_TYPE_ID`,`DOMAIN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_company`utf8_unicode_ci	;
CREATE TABLE `b_sale_company` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `LOCATION_ID` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) DEFAULT '100',
  `XML_ID` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `DATE_CREATE` datetime DEFAULT NULL,
  `DATE_MODIFY` datetime DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `MODIFIED_BY` int(11) DEFAULT NULL,
  `ADDRESS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_company2location`utf8_unicode_ci	;
CREATE TABLE `b_sale_company2location` (
  `COMPANY_ID` int(11) NOT NULL,
  `LOCATION_CODE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `LOCATION_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'L',
  PRIMARY KEY (`COMPANY_ID`,`LOCATION_CODE`,`LOCATION_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_company2service`utf8_unicode_ci	;
CREATE TABLE `b_sale_company2service` (
  `COMPANY_ID` int(11) NOT NULL,
  `SERVICE_ID` int(11) NOT NULL,
  `SERVICE_TYPE` int(11) NOT NULL,
  PRIMARY KEY (`COMPANY_ID`,`SERVICE_ID`,`SERVICE_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_delivery2location`utf8_unicode_ci	;
CREATE TABLE `b_sale_delivery2location` (
  `DELIVERY_ID` int(11) NOT NULL,
  `LOCATION_CODE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `LOCATION_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'L',
  PRIMARY KEY (`DELIVERY_ID`,`LOCATION_CODE`,`LOCATION_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_delivery2paysystem`utf8_unicode_ci	;
CREATE TABLE `b_sale_delivery2paysystem` (
  `DELIVERY_ID` int(11) NOT NULL,
  `LINK_DIRECTION` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `PAYSYSTEM_ID` int(11) NOT NULL,
  KEY `IX_DELIVERY` (`DELIVERY_ID`),
  KEY `IX_PAYSYSTEM` (`PAYSYSTEM_ID`),
  KEY `LINK_DIRECTION` (`LINK_DIRECTION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_delivery_es`utf8_unicode_ci	;
CREATE TABLE `b_sale_delivery_es` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CLASS_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci,
  `RIGHTS` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `DELIVERY_ID` int(11) NOT NULL,
  `INIT_VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) DEFAULT '100',
  PRIMARY KEY (`ID`),
  KEY `IX_BSD_ES_DELIVERY_ID` (`DELIVERY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_delivery_srv`utf8_unicode_ci	;
CREATE TABLE `b_sale_delivery_srv` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PARENT_ID` int(11) DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `SORT` int(11) NOT NULL,
  `LOGOTIP` int(11) DEFAULT NULL,
  `CONFIG` longtext COLLATE utf8_unicode_ci,
  `CLASS_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CURRENCY` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `TRACKING_PARAMS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ALLOW_EDIT_SHIPMENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `IX_BSD_SRV_CODE` (`CODE`),
  KEY `IX_BSD_SRV_PARENT_ID` (`PARENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_discount`utf8_unicode_ci	;
CREATE TABLE `b_sale_discount` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRICE_FROM` decimal(18,2) DEFAULT NULL,
  `PRICE_TO` decimal(18,2) DEFAULT NULL,
  `CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DISCOUNT_VALUE` decimal(18,2) NOT NULL,
  `DISCOUNT_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'P',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '100',
  `ACTIVE_FROM` datetime DEFAULT NULL,
  `ACTIVE_TO` datetime DEFAULT NULL,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `PRIORITY` int(18) NOT NULL DEFAULT '1',
  `LAST_DISCOUNT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `VERSION` int(11) NOT NULL DEFAULT '1',
  `CONDITIONS` mediumtext COLLATE utf8_unicode_ci,
  `UNPACK` mediumtext COLLATE utf8_unicode_ci,
  `ACTIONS` mediumtext COLLATE utf8_unicode_ci,
  `APPLICATION` mediumtext COLLATE utf8_unicode_ci,
  `USE_COUPONS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `EXECUTE_MODULE` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'all',
  PRIMARY KEY (`ID`),
  KEY `IXS_DISCOUNT_LID` (`LID`),
  KEY `IX_SSD_ACTIVE_DATE` (`ACTIVE_FROM`,`ACTIVE_TO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_discount_coupon`utf8_unicode_ci	;
CREATE TABLE `b_sale_discount_coupon` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ACTIVE_FROM` datetime DEFAULT NULL,
  `ACTIVE_TO` datetime DEFAULT NULL,
  `COUPON` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `TYPE` int(11) NOT NULL DEFAULT '0',
  `MAX_USE` int(11) NOT NULL DEFAULT '0',
  `USE_COUNT` int(11) NOT NULL DEFAULT '0',
  `USER_ID` int(11) NOT NULL DEFAULT '0',
  `DATE_APPLY` datetime DEFAULT NULL,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_discount_entities`utf8_unicode_ci	;
CREATE TABLE `b_sale_discount_entities` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `FIELD_ENTITY` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `FIELD_TABLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_SALE_DSC_ENT_DISCOUNT_ID` (`DISCOUNT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_discount_group`utf8_unicode_ci	;
CREATE TABLE `b_sale_discount_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GROUP_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_S_DISGRP` (`DISCOUNT_ID`,`GROUP_ID`),
  UNIQUE KEY `IX_S_DISGRP_G` (`GROUP_ID`,`DISCOUNT_ID`),
  KEY `IX_S_DISGRP_D` (`DISCOUNT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_discount_module`utf8_unicode_ci	;
CREATE TABLE `b_sale_discount_module` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_SALE_DSC_MOD` (`DISCOUNT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_export`utf8_unicode_ci	;
CREATE TABLE `b_sale_export` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PERSON_TYPE_ID` int(11) NOT NULL,
  `VARS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_fuser`utf8_unicode_ci	;
CREATE TABLE `b_sale_fuser` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DATE_INSERT` datetime NOT NULL,
  `DATE_UPDATE` datetime NOT NULL,
  `USER_ID` int(11) DEFAULT NULL,
  `CODE` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_USER_ID` (`USER_ID`),
  KEY `IX_CODE` (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_gift_related_data`utf8_unicode_ci	;
CREATE TABLE `b_sale_gift_related_data` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DISCOUNT_ID` int(11) NOT NULL,
  `ELEMENT_ID` int(11) DEFAULT NULL,
  `SECTION_ID` int(11) DEFAULT NULL,
  `MAIN_PRODUCT_SECTION_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_S_GRD_O_1` (`DISCOUNT_ID`),
  KEY `IX_S_GRD_O_2` (`MAIN_PRODUCT_SECTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_hdaln`utf8_unicode_ci	;
CREATE TABLE `b_sale_hdaln` (
  `LOCATION_ID` int(11) NOT NULL,
  `LEFT_MARGIN` int(11) NOT NULL,
  `RIGHT_MARGIN` int(11) NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`LOCATION_ID`),
  KEY `IX_BSHDALN_NAME` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_lang`utf8_unicode_ci	;
CREATE TABLE `b_sale_lang` (
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `CURRENCY` char(3) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_loc_2site`utf8_unicode_ci	;
CREATE TABLE `b_sale_loc_2site` (
  `LOCATION_ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `LOCATION_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'L',
  PRIMARY KEY (`SITE_ID`,`LOCATION_ID`,`LOCATION_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_loc_def2site`utf8_unicode_ci	;
CREATE TABLE `b_sale_loc_def2site` (
  `LOCATION_CODE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) DEFAULT '100',
  PRIMARY KEY (`LOCATION_CODE`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_loc_ext`utf8_unicode_ci	;
CREATE TABLE `b_sale_loc_ext` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SERVICE_ID` int(11) NOT NULL,
  `LOCATION_ID` int(11) NOT NULL,
  `XML_ID` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_SALE_LOC_EXT_LID_SID` (`LOCATION_ID`,`SERVICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_loc_ext_srv`utf8_unicode_ci	;
CREATE TABLE `b_sale_loc_ext_srv` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CODE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_loc_name`utf8_unicode_ci	;
CREATE TABLE `b_sale_loc_name` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `LOCATION_ID` int(11) NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `NAME_UPPER` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `SHORT_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_SALE_L_NAME_NAME_UPPER` (`NAME_UPPER`),
  KEY `IX_SALE_L_NAME_LID_LID` (`LOCATION_ID`,`LANGUAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_loc_type`utf8_unicode_ci	;
CREATE TABLE `b_sale_loc_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CODE` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) DEFAULT '100',
  `DISPLAY_SORT` int(11) DEFAULT '100',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_loc_type_name`utf8_unicode_ci	;
CREATE TABLE `b_sale_loc_type_name` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `TYPE_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_SALE_L_TYPE_NAME_TID_LID` (`TYPE_ID`,`LANGUAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_location`utf8_unicode_ci	;
CREATE TABLE `b_sale_location` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `CODE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `LEFT_MARGIN` int(11) DEFAULT NULL,
  `RIGHT_MARGIN` int(11) DEFAULT NULL,
  `PARENT_ID` int(11) DEFAULT '0',
  `DEPTH_LEVEL` int(11) DEFAULT '1',
  `TYPE_ID` int(11) DEFAULT NULL,
  `LATITUDE` decimal(8,6) DEFAULT NULL,
  `LONGITUDE` decimal(9,6) DEFAULT NULL,
  `COUNTRY_ID` int(11) DEFAULT NULL,
  `REGION_ID` int(11) DEFAULT NULL,
  `CITY_ID` int(11) DEFAULT NULL,
  `LOC_DEFAULT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_SALE_LOCATION_CODE` (`CODE`),
  KEY `IX_SALE_LOCATION_MARGINS` (`LEFT_MARGIN`,`RIGHT_MARGIN`),
  KEY `IX_SALE_LOCATION_MARGINS_REV` (`RIGHT_MARGIN`,`LEFT_MARGIN`),
  KEY `IX_SALE_LOCATION_PARENT` (`PARENT_ID`),
  KEY `IX_SALE_LOCATION_DL` (`DEPTH_LEVEL`),
  KEY `IX_SALE_LOCATION_TYPE` (`TYPE_ID`),
  KEY `IXS_LOCATION_COUNTRY_ID` (`COUNTRY_ID`),
  KEY `IXS_LOCATION_REGION_ID` (`REGION_ID`),
  KEY `IXS_LOCATION_CITY_ID` (`CITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_location2location_group`utf8_unicode_ci	;
CREATE TABLE `b_sale_location2location_group` (
  `LOCATION_ID` int(11) NOT NULL,
  `LOCATION_GROUP_ID` int(11) NOT NULL,
  PRIMARY KEY (`LOCATION_ID`,`LOCATION_GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_location_city`utf8_unicode_ci	;
CREATE TABLE `b_sale_location_city` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `SHORT_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REGION_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IXS_LOCAT_REGION_ID` (`REGION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_location_city_lang`utf8_unicode_ci	;
CREATE TABLE `b_sale_location_city_lang` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CITY_ID` int(11) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `SHORT_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IXS_LOCAT_CITY_LID` (`CITY_ID`,`LID`),
  KEY `IX_NAME` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_location_country`utf8_unicode_ci	;
CREATE TABLE `b_sale_location_country` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `SHORT_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_NAME` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_location_country_lang`utf8_unicode_ci	;
CREATE TABLE `b_sale_location_country_lang` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `COUNTRY_ID` int(11) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `SHORT_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IXS_LOCAT_CNTR_LID` (`COUNTRY_ID`,`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_location_group`utf8_unicode_ci	;
CREATE TABLE `b_sale_location_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CODE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_SALE_LOCATION_GROUP_CODE` (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_location_group_lang`utf8_unicode_ci	;
CREATE TABLE `b_sale_location_group_lang` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LOCATION_GROUP_ID` int(11) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_LOCATION_GROUP_LID` (`LOCATION_GROUP_ID`,`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_location_region`utf8_unicode_ci	;
CREATE TABLE `b_sale_location_region` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SHORT_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_location_region_lang`utf8_unicode_ci	;
CREATE TABLE `b_sale_location_region_lang` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `REGION_ID` int(11) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `SHORT_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IXS_LOCAT_REGION_LID` (`REGION_ID`,`LID`),
  KEY `IXS_NAME` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_location_zip`utf8_unicode_ci	;
CREATE TABLE `b_sale_location_zip` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LOCATION_ID` int(11) NOT NULL DEFAULT '0',
  `ZIP` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `IX_LOCATION_ID` (`LOCATION_ID`),
  KEY `IX_ZIP` (`ZIP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order`utf8_unicode_ci	;
CREATE TABLE `b_sale_order` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `PERSON_TYPE_ID` int(11) NOT NULL,
  `PAYED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DATE_PAYED` datetime DEFAULT NULL,
  `EMP_PAYED_ID` int(11) DEFAULT NULL,
  `CANCELED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DATE_CANCELED` datetime DEFAULT NULL,
  `EMP_CANCELED_ID` int(11) DEFAULT NULL,
  `REASON_CANCELED` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STATUS_ID` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_STATUS` datetime NOT NULL,
  `EMP_STATUS_ID` int(11) DEFAULT NULL,
  `PRICE_DELIVERY` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `PRICE_PAYMENT` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `ALLOW_DELIVERY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DATE_ALLOW_DELIVERY` datetime DEFAULT NULL,
  `EMP_ALLOW_DELIVERY_ID` int(11) DEFAULT NULL,
  `DEDUCTED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DATE_DEDUCTED` datetime DEFAULT NULL,
  `EMP_DEDUCTED_ID` int(11) DEFAULT NULL,
  `REASON_UNDO_DEDUCTED` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MARKED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DATE_MARKED` datetime DEFAULT NULL,
  `EMP_MARKED_ID` int(11) DEFAULT NULL,
  `REASON_MARKED` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RESERVED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `PRICE` decimal(18,4) NOT NULL,
  `CURRENCY` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `DISCOUNT_VALUE` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `USER_ID` int(11) NOT NULL,
  `PAY_SYSTEM_ID` int(11) DEFAULT NULL,
  `DELIVERY_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_INSERT` datetime NOT NULL,
  `DATE_UPDATE` datetime NOT NULL,
  `USER_DESCRIPTION` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ADDITIONAL_INFO` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_STATUS` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_STATUS_CODE` char(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_STATUS_DESCRIPTION` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_STATUS_MESSAGE` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_SUM` decimal(18,2) DEFAULT NULL,
  `PS_CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_RESPONSE_DATE` datetime DEFAULT NULL,
  `COMMENTS` text COLLATE utf8_unicode_ci,
  `TAX_VALUE` decimal(18,2) NOT NULL DEFAULT '0.00',
  `STAT_GID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUM_PAID` decimal(18,2) NOT NULL DEFAULT '0.00',
  `RECURRING_ID` int(11) DEFAULT NULL,
  `PAY_VOUCHER_NUM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PAY_VOUCHER_DATE` date DEFAULT NULL,
  `LOCKED_BY` int(11) DEFAULT NULL,
  `DATE_LOCK` datetime DEFAULT NULL,
  `RECOUNT_FLAG` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `AFFILIATE_ID` int(11) DEFAULT NULL,
  `DELIVERY_DOC_NUM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DELIVERY_DOC_DATE` date DEFAULT NULL,
  `UPDATED_1C` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `STORE_ID` int(11) DEFAULT NULL,
  `ORDER_TOPIC` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `RESPONSIBLE_ID` int(11) DEFAULT NULL,
  `DATE_PAY_BEFORE` datetime DEFAULT NULL,
  `DATE_BILL` datetime DEFAULT NULL,
  `ACCOUNT_NUMBER` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TRACKING_NUMBER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ID_1C` varchar(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION_1C` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION` int(11) NOT NULL DEFAULT '0',
  `EXTERNAL_ORDER` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `BX_USER_ID` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IXS_ACCOUNT_NUMBER` (`ACCOUNT_NUMBER`),
  KEY `IXS_ORDER_USER_ID` (`USER_ID`),
  KEY `IXS_ORDER_PERSON_TYPE_ID` (`PERSON_TYPE_ID`),
  KEY `IXS_ORDER_STATUS_ID` (`STATUS_ID`),
  KEY `IXS_ORDER_REC_ID` (`RECURRING_ID`),
  KEY `IX_SOO_AFFILIATE_ID` (`AFFILIATE_ID`),
  KEY `IXS_ORDER_UPDATED_1C` (`UPDATED_1C`),
  KEY `IXS_SALE_COUNT` (`USER_ID`,`LID`,`PAYED`,`CANCELED`),
  KEY `IXS_DATE_UPDATE` (`DATE_UPDATE`),
  KEY `IXS_XML_ID` (`XML_ID`),
  KEY `IXS_ID_1C` (`ID_1C`),
  KEY `IX_BSO_DATE_ALLOW_DELIVERY` (`DATE_ALLOW_DELIVERY`),
  KEY `IX_BSO_ALLOW_DELIVERY` (`ALLOW_DELIVERY`),
  KEY `IX_BSO_DATE_CANCELED` (`DATE_CANCELED`),
  KEY `IX_BSO_CANCELED` (`CANCELED`),
  KEY `IX_BSO_DATE_PAYED` (`DATE_PAYED`),
  KEY `IX_BSO_DATE_INSERT` (`DATE_INSERT`),
  KEY `IX_BSO_DATE_PAY_BEFORE` (`DATE_PAY_BEFORE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_change`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_change` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORDER_ID` int(11) NOT NULL,
  `TYPE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DATA` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_CREATE` datetime NOT NULL,
  `DATE_MODIFY` datetime NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `ENTITY` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ENTITY_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IXS_ORDER_ID_CHANGE` (`ORDER_ID`),
  KEY `IXS_TYPE_CHANGE` (`TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_coupons`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_coupons` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORDER_ID` int(11) NOT NULL,
  `ORDER_DISCOUNT_ID` int(11) NOT NULL,
  `COUPON` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `TYPE` int(11) NOT NULL,
  `COUPON_ID` int(11) NOT NULL,
  `DATA` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_SALE_ORDER_CPN_ORDER` (`ORDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_delivery`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_delivery` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORDER_ID` int(11) NOT NULL,
  `ACCOUNT_NUMBER` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_INSERT` datetime NOT NULL,
  `DATE_REQUEST` datetime DEFAULT NULL,
  `DATE_UPDATE` datetime DEFAULT NULL,
  `DELIVERY_LOCATION` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci,
  `STATUS_ID` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `PRICE_DELIVERY` decimal(18,4) DEFAULT NULL,
  `DISCOUNT_PRICE` decimal(18,4) DEFAULT NULL,
  `BASE_PRICE_DELIVERY` decimal(18,4) DEFAULT NULL,
  `CUSTOM_PRICE_DELIVERY` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ALLOW_DELIVERY` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `DATE_ALLOW_DELIVERY` datetime DEFAULT NULL,
  `EMP_ALLOW_DELIVERY_ID` int(11) DEFAULT NULL,
  `DEDUCTED` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `DATE_DEDUCTED` datetime DEFAULT NULL,
  `EMP_DEDUCTED_ID` int(11) DEFAULT NULL,
  `REASON_UNDO_DEDUCTED` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RESERVED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DELIVERY_ID` int(11) NOT NULL,
  `DELIVERY_DOC_NUM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DELIVERY_DOC_DATE` datetime DEFAULT NULL,
  `TRACKING_NUMBER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DELIVERY_NAME` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CANCELED` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `DATE_CANCELED` datetime DEFAULT NULL,
  `EMP_CANCELED_ID` int(11) DEFAULT NULL,
  `REASON_CANCELED` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `MARKED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_MARKED` datetime DEFAULT NULL,
  `EMP_MARKED_ID` int(11) DEFAULT NULL,
  `REASON_MARKED` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CURRENCY` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SYSTEM` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `RESPONSIBLE_ID` int(11) DEFAULT NULL,
  `EMP_RESPONSIBLE_ID` int(11) DEFAULT NULL,
  `DATE_RESPONSIBLE_ID` datetime DEFAULT NULL,
  `COMMENTS` text COLLATE utf8_unicode_ci,
  `COMPANY_ID` int(11) DEFAULT NULL,
  `TRACKING_STATUS` int(11) DEFAULT NULL,
  `TRACKING_DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TRACKING_LAST_CHECK` datetime DEFAULT NULL,
  `TRACKING_LAST_CHANGE` datetime DEFAULT NULL,
  `ID_1C` varchar(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION_1C` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EXTERNAL_DELIVERY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `UPDATED_1C` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IXS_DLV_ACCOUNT_NUMBER` (`ACCOUNT_NUMBER`),
  KEY `IX_BSOD_ORDER_ID` (`ORDER_ID`),
  KEY `IX_BSOD_DATE_ALLOW_DELIVERY` (`DATE_ALLOW_DELIVERY`),
  KEY `IX_BSOD_ALLOW_DELIVERY` (`ALLOW_DELIVERY`),
  KEY `IX_BSOD_DATE_CANCELED` (`DATE_CANCELED`),
  KEY `IX_BSOD_CANCELED` (`CANCELED`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_delivery_es`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_delivery_es` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SHIPMENT_ID` int(11) NOT NULL,
  `EXTRA_SERVICE_ID` int(11) NOT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_BSOD_ES_SHIPMENT_ID` (`SHIPMENT_ID`),
  KEY `IX_BSOD_ES_EXTRA_SERVICE_ID` (`EXTRA_SERVICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_delivery_req`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_delivery_req` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORDER_ID` int(11) NOT NULL,
  `DATE_REQUEST` datetime DEFAULT NULL,
  `DELIVERY_LOCATION` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci,
  `SHIPMENT_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_ORDER_ID` (`ORDER_ID`),
  KEY `IX_SHIPMENT_ID` (`SHIPMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_discount`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_discount` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DISCOUNT_ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DISCOUNT_HASH` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITIONS` mediumtext COLLATE utf8_unicode_ci,
  `UNPACK` mediumtext COLLATE utf8_unicode_ci,
  `ACTIONS` mediumtext COLLATE utf8_unicode_ci,
  `APPLICATION` mediumtext COLLATE utf8_unicode_ci,
  `USE_COUPONS` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL,
  `PRIORITY` int(11) NOT NULL,
  `LAST_DISCOUNT` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIONS_DESCR` mediumtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_SALE_ORDER_DSC_HASH` (`DISCOUNT_HASH`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_discount_data`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_discount_data` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORDER_ID` int(11) NOT NULL,
  `ENTITY_TYPE` int(11) NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `ENTITY_VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ENTITY_DATA` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_SALE_DSC_DATA_CMX` (`ORDER_ID`,`ENTITY_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_dlv_basket`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_dlv_basket` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORDER_DELIVERY_ID` int(11) NOT NULL,
  `BASKET_ID` int(11) NOT NULL,
  `DATE_INSERT` datetime NOT NULL,
  `QUANTITY` decimal(18,4) NOT NULL,
  `RESERVED_QUANTITY` decimal(18,4) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_BSODB_ORDER_DELIVERY_ID` (`ORDER_DELIVERY_ID`),
  KEY `IX_S_O_DB_BASKET_ID` (`BASKET_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_flags2group`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_flags2group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GROUP_ID` int(11) NOT NULL,
  `ORDER_FLAG` char(1) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ix_sale_ordfla2group` (`GROUP_ID`,`ORDER_FLAG`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_history`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_history` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `H_USER_ID` int(11) unsigned NOT NULL,
  `H_DATE_INSERT` datetime NOT NULL,
  `H_ORDER_ID` int(11) unsigned NOT NULL,
  `H_CURRENCY` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `PERSON_TYPE_ID` int(11) unsigned DEFAULT NULL,
  `PAYED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_PAYED` datetime DEFAULT NULL,
  `EMP_PAYED_ID` int(11) unsigned DEFAULT NULL,
  `CANCELED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_CANCELED` datetime DEFAULT NULL,
  `REASON_CANCELED` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STATUS_ID` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_STATUS` datetime DEFAULT NULL,
  `PRICE_DELIVERY` decimal(18,2) DEFAULT NULL,
  `ALLOW_DELIVERY` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_ALLOW_DELIVERY` datetime DEFAULT NULL,
  `RESERVED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEDUCTED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_DEDUCTED` datetime DEFAULT NULL,
  `REASON_UNDO_DEDUCTED` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MARKED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_MARKED` datetime DEFAULT NULL,
  `REASON_MARKED` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRICE` decimal(18,2) DEFAULT NULL,
  `CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DISCOUNT_VALUE` decimal(18,2) DEFAULT NULL,
  `USER_ID` int(11) unsigned DEFAULT NULL,
  `PAY_SYSTEM_ID` int(11) unsigned DEFAULT NULL,
  `DELIVERY_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_STATUS` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_STATUS_CODE` char(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_STATUS_DESCRIPTION` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_STATUS_MESSAGE` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_SUM` decimal(18,2) DEFAULT NULL,
  `PS_CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_RESPONSE_DATE` datetime DEFAULT NULL,
  `TAX_VALUE` decimal(18,2) DEFAULT NULL,
  `STAT_GID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUM_PAID` decimal(18,2) DEFAULT NULL,
  `PAY_VOUCHER_NUM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PAY_VOUCHER_DATE` date DEFAULT NULL,
  `AFFILIATE_ID` int(11) unsigned DEFAULT NULL,
  `DELIVERY_DOC_NUM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DELIVERY_DOC_DATE` date DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ixH_ORDER_ID` (`H_ORDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_modules`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_modules` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORDER_DISCOUNT_ID` int(11) NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_SALE_ORDER_MDL_DSC` (`ORDER_DISCOUNT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_payment`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_payment` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORDER_ID` int(11) NOT NULL,
  `ACCOUNT_NUMBER` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PAID` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DATE_PAID` datetime DEFAULT NULL,
  `EMP_PAID_ID` int(11) DEFAULT NULL,
  `PAY_SYSTEM_ID` int(11) NOT NULL,
  `PS_STATUS` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_INVOICE_ID` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_STATUS_CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_STATUS_DESCRIPTION` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_STATUS_MESSAGE` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_SUM` decimal(18,4) DEFAULT NULL,
  `PS_CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PS_RESPONSE_DATE` datetime DEFAULT NULL,
  `PAY_VOUCHER_NUM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PAY_VOUCHER_DATE` date DEFAULT NULL,
  `DATE_PAY_BEFORE` datetime DEFAULT NULL,
  `DATE_BILL` datetime DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUM` decimal(18,4) NOT NULL,
  `PRICE_COD` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `CURRENCY` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `PAY_SYSTEM_NAME` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `RESPONSIBLE_ID` int(11) DEFAULT NULL,
  `DATE_RESPONSIBLE_ID` datetime DEFAULT NULL,
  `EMP_RESPONSIBLE_ID` int(11) DEFAULT NULL,
  `COMMENTS` text COLLATE utf8_unicode_ci,
  `COMPANY_ID` int(11) DEFAULT NULL,
  `PAY_RETURN_DATE` date DEFAULT NULL,
  `EMP_RETURN_ID` int(11) DEFAULT NULL,
  `PAY_RETURN_NUM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PAY_RETURN_COMMENT` text COLLATE utf8_unicode_ci,
  `IS_RETURN` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ID_1C` varchar(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION_1C` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EXTERNAL_PAYMENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `UPDATED_1C` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IXS_PAY_ACCOUNT_NUMBER` (`ACCOUNT_NUMBER`),
  KEY `IX_BSOP_ORDER_ID` (`ORDER_ID`),
  KEY `IX_BSOP_DATE_PAID` (`DATE_PAID`),
  KEY `IX_BSOP_PAID` (`PAID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_payment_es`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_payment_es` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PAYMENT_ID` int(11) NOT NULL,
  `EXTRA_SERVICE_ID` int(11) NOT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_BSOP_ES_PAYMENT_ID` (`PAYMENT_ID`),
  KEY `IX_BSOP_ES_EXTRA_SERVICE_ID` (`EXTRA_SERVICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_processing`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_processing` (
  `ORDER_ID` int(11) DEFAULT '0',
  `PRODUCTS_ADDED` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `PRODUCTS_REMOVED` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  KEY `IX_ORDER_ID` (`ORDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_props`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_props` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PERSON_TYPE_ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TYPE` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `REQUIRED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DEFAULT_VALUE` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `USER_PROPS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IS_LOCATION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `PROPS_GROUP_ID` int(11) NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_EMAIL` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IS_PROFILE_NAME` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IS_PAYER` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IS_LOCATION4TAX` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IS_FILTERED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_ZIP` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IS_PHONE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ACTIVE` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `UTIL` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `INPUT_FIELD_LOCATION` int(11) NOT NULL DEFAULT '0',
  `MULTIPLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IS_ADDRESS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SETTINGS` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IXS_ORDER_PROPS_PERSON_TYPE_ID` (`PERSON_TYPE_ID`),
  KEY `IXS_CODE_OPP` (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_props_group`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_props_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PERSON_TYPE_ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  PRIMARY KEY (`ID`),
  KEY `IXS_ORDER_PROPS_GROUP_PERSON_TYPE_ID` (`PERSON_TYPE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_props_relation`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_props_relation` (
  `PROPERTY_ID` int(11) NOT NULL,
  `ENTITY_ID` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`PROPERTY_ID`,`ENTITY_ID`,`ENTITY_TYPE`),
  KEY `IX_PROPERTY` (`PROPERTY_ID`),
  KEY `IX_ENTITY_ID` (`ENTITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_props_value`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_props_value` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORDER_ID` int(11) NOT NULL,
  `ORDER_PROPS_ID` int(11) DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_SOPV_ORD_PROP_UNI` (`ORDER_ID`,`ORDER_PROPS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_props_variant`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_props_variant` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORDER_PROPS_ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IXS_ORDER_PROPS_VARIANT_ORDER_PROPS_ID` (`ORDER_PROPS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_rules`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_rules` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ORDER_DISCOUNT_ID` int(11) NOT NULL,
  `ORDER_ID` int(11) NOT NULL,
  `ENTITY_TYPE` int(11) NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `ENTITY_VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COUPON_ID` int(11) NOT NULL,
  `APPLY` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `ACTION_BLOCK_LIST` text COLLATE utf8_unicode_ci,
  `APPLY_BLOCK_COUNTER` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `IX_SALE_ORDER_RULES_ORD` (`ORDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_rules_descr`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_rules_descr` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ORDER_DISCOUNT_ID` int(11) NOT NULL,
  `ORDER_ID` int(11) NOT NULL,
  `RULE_ID` int(11) NOT NULL,
  `DESCR` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_SALE_ORDER_RULES_DS_ORD` (`ORDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_order_tax`utf8_unicode_ci	;
CREATE TABLE `b_sale_order_tax` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORDER_ID` int(11) NOT NULL,
  `TAX_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` decimal(18,4) DEFAULT NULL,
  `VALUE_MONEY` decimal(18,4) NOT NULL,
  `APPLY_ORDER` int(11) NOT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_PERCENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `IS_IN_PRICE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `ixs_sot_order_id` (`ORDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_pay_system_action`utf8_unicode_ci	;
CREATE TABLE `b_sale_pay_system_action` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PAY_SYSTEM_ID` int(11) DEFAULT NULL,
  `PERSON_TYPE_ID` int(11) DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PSA_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `DESCRIPTION` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTION_FILE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RESULT_FILE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NEW_WINDOW` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `PS_MODE` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci,
  `TARIF` text COLLATE utf8_unicode_ci,
  `HAVE_PAYMENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `HAVE_ACTION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `AUTO_CHANGE_1C` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `HAVE_RESULT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `HAVE_PRICE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `HAVE_PREPAY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `HAVE_RESULT_RECEIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ALLOW_EDIT_PAYMENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ENCODING` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOGOTIP` int(11) DEFAULT NULL,
  `IS_CASH` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_pay_system_err_log`utf8_unicode_ci	;
CREATE TABLE `b_sale_pay_system_err_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MESSAGE` text COLLATE utf8_unicode_ci NOT NULL,
  `ACTION` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_INSERT` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_pay_system_es`utf8_unicode_ci	;
CREATE TABLE `b_sale_pay_system_es` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CLASS_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci,
  `SHOW_MODE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PAY_SYSTEM_ID` int(11) NOT NULL,
  `DEFAULT_VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) DEFAULT '100',
  PRIMARY KEY (`ID`),
  KEY `IX_BSPS_ES_PAY_SYSTEM_ID` (`PAY_SYSTEM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_person_type`utf8_unicode_ci	;
CREATE TABLE `b_sale_person_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL DEFAULT '150',
  `ACTIVE` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `IXS_PERSON_TYPE_LID` (`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_person_type_site`utf8_unicode_ci	;
CREATE TABLE `b_sale_person_type_site` (
  `PERSON_TYPE_ID` int(18) NOT NULL DEFAULT '0',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`PERSON_TYPE_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_product2product`utf8_unicode_ci	;
CREATE TABLE `b_sale_product2product` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PRODUCT_ID` int(11) NOT NULL,
  `PARENT_PRODUCT_ID` int(11) NOT NULL,
  `CNT` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IXS_PRODUCT2PRODUCT_PRODUCT_ID` (`PRODUCT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_recurring`utf8_unicode_ci	;
CREATE TABLE `b_sale_recurring` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MODULE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRODUCT_ID` int(11) DEFAULT NULL,
  `PRODUCT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRODUCT_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRODUCT_PRICE_ID` int(11) DEFAULT NULL,
  `PRICE_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'R',
  `RECUR_SCHEME_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'M',
  `RECUR_SCHEME_LENGTH` int(11) NOT NULL DEFAULT '0',
  `WITHOUT_ORDER` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `PRICE` decimal(10,0) NOT NULL DEFAULT '0',
  `CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CANCELED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DATE_CANCELED` datetime DEFAULT NULL,
  `PRIOR_DATE` datetime DEFAULT NULL,
  `NEXT_DATE` datetime NOT NULL,
  `CALLBACK_FUNC` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRODUCT_PROVIDER_CLASS` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CANCELED_REASON` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ORDER_ID` int(11) NOT NULL,
  `REMAINING_ATTEMPTS` int(11) NOT NULL DEFAULT '0',
  `SUCCESS_PAYMENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `IX_S_R_USER_ID` (`USER_ID`),
  KEY `IX_S_R_NEXT_DATE` (`NEXT_DATE`,`CANCELED`,`REMAINING_ATTEMPTS`),
  KEY `IX_S_R_PRODUCT_ID` (`MODULE`,`PRODUCT_ID`,`PRODUCT_PRICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_service_rstr`utf8_unicode_ci	;
CREATE TABLE `b_sale_service_rstr` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SERVICE_ID` int(11) NOT NULL,
  `SERVICE_TYPE` int(11) NOT NULL,
  `SORT` int(11) DEFAULT '100',
  `CLASS_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_BSSR_SERVICE_ID` (`SERVICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_site2group`utf8_unicode_ci	;
CREATE TABLE `b_sale_site2group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GROUP_ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ix_sale_site2group` (`GROUP_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_status`utf8_unicode_ci	;
CREATE TABLE `b_sale_status` (
  `ID` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'O',
  `SORT` int(11) NOT NULL DEFAULT '100',
  `NOTIFY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_sale_status`utf8_unicode_ci	;
INSERT INTO `b_sale_status` VALUES 
('DF','D',400,'Y'),
('DN','D',300,'Y'),
('F','O',200,'Y'),
('N','O',100,'Y')	;
#	TC`b_sale_status_group_task`utf8_unicode_ci	;
CREATE TABLE `b_sale_status_group_task` (
  `STATUS_ID` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `GROUP_ID` int(18) NOT NULL,
  `TASK_ID` int(18) NOT NULL,
  PRIMARY KEY (`STATUS_ID`,`GROUP_ID`,`TASK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_status_lang`utf8_unicode_ci	;
CREATE TABLE `b_sale_status_lang` (
  `STATUS_ID` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`STATUS_ID`,`LID`),
  UNIQUE KEY `ixs_status_lang_status_id` (`STATUS_ID`,`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_sale_status_lang`utf8_unicode_ci	;
INSERT INTO `b_sale_status_lang` VALUES 
('DF','en','Отгружен','Отгружен'),
('DF','ru','Отгружен','Отгружен'),
('DN','en','Ожидает обработки','Ожидает обработки'),
('DN','ru','Ожидает обработки','Ожидает обработки'),
('F','en','Выполнен','Заказ доставлен и оплачен'),
('F','ru','Выполнен','Заказ доставлен и оплачен'),
('N','en','Принят, ожидается оплата','Заказ принят, но пока не обрабатывается (например, заказ только что создан или ожидается оплата заказа)'),
('N','ru','Принят, ожидается оплата','Заказ принят, но пока не обрабатывается (например, заказ только что создан или ожидается оплата заказа)')	;
#	TC`b_sale_store_barcode`utf8_unicode_ci	;
CREATE TABLE `b_sale_store_barcode` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BASKET_ID` int(11) NOT NULL,
  `BARCODE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STORE_ID` int(11) DEFAULT NULL,
  `QUANTITY` double NOT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `DATE_MODIFY` datetime DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `MODIFIED_BY` int(11) DEFAULT NULL,
  `ORDER_DELIVERY_BASKET_ID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `IX_BSSB_O_DLV_BASKET_ID` (`ORDER_DELIVERY_BASKET_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_tax`utf8_unicode_ci	;
CREATE TABLE `b_sale_tax` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIMESTAMP_X` datetime NOT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `itax_lid` (`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_tax2location`utf8_unicode_ci	;
CREATE TABLE `b_sale_tax2location` (
  `TAX_RATE_ID` int(11) NOT NULL,
  `LOCATION_CODE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `LOCATION_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'L',
  PRIMARY KEY (`TAX_RATE_ID`,`LOCATION_CODE`,`LOCATION_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_tax_exempt2group`utf8_unicode_ci	;
CREATE TABLE `b_sale_tax_exempt2group` (
  `GROUP_ID` int(11) NOT NULL,
  `TAX_ID` int(11) NOT NULL,
  PRIMARY KEY (`GROUP_ID`,`TAX_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_tax_rate`utf8_unicode_ci	;
CREATE TABLE `b_sale_tax_rate` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TAX_ID` int(11) NOT NULL,
  `PERSON_TYPE_ID` int(11) DEFAULT NULL,
  `VALUE` decimal(18,4) NOT NULL,
  `CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_PERCENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `IS_IN_PRICE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `APPLY_ORDER` int(11) NOT NULL DEFAULT '100',
  `TIMESTAMP_X` datetime NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `itax_pers_type` (`PERSON_TYPE_ID`),
  KEY `itax_lid` (`TAX_ID`),
  KEY `itax_inprice` (`IS_IN_PRICE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_tp`utf8_unicode_ci	;
CREATE TABLE `b_sale_tp` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CODE` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `SETTINGS` text COLLATE utf8_unicode_ci,
  `CATALOG_SECTION_TAB_CLASS_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CLASS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_CODE` (`CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_sale_tp`utf8_unicode_ci	;
INSERT INTO `b_sale_tp` VALUES 
(1,'ymarket','N','Покупки на Яндекс-Маркете','Интеграция магазина с программой Яндекса \"Покупка на Маркете\"','s:0:\"\";',\N,\N)	;
#	TC`b_sale_tp_ebay_cat`utf8_unicode_ci	;
CREATE TABLE `b_sale_tp_ebay_cat` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CATEGORY_ID` int(11) NOT NULL,
  `PARENT_ID` int(11) NOT NULL,
  `LEVEL` int(11) NOT NULL,
  `CONDITION_ID_VALUES` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION_ID_DEFINITION_URL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ITEM_SPECIFIC_ENABLED` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `VARIATIONS_ENABLED` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `PRODUCT_CREATION_ENABLED` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_UPDATE` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_tp_ebay_cat_var`utf8_unicode_ci	;
CREATE TABLE `b_sale_tp_ebay_cat_var` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CATEGORY_ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `REQUIRED` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `MIN_VALUES` int(11) NOT NULL,
  `MAX_VALUES` int(11) NOT NULL,
  `SELECTION_MODE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ALLOWED_AS_VARIATION` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `DEPENDENCY_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DEPENDENCY_VALUE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `HELP_URL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_tp_ebay_fq`utf8_unicode_ci	;
CREATE TABLE `b_sale_tp_ebay_fq` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FEED_TYPE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DATA` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_tp_ebay_fr`utf8_unicode_ci	;
CREATE TABLE `b_sale_tp_ebay_fr` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FILENAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `FEED_TYPE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `UPLOAD_TIME` datetime NOT NULL,
  `PROCESSING_REQUEST_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PROCESSING_RESULT` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RESULTS` text COLLATE utf8_unicode_ci,
  `IS_SUCCESS` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_tp_map`utf8_unicode_ci	;
CREATE TABLE `b_sale_tp_map` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ENTITY_ID` int(11) NOT NULL,
  `VALUE_EXTERNAL` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE_INTERNAL` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_BSTPM_E_V_V` (`ENTITY_ID`,`VALUE_EXTERNAL`,`VALUE_INTERNAL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_tp_map_entity`utf8_unicode_ci	;
CREATE TABLE `b_sale_tp_map_entity` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TRADING_PLATFORM_ID` int(11) NOT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_CODE_TRADING_PLATFORM_ID` (`TRADING_PLATFORM_ID`,`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_tp_order`utf8_unicode_ci	;
CREATE TABLE `b_sale_tp_order` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORDER_ID` int(11) NOT NULL,
  `TRADING_PLATFORM_ID` int(11) NOT NULL,
  `EXTERNAL_ORDER_ID` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_UNIQ_NUMBERS` (`ORDER_ID`,`TRADING_PLATFORM_ID`,`EXTERNAL_ORDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_user_account`utf8_unicode_ci	;
CREATE TABLE `b_sale_user_account` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CURRENT_BUDGET` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `CURRENCY` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `LOCKED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DATE_LOCKED` datetime DEFAULT NULL,
  `NOTES` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_S_U_USER_ID` (`USER_ID`,`CURRENCY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_user_cards`utf8_unicode_ci	;
CREATE TABLE `b_sale_user_cards` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '100',
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `PAY_SYSTEM_ACTION_ID` int(11) NOT NULL,
  `CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CARD_TYPE` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `CARD_NUM` text COLLATE utf8_unicode_ci NOT NULL,
  `CARD_CODE` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CARD_EXP_MONTH` int(11) NOT NULL,
  `CARD_EXP_YEAR` int(11) NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUM_MIN` decimal(18,4) DEFAULT NULL,
  `SUM_MAX` decimal(18,4) DEFAULT NULL,
  `SUM_CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_STATUS` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_STATUS_CODE` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_STATUS_DESCRIPTION` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_STATUS_MESSAGE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_SUM` decimal(18,4) DEFAULT NULL,
  `LAST_CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_S_U_C_USER_ID` (`USER_ID`,`ACTIVE`,`CURRENCY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_user_props`utf8_unicode_ci	;
CREATE TABLE `b_sale_user_props` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `PERSON_TYPE_ID` int(11) NOT NULL,
  `DATE_UPDATE` datetime NOT NULL,
  `XML_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION_1C` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IXS_USER_PROPS_USER_ID` (`USER_ID`),
  KEY `IXS_USER_PROPS_PERSON_TYPE_ID` (`PERSON_TYPE_ID`),
  KEY `IXS_USER_PROPS_XML_ID` (`XML_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_user_props_value`utf8_unicode_ci	;
CREATE TABLE `b_sale_user_props_value` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_PROPS_ID` int(11) NOT NULL,
  `ORDER_PROPS_ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IXS_USER_PROPS_VALUE_USER_PROPS_ID` (`USER_PROPS_ID`),
  KEY `IXS_USER_PROPS_VALUE_ORDER_PROPS_ID` (`ORDER_PROPS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_user_transact`utf8_unicode_ci	;
CREATE TABLE `b_sale_user_transact` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `TRANSACT_DATE` datetime NOT NULL,
  `AMOUNT` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `CURRENCY` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `DEBIT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ORDER_ID` int(11) DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `NOTES` text COLLATE utf8_unicode_ci,
  `PAYMENT_ID` int(11) DEFAULT NULL,
  `EMPLOYEE_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_S_U_T_USER_ID` (`USER_ID`),
  KEY `IX_S_U_T_USER_ID_CURRENCY` (`USER_ID`,`CURRENCY`),
  KEY `IX_S_U_T_ORDER_ID` (`ORDER_ID`),
  KEY `IX_S_U_T_PAYMENT_ID` (`PAYMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_viewed_product`utf8_unicode_ci	;
CREATE TABLE `b_sale_viewed_product` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `FUSER_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `DATE_VISIT` datetime NOT NULL,
  `PRODUCT_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `MODULE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DETAIL_PAGE_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRICE` decimal(18,2) NOT NULL DEFAULT '0.00',
  `NOTES` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREVIEW_PICTURE` int(11) DEFAULT NULL,
  `DETAIL_PICTURE` int(11) DEFAULT NULL,
  `CALLBACK_FUNC` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRODUCT_PROVIDER_CLASS` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ixLID` (`FUSER_ID`,`LID`),
  KEY `ixPRODUCT_ID` (`PRODUCT_ID`),
  KEY `ixDATE_VISIT` (`DATE_VISIT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sale_yandex_settings`utf8_unicode_ci	;
CREATE TABLE `b_sale_yandex_settings` (
  `SHOP_ID` int(11) NOT NULL,
  `CSR` text COLLATE utf8_unicode_ci,
  `SIGN` text COLLATE utf8_unicode_ci,
  `CERT` text COLLATE utf8_unicode_ci,
  `PKEY` text COLLATE utf8_unicode_ci,
  `PUB_KEY` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`SHOP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_search_content`utf8_unicode_ci	;
CREATE TABLE `b_search_content` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DATE_CHANGE` datetime NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ITEM_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CUSTOM_RANK` int(11) NOT NULL DEFAULT '0',
  `USER_ID` int(11) DEFAULT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ENTITY_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL` text COLLATE utf8_unicode_ci,
  `TITLE` text COLLATE utf8_unicode_ci,
  `BODY` longtext COLLATE utf8_unicode_ci,
  `TAGS` text COLLATE utf8_unicode_ci,
  `PARAM1` text COLLATE utf8_unicode_ci,
  `PARAM2` text COLLATE utf8_unicode_ci,
  `UPD` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_FROM` datetime DEFAULT NULL,
  `DATE_TO` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_B_SEARCH_CONTENT` (`MODULE_ID`,`ITEM_ID`),
  KEY `IX_B_SEARCH_CONTENT_1` (`MODULE_ID`,`PARAM1`(50),`PARAM2`(50)),
  KEY `IX_B_SEARCH_CONTENT_2` (`ENTITY_ID`(50),`ENTITY_TYPE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_search_content_freq`utf8_unicode_ci	;
CREATE TABLE `b_search_content_freq` (
  `STEM` int(11) NOT NULL DEFAULT '0',
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FREQ` float DEFAULT NULL,
  `TF` float DEFAULT NULL,
  UNIQUE KEY `UX_B_SEARCH_CONTENT_FREQ` (`STEM`,`LANGUAGE_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_search_content_param`utf8_unicode_ci	;
CREATE TABLE `b_search_content_param` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `PARAM_NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `PARAM_VALUE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  KEY `IX_B_SEARCH_CONTENT_PARAM` (`SEARCH_CONTENT_ID`,`PARAM_NAME`),
  KEY `IX_B_SEARCH_CONTENT_PARAM_1` (`PARAM_NAME`,`PARAM_VALUE`(50),`SEARCH_CONTENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_search_content_right`utf8_unicode_ci	;
CREATE TABLE `b_search_content_right` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `GROUP_CODE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `UX_B_SEARCH_CONTENT_RIGHT` (`SEARCH_CONTENT_ID`,`GROUP_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_search_content_site`utf8_unicode_ci	;
CREATE TABLE `b_search_content_site` (
  `SEARCH_CONTENT_ID` int(18) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `URL` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`SEARCH_CONTENT_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_search_content_stem`utf8_unicode_ci	;
CREATE TABLE `b_search_content_stem` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `STEM` int(11) NOT NULL,
  `TF` float NOT NULL,
  `PS` float NOT NULL,
  UNIQUE KEY `UX_B_SEARCH_CONTENT_STEM` (`STEM`,`LANGUAGE_ID`,`TF`,`PS`,`SEARCH_CONTENT_ID`),
  KEY `IND_B_SEARCH_CONTENT_STEM` (`SEARCH_CONTENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci DELAY_KEY_WRITE=1	;
#	TC`b_search_content_text`utf8_unicode_ci	;
CREATE TABLE `b_search_content_text` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `SEARCH_CONTENT_MD5` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `SEARCHABLE_CONTENT` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`SEARCH_CONTENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_search_content_title`utf8_unicode_ci	;
CREATE TABLE `b_search_content_title` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `POS` int(11) NOT NULL,
  `WORD` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `UX_B_SEARCH_CONTENT_TITLE` (`SITE_ID`,`WORD`,`SEARCH_CONTENT_ID`,`POS`),
  KEY `IND_B_SEARCH_CONTENT_TITLE` (`SEARCH_CONTENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci DELAY_KEY_WRITE=1	;
#	TC`b_search_custom_rank`utf8_unicode_ci	;
CREATE TABLE `b_search_custom_rank` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `APPLIED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `RANK` int(11) NOT NULL DEFAULT '0',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE_ID` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `PARAM1` text COLLATE utf8_unicode_ci,
  `PARAM2` text COLLATE utf8_unicode_ci,
  `ITEM_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IND_B_SEARCH_CUSTOM_RANK` (`SITE_ID`,`MODULE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_search_phrase`utf8_unicode_ci	;
CREATE TABLE `b_search_phrase` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` datetime NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `RESULT_COUNT` int(11) NOT NULL,
  `PAGES` int(11) NOT NULL,
  `SESSION_ID` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `PHRASE` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAGS` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL_TO` text COLLATE utf8_unicode_ci,
  `URL_TO_404` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL_TO_SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STAT_SESS_ID` int(18) DEFAULT NULL,
  `EVENT1` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IND_PK_B_SEARCH_PHRASE_SESS_PH` (`SESSION_ID`,`PHRASE`(50)),
  KEY `IND_PK_B_SEARCH_PHRASE_SESS_TG` (`SESSION_ID`,`TAGS`(50)),
  KEY `IND_PK_B_SEARCH_PHRASE_TIME` (`TIMESTAMP_X`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_search_stem`utf8_unicode_ci	;
CREATE TABLE `b_search_stem` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `STEM` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_B_SEARCH_STEM` (`STEM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_search_suggest`utf8_unicode_ci	;
CREATE TABLE `b_search_suggest` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `FILTER_MD5` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `PHRASE` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `RATE` float NOT NULL,
  `TIMESTAMP_X` datetime NOT NULL,
  `RESULT_COUNT` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IND_B_SEARCH_SUGGEST` (`FILTER_MD5`,`PHRASE`(50),`RATE`),
  KEY `IND_B_SEARCH_SUGGEST_PHRASE` (`PHRASE`(50),`RATE`),
  KEY `IND_B_SEARCH_SUGGEST_TIME` (`TIMESTAMP_X`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_search_tags`utf8_unicode_ci	;
CREATE TABLE `b_search_tags` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`SEARCH_CONTENT_ID`,`SITE_ID`,`NAME`),
  KEY `IX_B_SEARCH_TAGS_0` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci DELAY_KEY_WRITE=1	;
#	TC`b_search_user_right`utf8_unicode_ci	;
CREATE TABLE `b_search_user_right` (
  `USER_ID` int(11) NOT NULL,
  `GROUP_CODE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `UX_B_SEARCH_USER_RIGHT` (`USER_ID`,`GROUP_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sec_filter_mask`utf8_unicode_ci	;
CREATE TABLE `b_sec_filter_mask` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SORT` int(11) NOT NULL DEFAULT '10',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILTER_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LIKE_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREG_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sec_frame_mask`utf8_unicode_ci	;
CREATE TABLE `b_sec_frame_mask` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SORT` int(11) NOT NULL DEFAULT '10',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FRAME_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LIKE_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREG_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sec_iprule`utf8_unicode_ci	;
CREATE TABLE `b_sec_iprule` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RULE_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'M',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ADMIN_SECTION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `ACTIVE_FROM` datetime DEFAULT NULL,
  `ACTIVE_FROM_TIMESTAMP` int(11) DEFAULT NULL,
  `ACTIVE_TO` datetime DEFAULT NULL,
  `ACTIVE_TO_TIMESTAMP` int(11) DEFAULT NULL,
  `NAME` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_sec_iprule_active_to` (`ACTIVE_TO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sec_iprule_excl_ip`utf8_unicode_ci	;
CREATE TABLE `b_sec_iprule_excl_ip` (
  `IPRULE_ID` int(11) NOT NULL,
  `RULE_IP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `IP_START` bigint(18) DEFAULT NULL,
  `IP_END` bigint(18) DEFAULT NULL,
  PRIMARY KEY (`IPRULE_ID`,`RULE_IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sec_iprule_excl_mask`utf8_unicode_ci	;
CREATE TABLE `b_sec_iprule_excl_mask` (
  `IPRULE_ID` int(11) NOT NULL,
  `RULE_MASK` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `LIKE_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREG_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`IPRULE_ID`,`RULE_MASK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sec_iprule_incl_ip`utf8_unicode_ci	;
CREATE TABLE `b_sec_iprule_incl_ip` (
  `IPRULE_ID` int(11) NOT NULL,
  `RULE_IP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `IP_START` bigint(18) DEFAULT NULL,
  `IP_END` bigint(18) DEFAULT NULL,
  PRIMARY KEY (`IPRULE_ID`,`RULE_IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sec_iprule_incl_mask`utf8_unicode_ci	;
CREATE TABLE `b_sec_iprule_incl_mask` (
  `IPRULE_ID` int(11) NOT NULL,
  `RULE_MASK` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `LIKE_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREG_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`IPRULE_ID`,`RULE_MASK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sec_recovery_codes`utf8_unicode_ci	;
CREATE TABLE `b_sec_recovery_codes` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `USED` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `USING_DATE` datetime DEFAULT NULL,
  `USING_IP` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_sec_recovery_codes_user_id` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sec_redirect_url`utf8_unicode_ci	;
CREATE TABLE `b_sec_redirect_url` (
  `IS_SYSTEM` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `URL` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `PARAMETER_NAME` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_sec_redirect_url`utf8_unicode_ci	;
INSERT INTO `b_sec_redirect_url` VALUES 
('Y',10,'/bitrix/redirect.php','goto'),
('Y',20,'/bitrix/rk.php','goto'),
('Y',30,'/bitrix/click.php','goto')	;
#	TC`b_sec_session`utf8_unicode_ci	;
CREATE TABLE `b_sec_session` (
  `SESSION_ID` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SESSION_DATA` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`SESSION_ID`),
  KEY `ix_b_sec_session_time` (`TIMESTAMP_X`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sec_user`utf8_unicode_ci	;
CREATE TABLE `b_sec_user` (
  `USER_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SECRET` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TYPE` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci,
  `ATTEMPTS` int(18) DEFAULT NULL,
  `INITIAL_DATE` datetime DEFAULT NULL,
  `SKIP_MANDATORY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DEACTIVATE_UNTIL` datetime DEFAULT NULL,
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sec_virus`utf8_unicode_ci	;
CREATE TABLE `b_sec_virus` (
  `ID` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `TIMESTAMP_X` datetime NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `INFO` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sec_white_list`utf8_unicode_ci	;
CREATE TABLE `b_sec_white_list` (
  `ID` int(11) NOT NULL,
  `WHITE_SUBSTR` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_security_sitecheck`utf8_unicode_ci	;
CREATE TABLE `b_security_sitecheck` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TEST_DATE` datetime DEFAULT NULL,
  `RESULTS` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_contact`utf8_unicode_ci	;
CREATE TABLE `b_sender_contact` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DATE_INSERT` datetime NOT NULL,
  `DATE_UPDATE` datetime DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PHONE` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_SENDER_CONTACT_EMAIL` (`EMAIL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_contact_list`utf8_unicode_ci	;
CREATE TABLE `b_sender_contact_list` (
  `CONTACT_ID` int(11) NOT NULL,
  `LIST_ID` int(11) NOT NULL,
  UNIQUE KEY `UK_SENDER_CONTACT_LIST` (`CONTACT_ID`,`LIST_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_group`utf8_unicode_ci	;
CREATE TABLE `b_sender_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ADDRESS_COUNT` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_group_connector`utf8_unicode_ci	;
CREATE TABLE `b_sender_group_connector` (
  `GROUP_ID` int(11) NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ENDPOINT` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ADDRESS_COUNT` int(11) NOT NULL DEFAULT '0',
  KEY `IX_SENDER_GROUP_CONNECTOR` (`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_list`utf8_unicode_ci	;
CREATE TABLE `b_sender_list` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_mailing`utf8_unicode_ci	;
CREATE TABLE `b_sender_mailing` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DATE_INSERT` datetime DEFAULT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `IS_PUBLIC` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `TRACK_CLICK` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `TRIGGER_FIELDS` text COLLATE utf8_unicode_ci,
  `EMAIL_FROM` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_TRIGGER` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_mailing_attachment`utf8_unicode_ci	;
CREATE TABLE `b_sender_mailing_attachment` (
  `CHAIN_ID` int(18) NOT NULL,
  `FILE_ID` int(18) NOT NULL,
  PRIMARY KEY (`CHAIN_ID`,`FILE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_mailing_chain`utf8_unicode_ci	;
CREATE TABLE `b_sender_mailing_chain` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MAILING_ID` int(11) NOT NULL,
  `STATUS` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `POSTING_ID` int(11) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `PARENT_ID` int(11) DEFAULT NULL,
  `IS_TRIGGER` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DATE_INSERT` datetime DEFAULT NULL,
  `TIME_SHIFT` int(11) NOT NULL DEFAULT '0',
  `LAST_EXECUTED` datetime DEFAULT NULL,
  `AUTO_SEND_TIME` datetime DEFAULT NULL,
  `EMAIL_FROM` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SUBJECT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MESSAGE` longtext COLLATE utf8_unicode_ci,
  `PRIORITY` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINK_PARAMS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TEMPLATE_TYPE` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TEMPLATE_ID` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REITERATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DAYS_OF_MONTH` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DAYS_OF_WEEK` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIMES_OF_DAY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_SENDER_MAILING_CHAIN_MAILING` (`MAILING_ID`,`STATUS`),
  KEY `IX_SENDER_MAILING_CHAIN_REITERATE` (`REITERATE`,`STATUS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_mailing_group`utf8_unicode_ci	;
CREATE TABLE `b_sender_mailing_group` (
  `MAILING_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `INCLUDE` int(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `UK_SENDER_MAILING_GROUP` (`MAILING_ID`,`GROUP_ID`,`INCLUDE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_mailing_subscription`utf8_unicode_ci	;
CREATE TABLE `b_sender_mailing_subscription` (
  `MAILING_ID` int(11) NOT NULL,
  `CONTACT_ID` int(11) NOT NULL,
  `DATE_INSERT` datetime DEFAULT NULL,
  `IS_UNSUB` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`MAILING_ID`,`CONTACT_ID`,`IS_UNSUB`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_mailing_trigger`utf8_unicode_ci	;
CREATE TABLE `b_sender_mailing_trigger` (
  `MAILING_CHAIN_ID` int(11) NOT NULL,
  `IS_TYPE_START` int(1) NOT NULL DEFAULT '1',
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EVENT` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ENDPOINT` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_posting`utf8_unicode_ci	;
CREATE TABLE `b_sender_posting` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DATE_UPDATE` datetime DEFAULT NULL,
  `MAILING_ID` int(11) NOT NULL,
  `MAILING_CHAIN_ID` int(11) NOT NULL,
  `STATUS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'D',
  `DATE_SENT` datetime DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `COUNT_SEND_ALL` int(11) NOT NULL DEFAULT '0',
  `COUNT_SEND_NONE` int(11) NOT NULL DEFAULT '0',
  `COUNT_SEND_ERROR` int(11) NOT NULL DEFAULT '0',
  `COUNT_SEND_SUCCESS` int(11) NOT NULL DEFAULT '0',
  `COUNT_SEND_DENY` int(11) NOT NULL DEFAULT '0',
  `COUNT_READ` int(11) NOT NULL DEFAULT '0',
  `COUNT_CLICK` int(11) NOT NULL DEFAULT '0',
  `COUNT_UNSUB` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `IX_SENDER_POSTING_MAILING_CHAIN` (`MAILING_ID`,`STATUS`),
  KEY `IX_SENDER_POSTING_MAILING` (`MAILING_CHAIN_ID`,`STATUS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_posting_click`utf8_unicode_ci	;
CREATE TABLE `b_sender_posting_click` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `POSTING_ID` int(11) NOT NULL,
  `RECIPIENT_ID` int(11) DEFAULT NULL,
  `DATE_INSERT` datetime DEFAULT NULL,
  `URL` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_SENDER_POSTING_CLICK` (`POSTING_ID`,`RECIPIENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_posting_read`utf8_unicode_ci	;
CREATE TABLE `b_sender_posting_read` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `POSTING_ID` int(11) NOT NULL,
  `RECIPIENT_ID` int(11) DEFAULT NULL,
  `DATE_INSERT` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_SENDER_POSTING_READ` (`POSTING_ID`,`RECIPIENT_ID`),
  KEY `ix_b_sender_posting_read_recip_id` (`RECIPIENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_posting_recipient`utf8_unicode_ci	;
CREATE TABLE `b_sender_posting_recipient` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `POSTING_ID` int(11) NOT NULL,
  `STATUS` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_SENT` datetime DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PHONE` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_ID` int(11) DEFAULT NULL,
  `DATE_DENY` datetime DEFAULT NULL,
  `FIELDS` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ROOT_ID` int(11) DEFAULT NULL,
  `IS_READ` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IS_CLICK` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IS_UNSUB` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `IX_SENDER_POSTING_RECIP_STATUS` (`STATUS`,`POSTING_ID`),
  KEY `IX_SENDER_POSTING_RECIP_EMAIL` (`EMAIL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_posting_unsub`utf8_unicode_ci	;
CREATE TABLE `b_sender_posting_unsub` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RECIPIENT_ID` int(11) NOT NULL,
  `POSTING_ID` int(11) NOT NULL,
  `DATE_INSERT` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_SENDER_POSTING_UNSUB` (`POSTING_ID`,`RECIPIENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sender_preset_template`utf8_unicode_ci	;
CREATE TABLE `b_sender_preset_template` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CONTENT` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_seo_adv_autolog`utf8_unicode_ci	;
CREATE TABLE `b_seo_adv_autolog` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ENGINE_ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CAMPAIGN_ID` int(11) NOT NULL,
  `CAMPAIGN_XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `BANNER_ID` int(11) NOT NULL,
  `BANNER_XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CAUSE_CODE` int(11) DEFAULT '0',
  `SUCCESS` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `ix_b_seo_adv_autolog1` (`ENGINE_ID`),
  KEY `ix_b_seo_adv_autolog2` (`TIMESTAMP_X`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_seo_adv_banner`utf8_unicode_ci	;
CREATE TABLE `b_seo_adv_banner` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ENGINE_ID` int(11) NOT NULL,
  `OWNER_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `OWNER_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_UPDATE` timestamp NULL DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SETTINGS` text COLLATE utf8_unicode_ci,
  `CAMPAIGN_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) DEFAULT NULL,
  `AUTO_QUANTITY_OFF` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `AUTO_QUANTITY_ON` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_b_seo_adv_banner` (`ENGINE_ID`,`XML_ID`),
  KEY `ix_b_seo_adv_banner1` (`CAMPAIGN_ID`),
  KEY `ix_b_seo_adv_banner2` (`AUTO_QUANTITY_OFF`,`AUTO_QUANTITY_ON`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_seo_adv_campaign`utf8_unicode_ci	;
CREATE TABLE `b_seo_adv_campaign` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ENGINE_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `OWNER_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `OWNER_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_UPDATE` timestamp NULL DEFAULT NULL,
  `SETTINGS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_b_seo_adv_campaign` (`ENGINE_ID`,`XML_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_seo_adv_group`utf8_unicode_ci	;
CREATE TABLE `b_seo_adv_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ENGINE_ID` int(11) NOT NULL,
  `OWNER_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `OWNER_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_UPDATE` timestamp NULL DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SETTINGS` text COLLATE utf8_unicode_ci,
  `CAMPAIGN_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_b_seo_adv_group` (`ENGINE_ID`,`XML_ID`),
  KEY `ix_b_seo_adv_group1` (`CAMPAIGN_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_seo_adv_link`utf8_unicode_ci	;
CREATE TABLE `b_seo_adv_link` (
  `LINK_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `LINK_ID` int(18) NOT NULL,
  `BANNER_ID` int(11) NOT NULL,
  PRIMARY KEY (`LINK_TYPE`,`LINK_ID`,`BANNER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_seo_adv_log`utf8_unicode_ci	;
CREATE TABLE `b_seo_adv_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ENGINE_ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `REQUEST_URI` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `REQUEST_DATA` text COLLATE utf8_unicode_ci,
  `RESPONSE_TIME` float NOT NULL,
  `RESPONSE_STATUS` int(5) DEFAULT NULL,
  `RESPONSE_DATA` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `ix_b_seo_adv_log1` (`ENGINE_ID`),
  KEY `ix_b_seo_adv_log2` (`TIMESTAMP_X`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_seo_adv_order`utf8_unicode_ci	;
CREATE TABLE `b_seo_adv_order` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ENGINE_ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CAMPAIGN_ID` int(11) NOT NULL,
  `BANNER_ID` int(11) NOT NULL,
  `ORDER_ID` int(11) NOT NULL,
  `SUM` float DEFAULT '0',
  `PROCESSED` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_b_seo_adv_order` (`ENGINE_ID`,`CAMPAIGN_ID`,`BANNER_ID`,`ORDER_ID`),
  KEY `ix_b_seo_adv_order1` (`ORDER_ID`,`PROCESSED`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_seo_adv_region`utf8_unicode_ci	;
CREATE TABLE `b_seo_adv_region` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ENGINE_ID` int(11) NOT NULL,
  `OWNER_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `OWNER_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_UPDATE` timestamp NULL DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SETTINGS` text COLLATE utf8_unicode_ci,
  `PARENT_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_b_seo_adv_region` (`ENGINE_ID`,`XML_ID`),
  KEY `ix_b_seo_adv_region1` (`PARENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_seo_keywords`utf8_unicode_ci	;
CREATE TABLE `b_seo_keywords` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `KEYWORDS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `ix_b_seo_keywords_url` (`URL`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_seo_search_engine`utf8_unicode_ci	;
CREATE TABLE `b_seo_search_engine` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `SORT` int(5) DEFAULT '100',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CLIENT_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CLIENT_SECRET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REDIRECT_URI` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SETTINGS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_b_seo_search_engine_code` (`CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_seo_search_engine`utf8_unicode_ci	;
INSERT INTO `b_seo_search_engine` VALUES 
(1,'google','Y',200,'Google','868942902147-qrrd6ce1ajfkpse8ieq4gkpdeanvtnno.apps.googleusercontent.com','EItMlJpZLC2WRPKB6QsA5bV9','urn:ietf:wg:oauth:2.0:oob',\N),
(2,'yandex','Y',300,'Yandex','f848c7bfc1d34a94ba6d05439f81bbd7','da0e73b2d9cc4e809f3170e49cb9df01','https://oauth.yandex.ru/verification_code',\N),
(3,'yandex_direct','Y',400,'Yandex.Direct','','','https://oauth.yandex.ru/verification_code',\N)	;
#	TC`b_seo_sitemap`utf8_unicode_ci	;
CREATE TABLE `b_seo_sitemap` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `DATE_RUN` datetime DEFAULT NULL,
  `SETTINGS` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_seo_sitemap_entity`utf8_unicode_ci	;
CREATE TABLE `b_seo_sitemap_entity` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ENTITY_TYPE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `SITEMAP_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_seo_sitemap_entity_1` (`ENTITY_TYPE`,`ENTITY_ID`),
  KEY `ix_b_seo_sitemap_entity_2` (`SITEMAP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_seo_sitemap_iblock`utf8_unicode_ci	;
CREATE TABLE `b_seo_sitemap_iblock` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IBLOCK_ID` int(11) NOT NULL,
  `SITEMAP_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_seo_sitemap_iblock_1` (`IBLOCK_ID`),
  KEY `ix_b_seo_sitemap_iblock_2` (`SITEMAP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_seo_sitemap_runtime`utf8_unicode_ci	;
CREATE TABLE `b_seo_sitemap_runtime` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PID` int(11) NOT NULL,
  `PROCESSED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ITEM_PATH` varchar(700) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ITEM_ID` int(11) DEFAULT NULL,
  `ITEM_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'D',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `ACTIVE_ELEMENT` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `ix_seo_sitemap_runtime1` (`PID`,`PROCESSED`,`ITEM_TYPE`,`ITEM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_seo_yandex_direct_stat`utf8_unicode_ci	;
CREATE TABLE `b_seo_yandex_direct_stat` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `CAMPAIGN_ID` int(11) NOT NULL,
  `BANNER_ID` int(11) NOT NULL,
  `DATE_DAY` date NOT NULL,
  `CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUM` float DEFAULT '0',
  `SUM_SEARCH` float DEFAULT '0',
  `SUM_CONTEXT` float DEFAULT '0',
  `CLICKS` int(7) DEFAULT '0',
  `CLICKS_SEARCH` int(7) DEFAULT '0',
  `CLICKS_CONTEXT` int(7) DEFAULT '0',
  `SHOWS` int(7) DEFAULT '0',
  `SHOWS_SEARCH` int(7) DEFAULT '0',
  `SHOWS_CONTEXT` int(7) DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_seo_yandex_direct_stat` (`BANNER_ID`,`DATE_DAY`),
  KEY `ix_seo_yandex_direct_stat1` (`CAMPAIGN_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_short_uri`utf8_unicode_ci	;
CREATE TABLE `b_short_uri` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `URI` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `URI_CRC` int(18) NOT NULL,
  `SHORT_URI` varbinary(250) NOT NULL,
  `SHORT_URI_CRC` int(18) NOT NULL,
  `STATUS` int(18) NOT NULL DEFAULT '301',
  `MODIFIED` datetime NOT NULL,
  `LAST_USED` datetime DEFAULT NULL,
  `NUMBER_USED` int(18) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ux_b_short_uri_1` (`SHORT_URI_CRC`),
  KEY `ux_b_short_uri_2` (`URI_CRC`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_site_template`utf8_unicode_ci	;
CREATE TABLE `b_site_template` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `TEMPLATE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_site_template_site` (`SITE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_site_template`utf8_unicode_ci	;
INSERT INTO `b_site_template` VALUES 
(2,'s1','',150,'books'),
(3,'s1','$_GET[\'print\']==\'Y\'',150,'print')	;
#	TC`b_smile`utf8_unicode_ci	;
CREATE TABLE `b_smile` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `SET_ID` int(18) NOT NULL DEFAULT '0',
  `SORT` int(10) NOT NULL DEFAULT '150',
  `TYPING` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CLICKABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `HIDDEN` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IMAGE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `IMAGE_DEFINITION` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'SD',
  `IMAGE_WIDTH` int(11) NOT NULL DEFAULT '0',
  `IMAGE_HEIGHT` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_smile`utf8_unicode_ci	;
INSERT INTO `b_smile` VALUES 
(1,'S',2,100,':) :-)','Y','N','bx_smile_smile.png','UHD',20,20),
(2,'S',2,105,';) ;-)','Y','N','bx_smile_wink.png','UHD',20,20),
(3,'S',2,110,':D :-D','Y','N','bx_smile_biggrin.png','UHD',20,20),
(4,'S',2,115,'8) 8-)','Y','N','bx_smile_cool.png','UHD',20,20),
(5,'S',2,120,':facepalm:','Y','N','bx_smile_facepalm.png','UHD',20,20),
(6,'S',2,125,':{} :-{}','Y','N','bx_smile_kiss.png','UHD',20,20),
(7,'S',2,130,':( :-(','Y','N','bx_smile_sad.png','UHD',20,20),
(8,'S',2,135,':| :-|','Y','N','bx_smile_neutral.png','UHD',20,20),
(9,'S',2,140,':oops:','Y','N','bx_smile_redface.png','UHD',20,20),
(10,'S',2,145,':cry: :~(','Y','N','bx_smile_cry.png','UHD',20,20),
(11,'S',2,150,':evil: >:-<','Y','N','bx_smile_evil.png','UHD',20,20),
(12,'S',2,155,':o :-o :shock:','Y','N','bx_smile_eek.png','UHD',20,20),
(13,'S',2,160,':/ :-/','Y','N','bx_smile_confuse.png','UHD',20,20),
(14,'S',2,165,':idea:','Y','N','bx_smile_idea.png','UHD',20,20),
(15,'S',2,170,':?:','Y','N','bx_smile_question.png','UHD',20,20),
(16,'S',2,175,':!:','Y','N','bx_smile_exclaim.png','UHD',20,20),
(17,'S',2,180,':like:','Y','N','bx_smile_like.png','UHD',20,20),
(18,'I',2,175,'ICON_NOTE','Y','N','bx_icon_1.gif','SD',15,15),
(19,'I',2,180,'ICON_DIRRECTION','Y','N','bx_icon_2.gif','SD',15,15),
(20,'I',2,185,'ICON_IDEA','Y','N','bx_icon_3.gif','SD',15,15),
(21,'I',2,190,'ICON_ATTANSION','Y','N','bx_icon_4.gif','SD',15,15),
(22,'I',2,195,'ICON_QUESTION','Y','N','bx_icon_5.gif','SD',15,15),
(23,'I',2,200,'ICON_BAD','Y','N','bx_icon_6.gif','SD',15,15),
(24,'I',2,205,'ICON_GOOD','Y','N','bx_icon_7.gif','SD',15,15)	;
#	TC`b_smile_lang`utf8_unicode_ci	;
CREATE TABLE `b_smile_lang` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `SID` int(11) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_SMILE_SL` (`TYPE`,`SID`,`LID`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_smile_lang`utf8_unicode_ci	;
INSERT INTO `b_smile_lang` VALUES 
(1,'P',1,'ru','Стандартная галерея'),
(2,'P',1,'en','Standard gallery'),
(3,'G',2,'ru','Основной набор'),
(4,'G',2,'en','Default pack'),
(5,'S',1,'ru','С улыбкой'),
(6,'S',1,'en','Smile'),
(7,'S',2,'ru','Шутливо'),
(8,'S',2,'en','Wink'),
(9,'S',3,'ru','Широкая улыбка'),
(10,'S',3,'en','Big grin'),
(11,'S',4,'ru','Здорово'),
(12,'S',4,'en','Cool'),
(13,'S',5,'ru','Разочарование'),
(14,'S',5,'en','Facepalm'),
(15,'S',6,'ru','Поцелуй'),
(16,'S',6,'en','Kiss'),
(17,'S',7,'ru','Печально'),
(18,'S',7,'en','Sad'),
(19,'S',8,'ru','Скептически'),
(20,'S',8,'en','Skeptic'),
(21,'S',9,'ru','Смущенный'),
(22,'S',9,'en','Embarrassed'),
(23,'S',10,'ru','Очень грустно'),
(24,'S',10,'en','Crying'),
(25,'S',11,'ru','Со злостью'),
(26,'S',11,'en','Angry'),
(27,'S',12,'ru','Удивленно'),
(28,'S',12,'en','Surprised'),
(29,'S',13,'ru','Смущенно'),
(30,'S',13,'en','Confused'),
(31,'S',14,'ru','Идея'),
(32,'S',14,'en','Idea'),
(33,'S',15,'ru','Вопрос'),
(34,'S',15,'en','Question'),
(35,'S',16,'ru','Восклицание'),
(36,'S',16,'en','Exclamation'),
(37,'S',17,'ru','Нравится'),
(38,'S',17,'en','Like')	;
#	TC`b_smile_set`utf8_unicode_ci	;
CREATE TABLE `b_smile_set` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'G',
  `PARENT_ID` int(18) NOT NULL DEFAULT '0',
  `STRING_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(10) NOT NULL DEFAULT '150',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_smile_set`utf8_unicode_ci	;
INSERT INTO `b_smile_set` VALUES 
(1,'P',0,'bitrix',150),
(2,'G',1,'bitrix_main',150)	;
#	TC`b_socialservices_contact`utf8_unicode_ci	;
CREATE TABLE `b_socialservices_contact` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `USER_ID` int(11) NOT NULL,
  `CONTACT_USER_ID` int(11) DEFAULT NULL,
  `CONTACT_XML_ID` int(11) DEFAULT NULL,
  `CONTACT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONTACT_LAST_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONTACT_PHOTO` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_AUTHORIZE` datetime DEFAULT NULL,
  `NOTIFY` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `ix_b_socialservices_contact1` (`USER_ID`),
  KEY `ix_b_socialservices_contact2` (`CONTACT_USER_ID`),
  KEY `ix_b_socialservices_contact3` (`TIMESTAMP_X`),
  KEY `ix_b_socialservices_contact4` (`LAST_AUTHORIZE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_socialservices_contact_connect`utf8_unicode_ci	;
CREATE TABLE `b_socialservices_contact_connect` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `CONTACT_ID` int(11) DEFAULT NULL,
  `LINK_ID` int(11) DEFAULT NULL,
  `CONTACT_PROFILE_ID` int(11) NOT NULL,
  `CONTACT_PORTAL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CONNECT_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT 'P',
  `LAST_AUTHORIZE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_socialservices_contact_connect1` (`CONTACT_ID`),
  KEY `ix_b_socialservices_contact_connect2` (`LINK_ID`),
  KEY `ix_b_socialservices_contact_connect3` (`LAST_AUTHORIZE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_socialservices_message`utf8_unicode_ci	;
CREATE TABLE `b_socialservices_message` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `SOCSERV_USER_ID` int(11) NOT NULL,
  `PROVIDER` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `INSERT_DATE` datetime DEFAULT NULL,
  `SUCCES_SENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_socialservices_user`utf8_unicode_ci	;
CREATE TABLE `b_socialservices_user` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LOGIN` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_PHOTO` int(11) DEFAULT NULL,
  `EXTERNAL_AUTH_ID` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `XML_ID` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `CAN_DELETE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `PERSONAL_WWW` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERMISSIONS` varchar(555) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OATOKEN` varchar(3000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OATOKEN_EXPIRES` int(11) DEFAULT NULL,
  `OASECRET` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REFRESH_TOKEN` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEND_ACTIVITY` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `SITE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `INITIALIZED` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_B_SOCIALSERVICES_USER` (`XML_ID`,`EXTERNAL_AUTH_ID`),
  KEY `IX_B_SOCIALSERVICES_US_1` (`USER_ID`),
  KEY `IX_B_SOCIALSERVICES_US_3` (`LOGIN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_socialservices_user_link`utf8_unicode_ci	;
CREATE TABLE `b_socialservices_user_link` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `SOCSERV_USER_ID` int(11) NOT NULL,
  `LINK_USER_ID` int(11) DEFAULT NULL,
  `LINK_UID` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `LINK_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINK_LAST_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINK_PICTURE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINK_EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIMESTAMP_X` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_socialservices_user_link_5` (`SOCSERV_USER_ID`),
  KEY `ix_b_socialservices_user_link_6` (`LINK_USER_ID`,`TIMESTAMP_X`),
  KEY `ix_b_socialservices_user_link_7` (`LINK_UID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sticker`utf8_unicode_ci	;
CREATE TABLE `b_sticker` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PAGE_URL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PAGE_TITLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATE` datetime NOT NULL,
  `DATE_UPDATE` datetime NOT NULL,
  `MODIFIED_BY` int(18) NOT NULL,
  `CREATED_BY` int(18) NOT NULL,
  `PERSONAL` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CONTENT` text COLLATE utf8_unicode_ci,
  `POS_TOP` int(11) DEFAULT NULL,
  `POS_LEFT` int(11) DEFAULT NULL,
  `WIDTH` int(11) DEFAULT NULL,
  `HEIGHT` int(11) DEFAULT NULL,
  `COLOR` int(11) DEFAULT NULL,
  `COLLAPSED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `COMPLETED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CLOSED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DELETED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `MARKER_TOP` int(11) DEFAULT NULL,
  `MARKER_LEFT` int(11) DEFAULT NULL,
  `MARKER_WIDTH` int(11) DEFAULT NULL,
  `MARKER_HEIGHT` int(11) DEFAULT NULL,
  `MARKER_ADJUST` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_sticker_group_task`utf8_unicode_ci	;
CREATE TABLE `b_sticker_group_task` (
  `GROUP_ID` int(11) NOT NULL,
  `TASK_ID` int(11) NOT NULL,
  PRIMARY KEY (`GROUP_ID`,`TASK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_subscription`utf8_unicode_ci	;
CREATE TABLE `b_subscription` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DATE_INSERT` datetime NOT NULL,
  `DATE_UPDATE` datetime DEFAULT NULL,
  `USER_ID` int(11) DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `FORMAT` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `CONFIRM_CODE` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONFIRMED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DATE_CONFIRM` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_SUBSCRIPTION_EMAIL` (`EMAIL`,`USER_ID`),
  KEY `IX_DATE_CONFIRM` (`CONFIRMED`,`DATE_CONFIRM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_subscription_rubric`utf8_unicode_ci	;
CREATE TABLE `b_subscription_rubric` (
  `SUBSCRIPTION_ID` int(11) NOT NULL,
  `LIST_RUBRIC_ID` int(11) NOT NULL,
  UNIQUE KEY `UK_SUBSCRIPTION_RUBRIC` (`SUBSCRIPTION_ID`,`LIST_RUBRIC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_task`utf8_unicode_ci	;
CREATE TABLE `b_task` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `LETTER` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SYS` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BINDING` varchar(50) COLLATE utf8_unicode_ci DEFAULT 'module',
  PRIMARY KEY (`ID`),
  KEY `ix_task` (`MODULE_ID`,`BINDING`,`LETTER`,`SYS`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_task`utf8_unicode_ci	;
INSERT INTO `b_task` VALUES 
(1,'main_denied','D','main','Y',\N,'module'),
(2,'main_change_profile','P','main','Y',\N,'module'),
(3,'main_view_all_settings','R','main','Y',\N,'module'),
(4,'main_view_all_settings_change_profile','T','main','Y',\N,'module'),
(5,'main_edit_subordinate_users','V','main','Y',\N,'module'),
(6,'main_full_access','W','main','Y',\N,'module'),
(7,'fm_folder_access_denied','D','main','Y',\N,'file'),
(8,'fm_folder_access_read','R','main','Y',\N,'file'),
(9,'fm_folder_access_write','W','main','Y',\N,'file'),
(10,'fm_folder_access_full','X','main','Y',\N,'file'),
(11,'fm_folder_access_workflow','U','main','Y',\N,'file'),
(12,'catalog_denied','D','catalog','Y',\N,'module'),
(13,'catalog_view','M','catalog','Y',\N,'module'),
(14,'catalog_read','R','catalog','Y',\N,'module'),
(15,'catalog_price_edit','T','catalog','Y',\N,'module'),
(16,'catalog_store_edit','S','catalog','Y',\N,'module'),
(17,'catalog_export_import','U','catalog','Y',\N,'module'),
(18,'catalog_full_access','W','catalog','Y',\N,'module'),
(19,'clouds_denied','D','clouds','Y',\N,'module'),
(20,'clouds_browse','F','clouds','Y',\N,'module'),
(21,'clouds_upload','U','clouds','Y',\N,'module'),
(22,'clouds_full_access','W','clouds','Y',\N,'module'),
(23,'fileman_denied','D','fileman','Y','','module'),
(24,'fileman_allowed_folders','F','fileman','Y','','module'),
(25,'fileman_full_access','W','fileman','Y','','module'),
(26,'medialib_denied','D','fileman','Y','','medialib'),
(27,'medialib_view','F','fileman','Y','','medialib'),
(28,'medialib_only_new','R','fileman','Y','','medialib'),
(29,'medialib_edit_items','V','fileman','Y','','medialib'),
(30,'medialib_editor','W','fileman','Y','','medialib'),
(31,'medialib_full','X','fileman','Y','','medialib'),
(32,'stickers_denied','D','fileman','Y','','stickers'),
(33,'stickers_read','R','fileman','Y','','stickers'),
(34,'stickers_edit','W','fileman','Y','','stickers'),
(35,'iblock_deny','D','iblock','Y',\N,'iblock'),
(36,'iblock_read','R','iblock','Y',\N,'iblock'),
(37,'iblock_element_add','E','iblock','Y',\N,'iblock'),
(38,'iblock_admin_read','S','iblock','Y',\N,'iblock'),
(39,'iblock_admin_add','T','iblock','Y',\N,'iblock'),
(40,'iblock_limited_edit','U','iblock','Y',\N,'iblock'),
(41,'iblock_full_edit','W','iblock','Y',\N,'iblock'),
(42,'iblock_full','X','iblock','Y',\N,'iblock'),
(43,'sale_status_none','D','sale','Y',\N,'status'),
(44,'sale_status_all','X','sale','Y',\N,'status'),
(45,'security_denied','D','security','Y',\N,'module'),
(46,'security_filter','F','security','Y',\N,'module'),
(47,'security_otp','S','security','Y',\N,'module'),
(48,'security_view_all_settings','T','security','Y',\N,'module'),
(49,'security_full_access','W','security','Y',\N,'module'),
(50,'seo_denied','D','seo','Y','','module'),
(51,'seo_edit','F','seo','Y','','module'),
(52,'seo_full_access','W','seo','Y','','module')	;
#	TC`b_task_operation`utf8_unicode_ci	;
CREATE TABLE `b_task_operation` (
  `TASK_ID` int(18) NOT NULL,
  `OPERATION_ID` int(18) NOT NULL,
  PRIMARY KEY (`TASK_ID`,`OPERATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_task_operation`utf8_unicode_ci	;
INSERT INTO `b_task_operation` VALUES 
(2,2),
(2,3),
(3,2),
(3,4),
(3,5),
(3,6),
(3,7),
(4,2),
(4,3),
(4,4),
(4,5),
(4,6),
(4,7),
(5,2),
(5,3),
(5,5),
(5,6),
(5,7),
(5,8),
(5,9),
(6,2),
(6,3),
(6,4),
(6,5),
(6,6),
(6,7),
(6,10),
(6,11),
(6,12),
(6,13),
(6,14),
(6,15),
(6,16),
(6,17),
(6,18),
(8,19),
(8,20),
(8,21),
(9,19),
(9,20),
(9,21),
(9,22),
(9,23),
(9,24),
(9,25),
(9,26),
(9,27),
(9,28),
(9,29),
(9,30),
(9,31),
(9,32),
(9,33),
(9,34),
(10,19),
(10,20),
(10,21),
(10,22),
(10,23),
(10,24),
(10,25),
(10,26),
(10,27),
(10,28),
(10,29),
(10,30),
(10,31),
(10,32),
(10,33),
(10,34),
(10,35),
(11,19),
(11,20),
(11,21),
(11,24),
(11,28),
(13,36),
(14,37),
(15,37),
(15,38),
(15,39),
(15,40),
(15,41),
(15,42),
(15,43),
(16,37),
(16,38),
(16,42),
(16,43),
(16,44),
(17,37),
(17,45),
(17,46),
(17,47),
(17,48),
(18,37),
(18,38),
(18,39),
(18,40),
(18,41),
(18,42),
(18,43),
(18,44),
(18,45),
(18,46),
(18,47),
(18,48),
(18,49),
(18,50),
(20,51),
(21,51),
(21,52),
(22,51),
(22,52),
(22,53),
(24,56),
(24,57),
(24,58),
(24,59),
(24,60),
(24,61),
(24,62),
(24,64),
(24,65),
(25,54),
(25,55),
(25,56),
(25,57),
(25,58),
(25,59),
(25,60),
(25,61),
(25,62),
(25,63),
(25,64),
(25,65),
(25,66),
(27,67),
(28,67),
(28,68),
(28,72),
(29,67),
(29,72),
(29,73),
(29,74),
(30,67),
(30,68),
(30,69),
(30,70),
(30,72),
(30,73),
(30,74),
(31,67),
(31,68),
(31,69),
(31,70),
(31,71),
(31,72),
(31,73),
(31,74),
(33,75),
(34,75),
(34,76),
(34,77),
(34,78),
(36,79),
(36,80),
(37,81),
(38,79),
(38,80),
(38,82),
(39,79),
(39,80),
(39,81),
(39,82),
(40,79),
(40,80),
(40,81),
(40,82),
(40,83),
(40,84),
(40,85),
(40,86),
(41,79),
(41,80),
(41,81),
(41,82),
(41,83),
(41,84),
(41,85),
(41,86),
(41,87),
(41,88),
(41,89),
(41,90),
(42,79),
(42,80),
(42,81),
(42,82),
(42,83),
(42,84),
(42,85),
(42,86),
(42,87),
(42,88),
(42,89),
(42,90),
(42,91),
(42,92),
(42,93),
(42,94),
(42,95),
(42,96),
(44,97),
(44,98),
(44,99),
(44,100),
(44,101),
(44,102),
(44,103),
(44,104),
(44,105),
(44,106),
(46,107),
(47,108),
(48,109),
(48,110),
(48,111),
(48,112),
(48,113),
(48,114),
(48,115),
(48,116),
(48,117),
(48,118),
(48,119),
(49,107),
(49,108),
(49,109),
(49,110),
(49,111),
(49,112),
(49,113),
(49,114),
(49,115),
(49,116),
(49,117),
(49,118),
(49,119),
(49,120),
(49,121),
(49,122),
(49,123),
(49,124),
(49,125),
(49,126),
(49,127),
(49,128),
(49,129),
(49,130),
(49,131),
(49,132),
(51,134),
(52,133),
(52,134)	;
#	TC`b_undo`utf8_unicode_ci	;
CREATE TABLE `b_undo` (
  `ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UNDO_TYPE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UNDO_HANDLER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONTENT` mediumtext COLLATE utf8_unicode_ci,
  `USER_ID` int(11) DEFAULT NULL,
  `TIMESTAMP_X` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_urlpreview_metadata`utf8_unicode_ci	;
CREATE TABLE `b_urlpreview_metadata` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `URL` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `DATE_INSERT` datetime NOT NULL,
  `DATE_EXPIRE` datetime DEFAULT NULL,
  `TITLE` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `IMAGE_ID` int(11) DEFAULT NULL,
  `IMAGE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMBED` mediumtext COLLATE utf8_unicode_ci,
  `EXTRA` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_URLPREVIEW_METADATA_URL` (`URL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_urlpreview_route`utf8_unicode_ci	;
CREATE TABLE `b_urlpreview_route` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ROUTE` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CLASS` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `PARAMETERS` mediumtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_URLPREVIEW_ROUTE_ROUTE` (`ROUTE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_user`utf8_unicode_ci	;
CREATE TABLE `b_user` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LOGIN` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `PASSWORD` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CHECKWORD` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_LOGIN` datetime DEFAULT NULL,
  `DATE_REGISTER` datetime NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_PROFESSION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_WWW` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_ICQ` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_GENDER` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_BIRTHDATE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_PHOTO` int(18) DEFAULT NULL,
  `PERSONAL_PHONE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_FAX` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_MOBILE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_PAGER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_STREET` text COLLATE utf8_unicode_ci,
  `PERSONAL_MAILBOX` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_CITY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_STATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_ZIP` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_COUNTRY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_NOTES` text COLLATE utf8_unicode_ci,
  `WORK_COMPANY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_DEPARTMENT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_POSITION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_WWW` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_PHONE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_FAX` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_PAGER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_STREET` text COLLATE utf8_unicode_ci,
  `WORK_MAILBOX` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_CITY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_STATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_ZIP` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_COUNTRY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_PROFILE` text COLLATE utf8_unicode_ci,
  `WORK_LOGO` int(18) DEFAULT NULL,
  `WORK_NOTES` text COLLATE utf8_unicode_ci,
  `ADMIN_NOTES` text COLLATE utf8_unicode_ci,
  `STORED_HASH` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_BIRTHDAY` date DEFAULT NULL,
  `EXTERNAL_AUTH_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CHECKWORD_TIME` datetime DEFAULT NULL,
  `SECOND_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONFIRM_CODE` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOGIN_ATTEMPTS` int(18) DEFAULT NULL,
  `LAST_ACTIVITY_DATE` datetime DEFAULT NULL,
  `AUTO_TIME_ZONE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIME_ZONE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIME_ZONE_OFFSET` int(18) DEFAULT NULL,
  `TITLE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BX_USER_ID` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ix_login` (`LOGIN`,`EXTERNAL_AUTH_ID`),
  KEY `ix_b_user_email` (`EMAIL`),
  KEY `ix_b_user_activity_date` (`LAST_ACTIVITY_DATE`),
  KEY `IX_B_USER_XML_ID` (`XML_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_user`utf8_unicode_ci	;
INSERT INTO `b_user` VALUES 
(1,'2016-10-18 09:08:04','admin','QjGkj1L44a08f8aaf889a9b9a1d1973da28e2823','kLFZP3sn7a244071d5fa53c8eeef02ba78c01550','Y','','','bolonikov@medialine.by','2016-10-18 09:08:04','2016-10-18 09:05:30',\N,\N,\N,\N,'',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,'2016-10-18 09:05:30',\N,\N,0,\N,\N,\N,\N,\N,\N,\N)	;
#	TC`b_user_access`utf8_unicode_ci	;
CREATE TABLE `b_user_access` (
  `USER_ID` int(11) DEFAULT NULL,
  `PROVIDER_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACCESS_CODE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  KEY `ix_ua_user_provider` (`USER_ID`,`PROVIDER_ID`),
  KEY `ix_ua_user_access` (`USER_ID`,`ACCESS_CODE`),
  KEY `ix_ua_access` (`ACCESS_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_user_access`utf8_unicode_ci	;
INSERT INTO `b_user_access` VALUES 
(0,'group','G2'),
(1,'group','G1'),
(1,'group','G3'),
(1,'group','G4'),
(1,'group','G2'),
(1,'user','U1')	;
#	TC`b_user_access_check`utf8_unicode_ci	;
CREATE TABLE `b_user_access_check` (
  `USER_ID` int(11) DEFAULT NULL,
  `PROVIDER_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  KEY `ix_uac_user_provider` (`USER_ID`,`PROVIDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_user_access_check`utf8_unicode_ci	;
INSERT INTO `b_user_access_check` VALUES 
(1,'group'),
(1,'user')	;
#	TC`b_user_counter`utf8_unicode_ci	;
CREATE TABLE `b_user_counter` (
  `USER_ID` int(18) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '**',
  `CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CNT` int(18) NOT NULL DEFAULT '0',
  `LAST_DATE` datetime DEFAULT NULL,
  `TIMESTAMP_X` datetime NOT NULL DEFAULT '3000-01-01 00:00:00',
  `TAG` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci,
  `SENT` char(1) COLLATE utf8_unicode_ci DEFAULT '0',
  PRIMARY KEY (`USER_ID`,`SITE_ID`,`CODE`),
  KEY `ix_buc_tag` (`TAG`),
  KEY `ix_buc_code` (`CODE`),
  KEY `ix_buc_ts` (`TIMESTAMP_X`),
  KEY `ix_buc_sent_userid` (`SENT`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_user_digest`utf8_unicode_ci	;
CREATE TABLE `b_user_digest` (
  `USER_ID` int(11) NOT NULL,
  `DIGEST_HA1` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_user_field`utf8_unicode_ci	;
CREATE TABLE `b_user_field` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ENTITY_ID` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD_NAME` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) DEFAULT NULL,
  `MULTIPLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `MANDATORY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SHOW_FILTER` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SHOW_IN_LIST` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `EDIT_IN_LIST` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `IS_SEARCHABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SETTINGS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_user_type_entity` (`ENTITY_ID`,`FIELD_NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_user_field`utf8_unicode_ci	;
INSERT INTO `b_user_field` VALUES 
(1,'BLOG_POST','UF_BLOG_POST_DOC','file','UF_BLOG_POST_DOC',100,'Y','N','N','N','Y','Y','a:0:{}'),
(2,'BLOG_COMMENT','UF_BLOG_COMMENT_DOC','file','UF_BLOG_COMMENT_DOC',100,'Y','N','N','N','Y','Y','a:0:{}'),
(3,'BLOG_POST','UF_BLOG_POST_URL_PRV','url_preview','UF_BLOG_POST_URL_PRV',100,'N','N','N','N','Y','Y','a:0:{}'),
(4,'BLOG_COMMENT','UF_BLOG_COMM_URL_PRV','url_preview','UF_BLOG_COMM_URL_PRV',100,'N','N','N','N','Y','Y','a:0:{}'),
(5,'BLOG_POST','UF_GRATITUDE','integer','UF_GRATITUDE',100,'N','N','N','N','Y','N','a:0:{}'),
(6,'FORUM_MESSAGE','UF_FORUM_MES_URL_PRV','url_preview','UF_FORUM_MES_URL_PRV',100,'N','N','N','N','Y','N','a:0:{}')	;
#	TC`b_user_field_confirm`utf8_unicode_ci	;
CREATE TABLE `b_user_field_confirm` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(18) NOT NULL,
  `DATE_CHANGE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `FIELD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `FIELD_VALUE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CONFIRM_CODE` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_user_field_confirm1` (`USER_ID`,`CONFIRM_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_user_field_enum`utf8_unicode_ci	;
CREATE TABLE `b_user_field_enum` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_FIELD_ID` int(11) DEFAULT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_user_field_enum` (`USER_FIELD_ID`,`XML_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_user_field_lang`utf8_unicode_ci	;
CREATE TABLE `b_user_field_lang` (
  `USER_FIELD_ID` int(11) NOT NULL DEFAULT '0',
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `EDIT_FORM_LABEL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LIST_COLUMN_LABEL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LIST_FILTER_LABEL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ERROR_MESSAGE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HELP_MESSAGE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`USER_FIELD_ID`,`LANGUAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_user_group`utf8_unicode_ci	;
CREATE TABLE `b_user_group` (
  `USER_ID` int(18) NOT NULL,
  `GROUP_ID` int(18) NOT NULL,
  `DATE_ACTIVE_FROM` datetime DEFAULT NULL,
  `DATE_ACTIVE_TO` datetime DEFAULT NULL,
  UNIQUE KEY `ix_user_group` (`USER_ID`,`GROUP_ID`),
  KEY `ix_user_group_group` (`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_user_group`utf8_unicode_ci	;
INSERT INTO `b_user_group` VALUES 
(1,1,\N,\N),
(1,3,\N,\N),
(1,4,\N,\N)	;
#	TC`b_user_hit_auth`utf8_unicode_ci	;
CREATE TABLE `b_user_hit_auth` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(18) NOT NULL,
  `HASH` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `URL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `IX_USER_HIT_AUTH_1` (`HASH`),
  KEY `IX_USER_HIT_AUTH_2` (`USER_ID`),
  KEY `IX_USER_HIT_AUTH_3` (`TIMESTAMP_X`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_user_option`utf8_unicode_ci	;
CREATE TABLE `b_user_option` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `CATEGORY` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` mediumtext COLLATE utf8_unicode_ci,
  `COMMON` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_user_category_name` (`USER_ID`,`CATEGORY`,`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_user_option`utf8_unicode_ci	;
INSERT INTO `b_user_option` VALUES 
(1,0,'intranet','~gadgets_admin_index','a:1:{i:0;a:1:{s:7:\"GADGETS\";a:11:{s:28:\"ADMIN_ORDERS_GRAPH@111111111\";a:3:{s:6:\"COLUMN\";i:0;s:3:\"ROW\";i:0;s:4:\"HIDE\";s:1:\"N\";}s:22:\"ADMIN_ORDERS@111111111\";a:3:{s:6:\"COLUMN\";i:0;s:3:\"ROW\";i:1;s:4:\"HIDE\";s:1:\"N\";}s:19:\"HTML_AREA@444444444\";a:5:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:0;s:4:\"HIDE\";s:1:\"N\";s:8:\"USERDATA\";a:1:{s:7:\"content\";s:797:\"<table class=\"bx-gadgets-info-site-table\" cellspacing=\"0\"><tr>	<td class=\"bx-gadget-gray\">Создатель сайта:</td>	<td>Группа компаний &laquo;1С-Битрикс&raquo;.</td>	<td class=\"bx-gadgets-info-site-logo\" rowspan=\"5\"><img src=\"/bitrix/components/bitrix/desktop/templates/admin/images/site_logo.png\"></td></tr><tr>	<td class=\"bx-gadget-gray\">Адрес сайта:</td>	<td><a href=\"http://www.1c-bitrix.ru\">www.1c-bitrix.ru</a></td></tr><tr>	<td class=\"bx-gadget-gray\">Сайт сдан:</td>	<td>12 декабря 2010 г.</td></tr><tr>	<td class=\"bx-gadget-gray\">Ответственное лицо:</td>	<td>Иван Иванов</td></tr><tr>	<td class=\"bx-gadget-gray\">E-mail:</td>	<td><a href=\"mailto:info@1c-bitrix.ru\">info@1c-bitrix.ru</a></td></tr></table>\";}s:8:\"SETTINGS\";a:1:{s:9:\"TITLE_STD\";s:34:\"Информация о сайте\";}}s:24:\"ADMIN_SECURITY@555555555\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:1;s:4:\"HIDE\";s:1:\"N\";}s:23:\"ADMIN_PERFMON@666666666\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:2;s:4:\"HIDE\";s:1:\"N\";}s:24:\"ADMIN_PRODUCTS@111111111\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:5;s:4:\"HIDE\";s:1:\"N\";}s:20:\"ADMIN_INFO@333333333\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:6;s:4:\"HIDE\";s:1:\"N\";}s:25:\"ADMIN_CHECKLIST@777888999\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:7;s:4:\"HIDE\";s:1:\"N\";}s:19:\"RSSREADER@777777777\";a:4:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:8;s:4:\"HIDE\";s:1:\"N\";s:8:\"SETTINGS\";a:3:{s:9:\"TITLE_STD\";s:33:\"Новости 1С-Битрикс\";s:3:\"CNT\";i:10;s:7:\"RSS_URL\";s:45:\"https://www.1c-bitrix.ru/about/life/news/rss/\";}}s:23:\"ADMIN_MARKETPALCE@22549\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:3;s:4:\"HIDE\";s:1:\"N\";}s:22:\"ADMIN_MOBILESHOP@13391\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:4;s:4:\"HIDE\";s:1:\"N\";}}}}','Y'),
(2,0,'global','settings','a:2:{s:18:\"start_menu_preload\";s:1:\"Y\";s:16:\"start_menu_title\";s:1:\"N\";}','Y'),
(3,0,'intranet','~gadgets_holder1','a:1:{s:7:\"GADGETS\";a:5:{s:15:\"RSSREADER@12333\";a:5:{s:6:\"COLUMN\";i:0;s:3:\"ROW\";i:0;s:8:\"USERDATA\";N;s:4:\"HIDE\";s:1:\"N\";s:8:\"SETTINGS\";a:2:{s:3:\"CNT\";s:2:\"10\";s:7:\"RSS_URL\";s:44:\"http://www.1c-bitrix.ru/about/life/news/rss/\";}}s:15:\"HTML_AREA@24648\";a:4:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:0;s:8:\"USERDATA\";N;s:4:\"HIDE\";s:1:\"N\";}s:15:\"FAVORITES@20837\";a:4:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:1;s:8:\"USERDATA\";a:1:{s:5:\"LINKS\";a:1:{i:0;a:2:{s:4:\"NAME\";s:0:\"\";s:3:\"URL\";s:24:\"http://www.1c-bitrix.ru/\";}}}s:4:\"HIDE\";s:1:\"N\";}s:12:\"PROBKI@28450\";a:4:{s:6:\"COLUMN\";i:2;s:3:\"ROW\";i:0;s:8:\"USERDATA\";N;s:4:\"HIDE\";s:1:\"N\";}s:13:\"WEATHER@23987\";a:4:{s:6:\"COLUMN\";i:2;s:3:\"ROW\";i:1;s:8:\"USERDATA\";N;s:4:\"HIDE\";s:1:\"N\";}}}','Y'),
(4,1,'admin_panel','settings','a:1:{s:4:\"edit\";s:3:\"off\";}','N'),
(5,1,'favorite','favorite_menu','a:1:{s:5:\"stick\";s:1:\"N\";}','N'),
(6,1,'main','helper_hero_admin','a:1:{s:4:\"time\";s:10:\"1476767377\";}','N'),
(9,1,'admin_menu','pos','a:1:{s:8:\"sections\";s:11:\"menu_system\";}','N')	;
#	TC`b_user_stored_auth`utf8_unicode_ci	;
CREATE TABLE `b_user_stored_auth` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(18) NOT NULL,
  `DATE_REG` datetime NOT NULL,
  `LAST_AUTH` datetime NOT NULL,
  `STORED_HASH` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `TEMP_HASH` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IP_ADDR` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ux_user_hash` (`USER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`b_user_stored_auth`utf8_unicode_ci	;
INSERT INTO `b_user_stored_auth` VALUES 
(1,1,'2016-10-18 09:05:30','2016-10-18 09:05:30','7b9e263abdaee413ee7f600ddf15f952','N',2130706433)	;
#	TC`b_utm_blog_comment`utf8_unicode_ci	;
CREATE TABLE `b_utm_blog_comment` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VALUE_ID` int(11) NOT NULL,
  `FIELD_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci,
  `VALUE_INT` int(11) DEFAULT NULL,
  `VALUE_DOUBLE` float DEFAULT NULL,
  `VALUE_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_utm_BLOG_COMMENT_1` (`FIELD_ID`),
  KEY `ix_utm_BLOG_COMMENT_2` (`VALUE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_utm_blog_post`utf8_unicode_ci	;
CREATE TABLE `b_utm_blog_post` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VALUE_ID` int(11) NOT NULL,
  `FIELD_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci,
  `VALUE_INT` int(11) DEFAULT NULL,
  `VALUE_DOUBLE` float DEFAULT NULL,
  `VALUE_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_utm_BLOG_POST_1` (`FIELD_ID`),
  KEY `ix_utm_BLOG_POST_2` (`VALUE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_utm_forum_message`utf8_unicode_ci	;
CREATE TABLE `b_utm_forum_message` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VALUE_ID` int(11) NOT NULL,
  `FIELD_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci,
  `VALUE_INT` int(11) DEFAULT NULL,
  `VALUE_DOUBLE` float DEFAULT NULL,
  `VALUE_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_utm_FORUM_MESSAGE_1` (`FIELD_ID`),
  KEY `ix_utm_FORUM_MESSAGE_2` (`VALUE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_uts_blog_comment`utf8_unicode_ci	;
CREATE TABLE `b_uts_blog_comment` (
  `VALUE_ID` int(11) NOT NULL,
  `UF_BLOG_COMMENT_DOC` text COLLATE utf8_unicode_ci,
  `UF_BLOG_COMM_URL_PRV` int(11) DEFAULT NULL,
  PRIMARY KEY (`VALUE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_uts_blog_post`utf8_unicode_ci	;
CREATE TABLE `b_uts_blog_post` (
  `VALUE_ID` int(11) NOT NULL,
  `UF_BLOG_POST_DOC` text COLLATE utf8_unicode_ci,
  `UF_BLOG_POST_URL_PRV` int(11) DEFAULT NULL,
  `UF_GRATITUDE` int(18) DEFAULT NULL,
  PRIMARY KEY (`VALUE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_uts_forum_message`utf8_unicode_ci	;
CREATE TABLE `b_uts_forum_message` (
  `VALUE_ID` int(11) NOT NULL,
  `UF_FORUM_MES_URL_PRV` int(11) DEFAULT NULL,
  PRIMARY KEY (`VALUE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_vote`utf8_unicode_ci	;
CREATE TABLE `b_vote` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `CHANNEL_ID` int(18) NOT NULL DEFAULT '0',
  `C_SORT` int(18) DEFAULT '100',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NOTIFY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `AUTHOR_ID` int(18) DEFAULT NULL,
  `TIMESTAMP_X` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_START` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_END` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COUNTER` int(11) NOT NULL DEFAULT '0',
  `TITLE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DESCRIPTION_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'html',
  `IMAGE_ID` int(18) DEFAULT NULL,
  `EVENT1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EVENT2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EVENT3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UNIQUE_TYPE` int(18) NOT NULL DEFAULT '2',
  `KEEP_IP_SEC` int(18) DEFAULT NULL,
  `DELAY` int(18) DEFAULT NULL,
  `DELAY_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TEMPLATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RESULT_TEMPLATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_CHANNEL_ID` (`CHANNEL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_vote_answer`utf8_unicode_ci	;
CREATE TABLE `b_vote_answer` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `TIMESTAMP_X` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `QUESTION_ID` int(18) NOT NULL DEFAULT '0',
  `C_SORT` int(18) DEFAULT '100',
  `MESSAGE` text COLLATE utf8_unicode_ci,
  `MESSAGE_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'html',
  `COUNTER` int(18) NOT NULL DEFAULT '0',
  `FIELD_TYPE` int(5) NOT NULL DEFAULT '0',
  `FIELD_WIDTH` int(18) DEFAULT NULL,
  `FIELD_HEIGHT` int(18) DEFAULT NULL,
  `FIELD_PARAM` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COLOR` varchar(7) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_QUESTION_ID` (`QUESTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_vote_channel`utf8_unicode_ci	;
CREATE TABLE `b_vote_channel` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `SYMBOLIC_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `C_SORT` int(18) DEFAULT '100',
  `FIRST_SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `HIDDEN` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `TIMESTAMP_X` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `TITLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `VOTE_SINGLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `USE_CAPTCHA` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_vote_channel_2_group`utf8_unicode_ci	;
CREATE TABLE `b_vote_channel_2_group` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `CHANNEL_ID` int(18) NOT NULL DEFAULT '0',
  `GROUP_ID` int(18) NOT NULL DEFAULT '0',
  `PERMISSION` int(18) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `IX_VOTE_CHANNEL_ID_GROUP_ID` (`CHANNEL_ID`,`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_vote_channel_2_site`utf8_unicode_ci	;
CREATE TABLE `b_vote_channel_2_site` (
  `CHANNEL_ID` int(18) NOT NULL DEFAULT '0',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`CHANNEL_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_vote_event`utf8_unicode_ci	;
CREATE TABLE `b_vote_event` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `VOTE_ID` int(18) NOT NULL DEFAULT '0',
  `VOTE_USER_ID` int(18) NOT NULL DEFAULT '0',
  `DATE_VOTE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `STAT_SESSION_ID` int(18) DEFAULT NULL,
  `IP` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VALID` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `IX_USER_ID` (`VOTE_USER_ID`),
  KEY `IX_B_VOTE_EVENT_2` (`VOTE_ID`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_vote_event_answer`utf8_unicode_ci	;
CREATE TABLE `b_vote_event_answer` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `EVENT_QUESTION_ID` int(18) NOT NULL DEFAULT '0',
  `ANSWER_ID` int(18) NOT NULL DEFAULT '0',
  `MESSAGE` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_EVENT_QUESTION_ID` (`EVENT_QUESTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_vote_event_question`utf8_unicode_ci	;
CREATE TABLE `b_vote_event_question` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `EVENT_ID` int(18) NOT NULL DEFAULT '0',
  `QUESTION_ID` int(18) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `IX_EVENT_ID` (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_vote_question`utf8_unicode_ci	;
CREATE TABLE `b_vote_question` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `TIMESTAMP_X` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `VOTE_ID` int(18) NOT NULL DEFAULT '0',
  `C_SORT` int(18) DEFAULT '100',
  `COUNTER` int(11) NOT NULL DEFAULT '0',
  `QUESTION` text COLLATE utf8_unicode_ci NOT NULL,
  `QUESTION_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'html',
  `IMAGE_ID` int(18) DEFAULT NULL,
  `DIAGRAM` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `REQUIRED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DIAGRAM_TYPE` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'histogram',
  `TEMPLATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TEMPLATE_NEW` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_VOTE_ID` (`VOTE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`b_vote_user`utf8_unicode_ci	;
CREATE TABLE `b_vote_user` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `STAT_GUEST_ID` int(18) DEFAULT NULL,
  `AUTH_USER_ID` int(18) DEFAULT NULL,
  `COUNTER` int(18) NOT NULL DEFAULT '0',
  `DATE_FIRST` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_LAST` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `LAST_IP` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
